# Call Follow-Ups

Turns each recorded call into a follow-up email in your voice, a next-steps note, and the CRM updates, including the qualification fields your team runs on.

## Install and open

```bash
hermes profile import call-follow-ups.tar.gz && hermes -p call-follow-ups
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `call-follow-ups` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p call-follow-ups setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Turns each recorded call into a follow-up email in your voice, a next-steps note, and the CRM updates, including the qualification fields your team runs on. Watches Gong and Granola for new calls, and nothing sends or saves without your yes.

- **Crm update proposal**
- **Next steps note**
- **Promise tracker**
- **Recap email**
- **Voice profile**
- **Optional new call watch:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p call-follow-ups chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p call-follow-ups`.

## Setup

- Use pasted/exported transcripts for local work. Optional recordings require an available transcription capability; missing tools are disclosed.
- All 12 MCP entries and sampling are disabled. URL variables in .env.EXAMPLE are empty placeholders, not working servers. Choose a compatible implementation, verify its official endpoint/authentication/scopes and authorize account access before enabling. See skills/call-follow-ups/references/integrations.md.
- Select Gong and/or Granola, one CRM (Salesforce/HubSpot/Attio), and Gmail or Outlook. Calendar, Slack, Notion, Linear and Hex are optional; sharing, draft saves, tickets and updates each need explicit approval and readback.
- The new call watch ships paused, every 30 minutes on weekdays, local delivery. Use offer-new-call-watch to confirm timezone and start boundary, approve checkpoint storage, and resume the existing ID 4f1c190ab7c2; never create duplicates or use cron run for previews.
