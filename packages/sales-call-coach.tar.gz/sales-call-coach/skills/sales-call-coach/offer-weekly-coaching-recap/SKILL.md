---
name: offer-weekly-coaching-recap
description: "Use after setup or when asked about routines: offer weekly coaching recap."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "sales-call-coach"}}
---

# Offer the weekly coaching recap

When to use: Once after completed or skipped onboarding, or when the user asks about this optional routine.

The shipped definition fdd3339137a0 is paused. Its schedule is only a review default, not an agreed recipient time. No scheduling happens without explicit consent in this chat.

## Procedure
1. Read workspace/routine-choice-weekly-coaching-recap.md if present. A declined or enabled choice suppresses repeat offers unless the user brings it up. Ask once whether they want weekly coaching recap; explain its purpose. A no is recorded locally as declined; an unclear answer leaves it paused without treating silence as consent.
2. On yes, confirm their chosen days, local hour and IANA timezone, one necessary question at a time. The example cron `0 16 * * 5` is not a user preference. Inspect the recipient scheduler's actual timezone and DST behavior; never infer it from an abbreviation. Show the resulting schedule and local delivery for approval.
3. Use available native scheduler tools scoped to this active profile. List existing jobs first; find the shipped ID fdd3339137a0 and verify its name and prompt. If imported under another profile name, preserve stable ID and verify ownership before any update. Update that same paused definition to the approved schedule, then resume only after approval. If already enabled correctly, report it without duplication. Never create a duplicate by name or by ID. If the shipped record is absent, obtain approval to create exactly one equivalent job only after listing and checking for an existing equivalent.
4. Read the exact job back and verify its ID, schedule, timezone interpretation, enabled state, local delivery and next run. A tool failure is not success. Record enabled, the verified ID and agreed schedule in the choice file only after verification.
5. Report the agreed local time and explain that the user can ask to pause or change it. A decline or pause never deletes the definition. If scheduler tools are unavailable, leave it paused and say so.

## Routine scope
Read coaching-records and coaching-trends. Review the authorized logged calls since the previous recap, or the last seven days if none exists. Report the window, sample size, measured changes, two weakest supported dimensions with actual quotes, and one proposed habit. With no calls say no logged calls; do not fabricate evidence. Deliver only locally; do not send externally.

External sending and changes to accounts are outside routine consent. Keep delivery local. Never invent calls, quotes, trends, a user reply, or a successful execution.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.

Optional integrations and consent: see ../references/integrations.md.
