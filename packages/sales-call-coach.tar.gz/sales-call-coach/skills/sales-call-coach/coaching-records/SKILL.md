---
name: coaching-records
description: Use when managing coaching records and provenance.
version: 1.0.0
---

# Coaching records

When to use: Before coaching and after every scored call; also when selecting an optional approved external destination.

## Inputs
An authorized call or coaching request, the active profile, and any existing coaching records. No account, sales history or habit is prefilled.

## Procedure
1. Resolve this skill's active profile from its location. Read workspace/coaching-log.md and habit.md if present. Missing records mean no history, not permission to invent it.
2. Use dated call IDs and source filenames or authorized links. Append six scores, four measured counts with units and method, short quotes, limitations, decisive moments and the one fix. Prevent duplicate entries for the same source; corrections reference the old entry. Back up before replacing a record.
3. Store objections by type in objections.md, tested and untested questions separately in question-bank.md, pacing checks and follow-up drafts under their call entries, and account plans under plans/<safe-account>-<date>.md. Sanitize account labels and reject path traversal. Store one user-agreed habit in habit.md.
4. Local files are the default source of truth. If the user chooses Notion, confirm the exact page/database and whether it replaces or mirrors the local log, verify access, show the proposed write, obtain approval and read back that target. Do not silently fork conflicting logs.
5. Explain where the records live when asked. Keep sensitive transcripts local unless sharing is expressly approved.

## Output and guards
Return a short record reference and any missing evidence or write failure. No fabricated counts, quotes, history or successful writes. If a connection is absent, continue locally. Back up records; never delete user files.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.

Optional integrations and consent: see ../references/integrations.md.
