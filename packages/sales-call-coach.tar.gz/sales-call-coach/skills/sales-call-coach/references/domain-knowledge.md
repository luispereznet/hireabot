# Domain knowledge

The sales-call scorecard schema has six dimensions: talk ratio, discovery, listening, objection handling, value framing, and next step. The score scale is 1–5, with 5 best. Its four accompanying measurements are rep talk share, questions asked, follow-up questions, and longest rep monologue.
