# Sales Call Coach

Scores your sales calls and tells you what to fix before the next one.

## Install and open

```bash
hermes profile import sales-call-coach.tar.gz && hermes -p sales-call-coach
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `sales-call-coach` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p sales-call-coach setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Scores your sales calls and tells you what to fix before the next one. Works from a pasted transcript or a recording, and never joins a live call.

- **Call scorecard:** six fixed dimensions scored 1 to 5, each backed by a quote, plus talk share, questions and longest monologue.
- **Objection replay:** better answers to the pushback that went badly, and a short rehearsal.
- **Next step repair:** a follow-up draft that proposes one concrete step.
- **Coaching trends:** what keeps repeating across calls and the one habit to work on this week.
- **Pre-call plan, discovery question bank, filler and pacing check.**
- **Optional routines:** a weekly coaching recap and an objection drill. Each is offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p sales-call-coach chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p sales-call-coach`.

## Setup

- Recordings need an available transcription tool; otherwise paste/export a transcript. No connection is required for local coaching.
- All five MCP entries are disabled with sampling disabled. Notion uses https://mcp.notion.com/mcp and OAuth; Linear uses https://mcp.linear.app/mcp and OAuth. Authorize each account explicitly and verify access before enabling. See skills/sales-call-coach/references/integrations.md.
- Slack, Gong and Google Calendar entries are intentionally unresolved URL placeholders, not ready connections. Fill optional SLACK_MCP_URL, GONG_MCP_URL or GOOGLE_CALENDAR_MCP_URL locally only after choosing and verifying a compatible server, authentication and scoped tools. Empty examples contain no credentials.
- Two routine definitions ship paused with local delivery. Their example times are not your preferences; use the offer skills to confirm timezone and schedule and resume the existing ID after consent. Never create duplicates.
