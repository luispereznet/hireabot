---
name: humanizer
description: "Use when make drafts sound natural."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-account-research"}}
---

# humanizer

When to use: Make drafts sound natural and specific while preserving every sourced fact, number, commitment, and uncertainty.

## Inputs
Draft account brief, connector ask or forwardable intro; audience, intended action, approved tone and its source/evidence ledger.

## Steps
1. Read the draft and identify its purpose and audience. Ask one question only if that changes the edit. If no tone guide exists, use plain, concise professional wording, not an invented personal voice.
2. Freeze factual claims, names, relationship edges, dates, numbers, commitments, citations and uncertainty qualifiers. Note unsupported claims separately rather than making them sound more convincing.
3. Replace generic praise, jargon, repetitive openings and inflated confidence with specific language already supported by the draft. Shorten sentences and put the decision or ask first.
4. For research, preserve evidence versus hypothesis and source conflicts. For intros, preserve who knows whom, consent status, the easy decline and the actual ask; never imply familiarity, endorsement or willingness without evidence.
5. Compare every frozen item against the edited version. Restore any changed meaning, missing citation or softened caveat. Flag new information needed without filling it in.
6. Return a draft for review. Do not send, post or schedule it; sending requires explicit yes on the exact recipient and text through an available connection.

## Output
Revised draft; brief change notes; factual or permission questions, if any. Preserve the original evidence ledger and list any unsupported claims left unresolved.

## Guardrails
Ask one question at a time when blocked. Never invent facts, numbers, sources, relationships or results. Disclose missing tools/connections; accept paste, CSV, export, URL or files. Require an explicit yes for the exact action before sending, posting, buying or changing external records. Keep drafts local; ordinary workflows never activate routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
