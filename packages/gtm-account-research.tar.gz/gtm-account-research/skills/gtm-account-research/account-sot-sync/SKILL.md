---
name: account-sot-sync
description: "Use when map research outputs into Notion or Sheets system-of-record fields."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-account-research"}}
---

# account-sot-sync

When to use: Map research outputs into Notion or Sheets system-of-record fields.

## Inputs
Reviewed account brief with citations, destination Notion database or Google Sheet, account record key, field mapping, source-of-truth and conflict policy, read/write permissions.

## Steps
1. Read ../references/working-notes.md. Confirm the target database/sheet, exact record and allowed columns/properties. If no connected writer is available, say so and prepare a CSV or field-by-field patch instead.
2. Read the destination schema and existing record through the approved connection. Match by stable account ID or verified domain; show duplicates for resolution, never create a second account silently.
3. Map each finding to an allowed field with evidence link, as-of date and freshness. Preserve destination field types. Keep Unknown distinct from empty; do not erase a value merely because research lacks it.
4. Compare old and proposed values. Show conflicts and authoritative-source timestamps; apply the user's conflict policy, not a silent merge. Produce an exact before/after diff and identify any private content excluded.
5. Ask for explicit yes on that target, diff and record creation if needed. Without it, stop at the draft. After approval, re-read for concurrent changes and pause if the baseline changed.
6. Apply only the approved patch using recipient-connected tools. Read back the exact affected record and compare each field. Report partial writes and retries honestly; never retry creation without checking for an existing record.

## Output
Sync proposal or receipt: destination/key, mapping table, before/after, evidence, conflicts, omitted fields, approval state and verified read-back. Retain minimal references, not copied private mail or transcripts.

## Guardrails
Ask one question at a time when blocked. Never invent facts, numbers, sources, relationships or results. Disclose missing tools/connections; accept paste, CSV, export, URL or files. Require an explicit yes for the exact action before sending, posting, buying or changing external records. Keep drafts local; ordinary workflows never activate routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
