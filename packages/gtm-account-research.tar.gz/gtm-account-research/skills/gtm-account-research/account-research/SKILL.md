---
name: account-research
description: "Use when run adaptive single."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-account-research"}}
---

# account-research

When to use: Run adaptive single, standard, or Swarm research lanes on one account and synthesize sourced findings.

## Inputs
One named account/domain, meeting or strategy goal, deadline, approved sources and research depth. Read ../references/working-notes.md for scopes, permissions and source mappings.

## Steps
1. Resolve the account identity and requested decision; separate subsidiaries and similarly named firms. Ask for the single missing detail that changes the research.
2. Load agent-orchestration. Choose Single for dependent work, standard lanes for independent work, or deep swarm research only within approved limits. Suggested lanes: company changes, stakeholders, relationship history, competitive/technical context, strategy gaps.
3. Read approved CRM, mail/calendar, call notes and public web sources actually available. For every finding capture source URL or record ID, publication/event time, retrieval time, scope and confidence. Distinguish evidence from inference and Unknown.
4. Build a stakeholder map with evidenced roles, relationship owners, buying influence and gaps. Do not infer a buying role from title alone. Compare account signals with the user's stated offering; label strategy hypotheses, not facts.
5. Deduplicate on account/person/event identifiers, expose conflicting sources with timestamps, and retain unresolved alternatives. Synthesize the lanes rather than concatenating their reports.
6. Prioritize meeting questions, hypotheses to test and next decisions. Offer account-sot-sync for an approved field-mapped write-back; do not perform it implicitly. Recurring monitoring goes through offer-weekly-account-monitor.

## Output
Account brief: identity and as-of date; executive takeaway; signal/source table; stakeholder map; relationship timeline; competitive context; strategy hypotheses; meeting plan; Unknowns; Decisions needed; execution receipt with sources checked and unavailable lanes.

## Guardrails
Ask one question at a time when blocked. Never invent facts, numbers, sources, relationships or results. Disclose missing tools/connections; accept paste, CSV, export, URL or files. Require an explicit yes for the exact action before sending, posting, buying or changing external records. Keep drafts local; ordinary workflows never activate routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
