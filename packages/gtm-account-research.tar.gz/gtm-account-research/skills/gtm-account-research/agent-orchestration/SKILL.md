---
name: agent-orchestration
description: "Use when coordinate a persistent pinned specialist."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-account-research"}}
---

# agent-orchestration

When to use: Coordinate a persistent pinned specialist, scoped subagents, adaptive armies, renameable folders, and auditable synthesis.

## Inputs
Named target/account, objective, approved source scopes, permissions, delegation preference, output destination and labels. Read ../references/working-notes.md before asking for saved settings.

## Steps
1. Keep the chosen persistent specialist responsible for configuration, source mappings, routine settings, synthesis and approvals. Pinning is a user preference, not a claim that another agent is running.
2. Show the mode and lane plan. Adaptive uses Single for small/dependent tasks, 2-3 workers for separable standard work, and 4-8 only for deep independent swarm work. Honor ask-before-delegating and custom limits; do not launch workers if approval is required but missing.
3. Scope account lanes to company signals, stakeholders, relationship history and strategy; scope connection lanes to evidence discovery, path ranking and intro drafts. Give each worker a bounded question, read-only source allowlist, expected evidence receipt and stop conditions.
4. Use available subagent tools only. If absent, run the same named lanes sequentially and disclose the fallback. Workers may draft plans, not send, write, connect accounts, enable jobs, create folders, widen access or delegate beyond scope.
5. Require receipts containing findings, source IDs/URLs, timestamps, scope, uncertainties and conflicts. Reject unsupported claims; parent deduplicates identities/events, resolves conflicts transparently and synthesizes a decision-ready answer.
6. Offer existing or renameable Strategy, Research, Execution and Operations folders only when durable outputs are needed. Explain each job and confirm any creation, move or write. Save semantic/display labels, group/worker names and preferences in the local config card with approval; labels never change permissions. Optional sibling handoffs are sourced drafts, not automatic dispatch.

## Output
Result, Evidence, Unknowns, Drafts, Decisions needed, Execution receipt; include actual mode, lane outcomes, missing sources and authorized writes. Do not claim a worker ran unless it returned a receipt.

## Guardrails
Ask one question at a time when blocked. Never invent facts, numbers, sources, relationships or results. Disclose missing tools/connections; accept paste, CSV, export, URL or files. Require an explicit yes for the exact action before sending, posting, buying or changing external records. Keep drafts local; ordinary workflows never activate routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
