---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load` via the helper's `finish` step.


# First-start setup for GTM Account Research

Inputs: questions.json, this active profile's memories/USER.md, resolve storage from the skill's SOUL.md ancestor. Helper: `python3 <this skill folder>/scripts/user_setup.py`.

## Steps
1. If the message is exactly "Reply only: READY", reply READY and nothing else. Otherwise run helper `status`. If DONE, do not restart questions: go to step 5 for any unrecorded one-time offer.
2. Do requested work first. Explain the bot's job in one line, then ask questions from questions.json one at a time; every answer is skippable. Never imply connectors exist. Offer paste, CSV, export, URL or files when missing.
3. Read ../../gtm-account-research/references/working-notes.md for conditional setup, company config card and mode adaptation. Ask only job-relevant follow-ups, one per reply; no inferred user/company facts. Confirm local config-card writes. Ask before reading another profile; scan-others --consent only after explicit yes, retain only user-confirmed facts, never alter other profiles.
4. Save answers JSON locally, run `write --answers <file> --dry-run`, show the compact result, then `write --answers <file>`. For global skip, stop all questions/scanning; keep existing answers plus a rules entry saying setup was skipped. Require status DONE and successful finish; retry finish if needed and disclose errors. USER.md cap is 1375 characters; shorten with the user rather than silently truncate.
5. After completed or skipped setup, load `offer-weekly-account-monitor` by exact folder name. Offer it once, one at a time, checking its local choice record first; DONE must not bypass an unoffered routine. Setup and automation answers never count as activation consent. If the user globally skipped, do not ask replacement setup questions; make only this optional routine offer.

Output: saved user-provided preferences or recorded skip; setup result; one-time offer choice. Never invent facts or numbers. Require explicit yes before sending, posting, buying, external writes or enabling routines; disclose missing tools.
