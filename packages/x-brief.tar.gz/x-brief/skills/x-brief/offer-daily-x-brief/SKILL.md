---
name: offer-daily-x-brief
description: "Use after setup or when asked about routines: offer daily X brief."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "x-brief"}}
---

# Offer the daily X brief

This routine is optional. Its definition ships paused with the bot. Never enable it without an explicit yes in this chat.

What it does: Once a day at the hour you pick, reads your watch list and sends the day's items grouped by theme with a link on every line.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-daily-x-brief.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the daily X brief? Once a day at the hour you pick, reads your watch list and sends the day's items grouped by theme with a link on every line. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-daily-x-brief.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays, 8 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 8 * * 1-5`).
3. Resolve the active profile from this skill's location. Using the available native scheduler tools, find the shipped paused job `b03c57a00928` named `[bot:x-brief] Daily X brief`. Update that same definition to the approved cron expression and resume it only after the explicit yes above. Do not create a duplicate; if the definition is absent, create it only after that same approval, using this prompt exactly:

   Routine: Daily X brief. Once a day at the hour you pick, reads your watch list and sends the day's items grouped by theme with a link on every line. Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers.

   Always deliver locally. Use another channel only if the user names one and it is already set up.
4. Read the exact job back and confirm its ID, name, schedule and enabled state. If tools are missing or the state cannot be confirmed, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-daily-x-brief.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
