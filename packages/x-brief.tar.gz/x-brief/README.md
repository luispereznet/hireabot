# X Brief

Turns the X accounts and topics you pick into one short daily brief with a link on every line.

## Install and open

```bash
hermes profile import x-brief.tar.gz && hermes -p x-brief
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `x-brief` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p x-brief setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Turns the X accounts and topics you pick into one short daily brief with a link on every line. Read-only: it never posts, replies, likes or DMs.

- **Watch list:** up to about ten accounts and five searches, kept in one file.
- **Daily X brief:** what landed since the last run, grouped by theme, each line with its post link. A quiet day gets one line.
- **Weekly X recap:** the themes that held, voices worth adding, accounts that went quiet.
- **Read a thread or post, draft a post or reply:** drafts only; you post them yourself.
- **Optional routines:** a daily brief and a Friday recap. Each is offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p x-brief chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p x-brief`.

## Setup

- All optional MCP entries and sampling ship disabled. Supply only a recipient-verified compatible server URL in the matching blank *_MCP_URL variable, configure its documented authentication and authorized scope locally, then enable only what you need. No endpoint or credential is supplied.
- Routine definitions ship paused with local delivery and no next run. Each exact offer skill is offered once after completed or skipped setup; explicit yes is required before enabling. Pasted inputs need no integration.
- X access is optional for pasted posts. For live reads, use the available X search tool (x_search) first and retain only real cited post links. Configure its documented access locally if needed; no AI provider or model is required by this package. Unsourced or degraded responses are not posts.
- Backup: the official xurl tool with your own X developer app. Install with `brew install --cask xdevplatform/tap/xurl` or `npm install -g @xdevplatform/xurl`, create the app at https://developer.x.com with redirect `http://localhost:8080/callback`, then run `xurl auth apps add`, `xurl auth oauth2 --app <app>`, `xurl auth default <app>` and `xurl auth status` yourself. X bills for API use; do not paste keys in chat. If neither access path works, paste posts or threads. Public x.com pages may require login; do not scrape or use a logged-in browser.
- Slack, Notion and Linear are optional recipient-connected destinations; the brief stays local unless you explicitly approve another destination.
