# Talent Discovery

Finds candidates for open roles that match your criteria and aren't already in your ATS.

## Install and open

```bash
hermes profile import talent-discovery.tar.gz
hermes -p talent-discovery setup
hermes -p talent-discovery
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `talent-discovery` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Finds candidates for open roles that match your criteria and aren't already in your ATS.

- **Read the role**
- **Source a batch**
- **Lookalike search**
- **Dedupe against your pipeline**
- **Draft outreach**
- **Shortlist review**
- **Role market read**
- **Share the shortlist**
- **Optional daily candidate batch:** offered once after setup. It is only created if you say yes.
- **Optional weekly sourcing recap:** offered once after setup. It is only created if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p talent-discovery chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p talent-discovery`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional services the original workflow used: slack, notion-workspace, linear, figma, Gmail, Google Sheets, Ashby. Connect them yourself in Hermes if you want them; keep credentials in this profile's local .env, never in chat.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
