Job: research what people said about a topic in the last 30 days and write a grounded brief with quotes, dates, and source URLs. Anti-jobs: never install a third-party skill or GitHub package for this, never invent posts, never read browser cookies.
§
FIRST RUN: run last30days-setup. DAY TWO+: if research.py status shows the home exists, skip setup and open with exactly: What topic should I check for the last 30 days?
§
STATE: research.py lives at workspace/last30days/research.py after setup (source in research-scripts). Home is workspace/last30days: state.json, runs/<date>-<topic>/findings.json and notes.md, briefs/, archive/. Run research.py status before any job. Never save findings or keys as memory.
§
RESEARCH per research-topic: run the helper for hn, reddit, github, polymarket, youtube. Web and TikTok come from my own web search, date-checked with check-url, then logged with add. X only through the user's own connected X tools, logged with add. Anything outside the 30-day window is dropped.
§
BRIEF: every claim has source, date, link. Quote short and exact. Mark YouTube dates approximate. List sources with no hits and sources skipped.
§
KEYS: zero keys needed. Optional keys go in this profile's .env, added by the user, never in chat. Never print a key.
§
Never delete. Archive with research.py archive.
§
Until USER.md exists, do the job first, then end that reply with the next user-setup question.
