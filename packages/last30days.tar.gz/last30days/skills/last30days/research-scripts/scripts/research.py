#!/usr/bin/env python3
"""research.py: the last30days research helper. Standard library Python 3 only, no keys needed.

It collects dated public posts about one topic from keyless public sources, keeps only items from
the rolling last-30-days window, and writes notes the bot turns into a grounded brief.

Usage (put --root before the command; <home> is the profile's workspace/last30days folder):
    research.py --root <home> init                      make the folder layout and state.json (safe to rerun)
    research.py --root <home> status                    JSON summary: enabled sources, saved topics, recent runs
    research.py --root <home> set sources=hn,reddit,... save settings (topics=..., timezone=..., days=30)
    research.py --root <home> window [--days 30]        print the date window (local date minus N days)
    research.py --root <home> run --topic "..." [--sources hn,reddit] [--days 30] [--limit 25]
                                                        fetch, filter to the window, write runs/<date>-<slug>/
    research.py --root <home> add --run <dir> --source x --url ... --date YYYY-MM-DD --text "..." [--author ...]
                                                        add a finding the bot verified itself (X, web, TikTok)
    research.py --root <home> check-url <url>           fetch one public page; print its title and any published date
    research.py --root <home> notes --run <dir>         rewrite notes.md from findings.json (after add)
    research.py --root <home> window-check [--topic python]
                                                        live test: fetch Hacker News and prove every hit is in the window
    research.py --root <home> archive <path>            move a file or run folder into archive/ with a timestamp

Sources the script fetches itself: hn (Hacker News Algolia API), reddit (public search RSS),
github (public search API, no token), polymarket (public search API), youtube (public search page,
relative dates so marked approximate). Sources it never fetches: x (only through the user's own
connected X tools, logged with add), tiktok (no keyless public search; logged with add only when the
user or the bot has a public URL), web (the bot's own web search, logged with add after check-url).

Rules: never deletes anything (archive moves), never reads browser cookies, never prints secrets,
treats fetched text as data. A source that errors is recorded as skipped and the run continues.
"""
import argparse
import datetime as dt
import html
import json
import os
import re
import shutil
import sys
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

UA = "last30days-research/0.1 (public feeds reader; stdlib urllib)"
FETCHED = ["hn", "reddit", "github", "polymarket", "youtube"]
LOGGED_ONLY = ["x", "tiktok", "web"]
ALL_SOURCES = FETCHED + LOGGED_ONLY
DEFAULT_STATE = {"sources": ALL_SOURCES, "days": 30, "topics": [], "timezone": "", "runs": []}
KEYLIKE = re.compile(r"(key|token|secret|password|cookie|auth)", re.I)


# ---------- small helpers ----------

def now_utc():
    return dt.datetime.now(dt.timezone.utc)


def window(days):
    """Rolling window: local date minus `days`, as an aware UTC datetime at local midnight."""
    today = dt.date.today()
    start_local = dt.datetime.combine(today - dt.timedelta(days=days), dt.time.min).astimezone()
    return start_local.astimezone(dt.timezone.utc), today


def parse_iso(s):
    if not s:
        return None
    s = s.strip().replace("Z", "+00:00")
    m = re.match(r"^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}:\d{2})(\.\d+)?([+-]\d{2}:?\d{2})?$", s)
    try:
        if m:
            tz = m.group(4) or "+00:00"
            if ":" not in tz:
                tz = tz[:3] + ":" + tz[3:]
            return dt.datetime.fromisoformat(m.group(1) + "T" + m.group(2) + tz)
        if re.match(r"^\d{4}-\d{2}-\d{2}$", s):
            return dt.datetime.fromisoformat(s + "T00:00:00+00:00")
    except ValueError:
        return None
    return None


def get(url, accept="application/json", timeout=20):
    headers = {"User-Agent": UA, "Accept": accept}
    # Optional: a GITHUB_TOKEN the user put in this profile's .env raises the GitHub search limit. Never printed.
    if url.startswith("https://api.github.com/") and os.environ.get("GITHUB_TOKEN"):
        headers["Authorization"] = "Bearer " + os.environ["GITHUB_TOKEN"]
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", "replace")


def strip_html(s, n=400):
    s = re.sub(r"<[^>]+>", " ", s or "")
    s = html.unescape(re.sub(r"\s+", " ", s)).strip()
    return s[:n] + ("..." if len(s) > n else "")


def slugify(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")[:40] or "topic"


def finding(source, url, when, text, author="", title="", approx=False, extra=None):
    d = {"source": source, "url": url, "date": when.astimezone(dt.timezone.utc).strftime("%Y-%m-%d"),
         "datetime": when.astimezone(dt.timezone.utc).isoformat(), "date_approx": approx,
         "title": title, "text": text, "author": author}
    if extra:
        d.update(extra)
    return d


# ---------- sources ----------

def src_hn(topic, start, limit):
    ts = int(start.timestamp())
    out = []
    for tags in ("story", "comment"):
        q = urllib.parse.urlencode({"query": topic, "tags": tags, "hitsPerPage": limit,
                                    "numericFilters": "created_at_i>%d" % ts})
        data = json.loads(get("https://hn.algolia.com/api/v1/search_by_date?" + q))
        for h in data.get("hits", []):
            when = parse_iso(h.get("created_at"))
            if not when:
                continue
            item = "https://news.ycombinator.com/item?id=%s" % h.get("objectID")
            if tags == "story":
                text = strip_html(h.get("story_text") or "") or (h.get("url") or "")
                out.append(finding("hn", item, when, text, h.get("author", ""), h.get("title") or "",
                                   extra={"points": h.get("points"), "comments": h.get("num_comments"),
                                          "link": h.get("url") or ""}))
            else:
                out.append(finding("hn", item, when, strip_html(h.get("comment_text")), h.get("author", ""),
                                   "comment on: " + (h.get("story_title") or "")))
    return out


def src_reddit(topic, start, limit):
    q = urllib.parse.urlencode({"q": topic, "sort": "new", "t": "month", "limit": limit})
    xml = get("https://www.reddit.com/search.rss?" + q, accept="application/atom+xml")
    ns = {"a": "http://www.w3.org/2005/Atom"}
    root = ET.fromstring(xml)
    out = []
    for e in root.findall("a:entry", ns):
        when = parse_iso((e.findtext("a:published", "", ns) or e.findtext("a:updated", "", ns)))
        link = e.find("a:link", ns)
        cat = e.find("a:category", ns)
        if not when or link is None:
            continue
        out.append(finding("reddit", link.get("href", ""), when, strip_html(e.findtext("a:content", "", ns)),
                           e.findtext("a:author/a:name", "", ns), e.findtext("a:title", "", ns),
                           extra={"subreddit": cat.get("label", "") if cat is not None else ""}))
    return out


def src_github(topic, start, limit):
    day = start.strftime("%Y-%m-%d")
    out = []
    q = urllib.parse.urlencode({"q": "%s created:>=%s" % (topic, day), "sort": "created", "order": "desc",
                                "per_page": min(limit, 30)})
    for it in json.loads(get("https://api.github.com/search/issues?" + q)).get("items", []):
        when = parse_iso(it.get("created_at"))
        if when:
            kind = "pull request" if it.get("pull_request") else "issue"
            out.append(finding("github", it.get("html_url", ""), when, strip_html(it.get("body") or ""),
                               (it.get("user") or {}).get("login", ""), "%s: %s" % (kind, it.get("title", "")),
                               extra={"comments": it.get("comments")}))
    q = urllib.parse.urlencode({"q": "%s pushed:>=%s" % (topic, day), "sort": "stars", "order": "desc",
                                "per_page": min(limit, 15)})
    for it in json.loads(get("https://api.github.com/search/repositories?" + q)).get("items", []):
        when = parse_iso(it.get("pushed_at"))
        if when:
            out.append(finding("github", it.get("html_url", ""), when, it.get("description") or "",
                               (it.get("owner") or {}).get("login", ""), "repo: " + it.get("full_name", ""),
                               extra={"stars": it.get("stargazers_count"), "date_meaning": "last push"}))
    return out


def src_polymarket(topic, start, limit):
    q = urllib.parse.urlencode({"q": topic, "limit_per_type": min(limit, 20)})
    data = json.loads(get("https://gamma-api.polymarket.com/public-search?" + q))
    out = []
    for ev in data.get("events") or []:
        when = parse_iso(ev.get("updatedAt")) or parse_iso(ev.get("createdAt"))
        if not when:
            continue
        markets = []
        for m in (ev.get("markets") or [])[:5]:
            markets.append({"question": m.get("question"), "outcomes": m.get("outcomes"),
                            "prices": m.get("outcomePrices")})
        out.append(finding("polymarket", "https://polymarket.com/event/%s" % ev.get("slug", ""), when,
                           strip_html(ev.get("description") or "", 250), "", ev.get("title", ""),
                           extra={"created": ev.get("createdAt"), "closed": ev.get("closed"),
                                  "volume": ev.get("volume"), "volume_1wk": ev.get("volume1wk"),
                                  "markets": markets, "date_meaning": "last update"}))
    return out


REL = re.compile(r"(\d+)\s*(second|minute|hour|day|week|month|year|[smhdwy]|mo)s?\b", re.I)


def rel_to_dt(text):
    m = REL.search(text or "")
    if not m:
        return None
    n, unit = int(m.group(1)), m.group(2).lower()
    days = {"second": 0, "s": 0, "minute": 0, "m": 0, "hour": 0, "h": 0, "day": 1, "d": 1,
            "week": 7, "w": 7, "month": 30, "mo": 30, "year": 365, "y": 365}.get(unit, None)
    if days is None:
        return None
    return now_utc() - dt.timedelta(days=n * days)


def src_youtube(topic, start, limit):
    # Public search page with the "this month" upload filter. Dates are relative ("3w ago"), so approximate.
    q = urllib.parse.urlencode({"search_query": topic, "sp": "EgIIBA=="})
    page = get("https://www.youtube.com/results?" + q, accept="text/html")
    m = re.search(r"ytInitialData\s*=\s*(\{.*?\});\s*</script>", page, re.S)
    if not m:
        raise RuntimeError("search page layout changed; no data block found")
    data = json.loads(m.group(1))
    out = []

    def walk(o):
        if isinstance(o, dict):
            if "videoRenderer" in o:
                yield o["videoRenderer"]
            for v in o.values():
                for x in walk(v):
                    yield x
        elif isinstance(o, list):
            for v in o:
                for x in walk(v):
                    yield x

    for v in walk(data):
        title = "".join(r.get("text", "") for r in (v.get("title") or {}).get("runs", []))
        rel = (v.get("publishedTimeText") or {}).get("simpleText", "")
        when = rel_to_dt(rel)
        if not when or not v.get("videoId"):
            continue
        chan = "".join(r.get("text", "") for r in (v.get("ownerText") or {}).get("runs", []))
        snip = ""
        for d in v.get("detailedMetadataSnippets") or []:
            snip = "".join(r.get("text", "") for r in (d.get("snippetText") or {}).get("runs", []))
            break
        out.append(finding("youtube", "https://www.youtube.com/watch?v=" + v["videoId"], when, snip, chan, title,
                           approx=True, extra={"published_text": rel,
                                               "views": (v.get("viewCountText") or {}).get("simpleText", "")}))
        if len(out) >= limit:
            break
    return out


FETCHERS = {"hn": src_hn, "reddit": src_reddit, "github": src_github, "polymarket": src_polymarket,
            "youtube": src_youtube}
NOT_FETCHED_NOTE = {
    "x": "not fetched by the script; searched only through the user's own connected X tools and logged with add",
    "tiktok": "no keyless public search; only public URLs the user or bot found are logged with add",
    "web": "found with the bot's web search, date checked with check-url, then logged with add",
}


# ---------- state ----------

def home(args):
    if not args.root:
        sys.exit("error: pass --root <profile>/workspace/last30days before the command")
    return os.path.abspath(os.path.expanduser(args.root))


def load_state(h):
    p = os.path.join(h, "state.json")
    if not os.path.exists(p):
        return dict(DEFAULT_STATE)
    with open(p) as f:
        s = json.load(f)
    for k, v in DEFAULT_STATE.items():
        s.setdefault(k, v)
    return s


def save_state(h, s):
    p = os.path.join(h, "state.json")
    tmp = p + ".tmp"
    with open(tmp, "w") as f:
        json.dump(s, f, indent=2)
    os.replace(tmp, p)


def stamp():
    return dt.datetime.now().strftime("%Y%m%d-%H%M%S")


def cmd_init(a):
    h = home(a)
    for d in ("runs", "archive"):
        os.makedirs(os.path.join(h, d), exist_ok=True)
    if not os.path.exists(os.path.join(h, "state.json")):
        save_state(h, dict(DEFAULT_STATE))
    print(json.dumps({"ok": True, "home": h}))


def cmd_status(a):
    h = home(a)
    s = load_state(h)
    start, today = window(int(s.get("days", 30)))
    print(json.dumps({"home": h, "exists": os.path.isdir(h), "sources": s["sources"], "days": s["days"],
                      "window": [start.astimezone().strftime("%Y-%m-%d"), today.isoformat()],
                      "topics": s["topics"], "timezone": s["timezone"], "recent_runs": s["runs"][-5:]}, indent=2))


def cmd_set(a):
    h = home(a)
    s = load_state(h)
    for pair in a.pairs:
        if "=" not in pair:
            sys.exit("error: use key=value")
        k, v = pair.split("=", 1)
        if KEYLIKE.search(k):
            sys.exit("error: refusing to store '%s'; keys and tokens belong in the profile .env, never here" % k)
        if k == "sources":
            bad = [x for x in v.split(",") if x and x not in ALL_SOURCES]
            if bad:
                sys.exit("error: unknown sources %s; choose from %s" % (bad, ",".join(ALL_SOURCES)))
            s[k] = [x for x in v.split(",") if x]
        elif k == "topics":
            s[k] = [x.strip() for x in v.split(";") if x.strip()]
        elif k == "days":
            s[k] = max(1, min(30, int(v)))
        elif k == "timezone":
            s[k] = v
        else:
            sys.exit("error: unknown setting %s (sources, topics, days, timezone)" % k)
    save_state(h, s)
    print(json.dumps({"ok": True, "sources": s["sources"], "topics": s["topics"], "days": s["days"]}))


def cmd_window(a):
    start, today = window(a.days)
    print(json.dumps({"days": a.days, "from": start.astimezone().strftime("%Y-%m-%d"), "to": today.isoformat()}))


def new_run_dir(h, topic):
    base = os.path.join(h, "runs", "%s-%s" % (dt.date.today().isoformat(), slugify(topic)))
    d, n = base, 2
    while os.path.exists(d):
        d, n = "%s-%d" % (base, n), n + 1
    os.makedirs(d)
    return d


def in_window(f, start):
    w = parse_iso(f["datetime"])
    return w is not None and w >= start and w <= now_utc() + dt.timedelta(days=1)


def write_notes(run_dir, data):
    lines = ["# Notes: %s" % data["topic"], "",
             "Window: %s to %s (last %d days). Fetched %s." % (data["window"][0], data["window"][1],
                                                               data["days"], data["fetched_at"]), ""]
    lines.append("## Sources")
    for src, st in data["sources"].items():
        lines.append("- %s: %s" % (src, st))
    lines.append("")
    by = {}
    for f in data["findings"]:
        by.setdefault(f["source"], []).append(f)
    for src in sorted(by):
        lines.append("## %s (%d)" % (src, len(by[src])))
        for f in sorted(by[src], key=lambda x: x["datetime"], reverse=True):
            approx = " (approx.)" if f.get("date_approx") else ""
            head = f["title"] or (f["text"][:80] if f["text"] else f["url"])
            lines.append("- %s%s | %s | %s" % (f["date"], approx, head, f["url"]))
            if f.get("text"):
                lines.append("  > %s" % f["text"][:300].replace("\n", " "))
        lines.append("")
    with open(os.path.join(run_dir, "notes.md"), "w") as fh:
        fh.write("\n".join(lines))


def cmd_run(a):
    h = home(a)
    s = load_state(h)
    days = max(1, min(30, a.days or int(s.get("days", 30))))
    start, today = window(days)
    wanted = a.sources.split(",") if a.sources else s["sources"]
    run_dir = new_run_dir(h, a.topic)
    data = {"topic": a.topic, "days": days, "window": [start.astimezone().strftime("%Y-%m-%d"), today.isoformat()],
            "fetched_at": now_utc().isoformat(), "sources": {}, "findings": []}
    for src in ALL_SOURCES:
        if src not in wanted:
            data["sources"][src] = "off (not enabled)"
            continue
        if src in LOGGED_ONLY:
            data["sources"][src] = "pending: " + NOT_FETCHED_NOTE[src]
            continue
        try:
            got = FETCHERS[src](a.topic, start, a.limit)
            kept = [f for f in got if in_window(f, start)]
            dropped = len(got) - len(kept)
            data["findings"].extend(kept)
            data["sources"][src] = ("ok: %d in window" % len(kept) + (", %d older dropped" % dropped if dropped else "")
                                    if kept else "ok: no hits in window" + (" (%d older dropped)" % dropped if dropped else ""))
        except urllib.error.HTTPError as e:
            data["sources"][src] = "skipped: HTTP %s%s" % (e.code, " (rate limited)" if e.code in (403, 429) else "")
        except Exception as e:  # any source failure is recorded, never fatal
            data["sources"][src] = "skipped: %s" % (str(e)[:120] or type(e).__name__)
    with open(os.path.join(run_dir, "findings.json"), "w") as fh:
        json.dump(data, fh, indent=2)
    write_notes(run_dir, data)
    s["runs"] = (s["runs"] + [{"topic": a.topic, "dir": os.path.relpath(run_dir, h), "date": today.isoformat(),
                               "count": len(data["findings"])}])[-50:]
    save_state(h, s)
    print(json.dumps({"run": run_dir, "count": len(data["findings"]), "sources": data["sources"]}, indent=2))


def load_run(h, run):
    d = run if os.path.isabs(run) else os.path.join(h, run)
    p = os.path.join(d, "findings.json")
    if not os.path.exists(p):
        sys.exit("error: no findings.json in %s" % d)
    with open(p) as fh:
        return d, json.load(fh)


def cmd_add(a):
    h = home(a)
    d, data = load_run(h, a.run)
    if a.source not in ALL_SOURCES:
        sys.exit("error: source must be one of %s" % ",".join(ALL_SOURCES))
    if not a.url.startswith(("http://", "https://")):
        sys.exit("error: a finding needs a real public URL")
    when = parse_iso(a.date)
    if not when:
        sys.exit("error: --date must be YYYY-MM-DD or ISO time")
    start = window(data["days"])[0]
    f = finding(a.source, a.url, when, a.text, a.author or "", a.title or "", approx=a.approx)
    if not in_window(f, start):
        sys.exit("error: %s is outside the window (%s to %s); not added" % (a.date, data["window"][0], data["window"][1]))
    if any(x["url"] == a.url and x["source"] == a.source for x in data["findings"]):
        print(json.dumps({"ok": True, "note": "already logged"}))
        return
    data["findings"].append(f)
    st = data["sources"].get(a.source, "")
    n = sum(1 for x in data["findings"] if x["source"] == a.source)
    data["sources"][a.source] = "ok: %d logged by the bot" % n if not st.startswith("ok: ") or "logged" in st else st
    with open(os.path.join(d, "findings.json"), "w") as fh:
        json.dump(data, fh, indent=2)
    write_notes(d, data)
    print(json.dumps({"ok": True, "source": a.source, "date": f["date"], "url": a.url}))


def cmd_notes(a):
    h = home(a)
    d, data = load_run(h, a.run)
    write_notes(d, data)
    print(os.path.join(d, "notes.md"))


class _Meta(HTMLParser):
    KEYS = ("article:published_time", "og:published_time", "datepublished", "date", "pubdate",
            "publish-date", "dc.date", "article:modified_time")

    def __init__(self):
        HTMLParser.__init__(self)
        self.title, self.dates, self._in_title = "", [], False

    def handle_starttag(self, tag, attrs):
        d = dict((k.lower(), v or "") for k, v in attrs)
        if tag == "title":
            self._in_title = True
        elif tag == "meta":
            name = (d.get("property") or d.get("name") or d.get("itemprop") or "").lower()
            if name in self.KEYS and d.get("content"):
                self.dates.append((name, d["content"]))
            if name == "og:title" and not self.title:
                self.title = d.get("content", "")
        elif tag == "time" and d.get("datetime"):
            self.dates.append(("time", d["datetime"]))

    def handle_endtag(self, tag):
        if tag == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title and len(self.title) < 200:
            self.title += data.strip()


def cmd_check_url(a):
    if not a.url.startswith(("http://", "https://")):
        sys.exit("error: give a public http(s) URL")
    try:
        page = get(a.url, accept="text/html", timeout=20)
    except Exception as e:
        print(json.dumps({"url": a.url, "ok": False, "error": str(e)[:160]}))
        sys.exit(2)
    p = _Meta()
    try:
        p.feed(page[:400000])
    except Exception:
        pass
    found = re.findall(r'"datePublished"\s*:\s*"([^"]+)"', page[:400000])
    dates = p.dates + [("jsonld", x) for x in found[:3]]
    start, today = window(30)
    best = None
    for _, v in dates:
        w = parse_iso(v[:25]) or parse_iso(v[:10])
        if w:
            best = w
            break
    print(json.dumps({"url": a.url, "ok": True, "title": html.unescape(p.title)[:200], "dates_found": dates[:6],
                      "published": best.strftime("%Y-%m-%d") if best else None,
                      "in_window": bool(best and best >= start)}, indent=2))


def cmd_window_check(a):
    start, today = window(30)
    try:
        got = src_hn(a.topic, start, 20)
    except Exception as e:
        print(json.dumps({"ok": False, "error": "Hacker News fetch failed: %s" % str(e)[:160]}))
        sys.exit(2)
    kept = [f for f in got if in_window(f, start)]
    outside = [f["date"] for f in got if not in_window(f, start)]
    dates = sorted(f["date"] for f in kept)
    print(json.dumps({"ok": not outside, "topic": a.topic,
                      "window": [start.astimezone().strftime("%Y-%m-%d"), today.isoformat()],
                      "hits": len(kept), "oldest": dates[0] if dates else None, "newest": dates[-1] if dates else None,
                      "outside_window": outside,
                      "sample": [{"date": f["date"], "title": f["title"][:80], "url": f["url"]} for f in kept[:3]]},
                     indent=2))
    if outside:
        sys.exit(2)


def cmd_archive(a):
    h = home(a)
    src = os.path.abspath(a.path)
    if not os.path.exists(src):
        sys.exit("error: %s not found" % src)
    if not src.startswith(h + os.sep):
        sys.exit("error: only files under %s can be archived here" % h)
    dest_dir = os.path.join(h, "archive")
    os.makedirs(dest_dir, exist_ok=True)
    dest = os.path.join(dest_dir, "%s-%s" % (stamp(), os.path.basename(src.rstrip(os.sep))))
    shutil.move(src, dest)
    print(json.dumps({"ok": True, "moved_to": dest}))


def main():
    ap = argparse.ArgumentParser(description="last30days research helper (stdlib only)")
    ap.add_argument("--root", help="the profile's workspace/last30days folder")
    sub = ap.add_subparsers(dest="cmd")
    sub.add_parser("init")
    sub.add_parser("status")
    p = sub.add_parser("set"); p.add_argument("pairs", nargs="+")
    p = sub.add_parser("window"); p.add_argument("--days", type=int, default=30)
    p = sub.add_parser("run"); p.add_argument("--topic", required=True); p.add_argument("--sources")
    p.add_argument("--days", type=int); p.add_argument("--limit", type=int, default=25)
    p = sub.add_parser("add"); p.add_argument("--run", required=True); p.add_argument("--source", required=True)
    p.add_argument("--url", required=True); p.add_argument("--date", required=True); p.add_argument("--text", default="")
    p.add_argument("--author"); p.add_argument("--title"); p.add_argument("--approx", action="store_true")
    p = sub.add_parser("notes"); p.add_argument("--run", required=True)
    p = sub.add_parser("check-url"); p.add_argument("url")
    p = sub.add_parser("window-check"); p.add_argument("--topic", default="python")
    p = sub.add_parser("archive"); p.add_argument("path")
    a = ap.parse_args()
    fn = {"init": cmd_init, "status": cmd_status, "set": cmd_set, "window": cmd_window, "run": cmd_run,
          "add": cmd_add, "notes": cmd_notes, "check-url": cmd_check_url, "window-check": cmd_window_check,
          "archive": cmd_archive}.get(a.cmd)
    if not fn:
        ap.print_help()
        sys.exit(1)
    if a.cmd == "window-check" and not a.root:
        a.root = "."
    fn(a)


if __name__ == "__main__":
    main()
