---
name: last30days-setup
description: "Use when this is the first run or the user asks to set up last30days again."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "last30days"}}
---

# last30days setup (first run)

Goal: the helper installed and tested, the user's sources chosen, and X handled honestly. Ask one question per reply. Every question can be skipped, and skipping keeps the defaults (all public sources on).

## Steps

1. Find this profile's folder (`~/.hermes/profiles/<profile>`, usually `last30days`). Set `<home>` = `<profile folder>/workspace/last30days`.
2. Install the helper: create `<home>`, then copy `research.py` from the research-scripts skill folder (`skills/last30days/research-scripts/scripts/research.py` inside this profile) to `<home>/research.py` if it is missing or older. If an older copy exists, run `L30 archive <home>/research.py` first. Then run `L30 init` and `L30 status`. If either fails, say so and stop.
3. Check Python: `python3 --version`. Any Python 3.8 or newer works. Nothing else to install.
4. Prove it works: run `L30 window-check`. Show the window dates and the number of Hacker News hits. If it fails, tell the user the network or the source is down and carry on; research can still use the other sources.
5. One intro line: "I check what people said about a topic in the last 30 days and write a brief with real quotes, dates, and links. No keys needed to start."
6. Ask which sources to use: "I read Reddit, Hacker News, GitHub, Polymarket, YouTube, the web, and TikTok when there's a public link. Want all of them, or leave some out?" Save with `L30 set sources=...`. Skip keeps all.
7. X: check whether this Hermes profile has an X connection of the user's own (an X tool or connector already set up). If yes, say "I'll include X posts through your connected X." and keep `x` in sources. If no, say "X isn't connected, so I'll skip X and say so in each brief. You can connect your own X in Hermes later." and remove `x` from sources. Never ask for an X password, cookie, or someone else's key, and never sign in for them.
8. Topics they check often (optional): if USER.md already lists topics, save those without asking again. Otherwise ask, then save with `L30 set topics="topic one; topic two"`.
9. Optional keys: say once that no keys are needed. If they later want a higher GitHub search limit, they can add their own `GITHUB_TOKEN` to this profile's `.env` themselves. Never ask them to paste a key into chat.
10. Finish with: "Set. What topic should I check for the last 30 days?" If USER.md has no time zone, ask for one only if the user brings up scheduling.
11. Never rerun setup on day two unless they ask. MEMORY has the day-two opener.
