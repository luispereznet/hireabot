---
name: offer-weekly-rundown
description: "Use after setup or when asked about routines: offer the weekly topic rundown."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "last30days"}}
---

# Offer the weekly topic rundown

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat. Offer it only if the user saved at least one topic (`L30 status` shows `topics`).

What it does: once a week I re-run each saved topic for the last 30 days and save a fresh brief here in Hermes. It installs nothing and only reads public sources.

## When to offer

- Once, right after setup finishes (or the user skipped it) and topics are saved, or whenever the user asks about routines, reminders, or check-ins.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-weekly-rundown.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

"Want a weekly rundown of your saved topics? Once a week I check the last 30 days for each one and save a fresh brief here. Yes or no?"

- Explicit no: reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-weekly-rundown.md`. Stop.
- No clear answer or a change of topic: do not create a routine or record a decline. Carry on.
- Yes: continue.

## On a yes

1. Ask day, time, and time zone in one question. Suggest "Mondays at 8 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 8 * * 1` before conversion).
3. Get this profile's name (usually `last30days`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Weekly topic rundown. Use the research-topic skill for each topic in research.py status topics: run the helper, log only dated in-window findings, use X only if the user's own X is connected, and save one brief per topic in briefs/. Never invent posts, never install anything, never delete. Stay short and local." --name "[bot:<profile>] weekly-rundown" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly. Do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-weekly-rundown.md`.
6. Tell the user the day and time in their time zone, and how to change it with `hermes -p <profile> cron pause|resume|remove <job id>`, or by asking me.
