# last30days

Finds what people actually said about any topic in the last 30 days and writes a grounded brief: short exact quotes, real dates, and a link for every claim. It reads public conversation on Reddit, Hacker News, GitHub, Polymarket, YouTube, and the web, plus TikTok when a public link exists and X when you have connected your own X. It needs no keys to start.

- **Last 30 days only:** a rolling window from today back 30 days. Anything older is dropped, never passed off as recent.
- **Grounded, not guessed:** every quote, number, and date comes from a post or page it actually fetched. Sources with no hits, or that were skipped, are named in the brief.
- **Patterns, not anecdotes:** it says when a take is one loud post and when several sources agree, and shows Hacker News points, GitHub activity, Polymarket odds, and YouTube views.
- **Its own helper:** a small built-in Python script reads the public sources. It installs nothing else, reads no browser cookies, and never deletes your files.
- **X is your choice:** X posts are included only through your own connected X. Without it, the brief says X was skipped.
- **Optional routine:** a weekly rundown of your saved topics, only if you say yes.

Needs: Python 3 (already on most computers). Optional: your own X connection in Hermes, and your own GitHub token in this profile's `.env` for higher GitHub search limits.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called last30days, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `last30days.zip` from the last30days page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install last30days from the Downloads folder.

The installer finds the newest last30days download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/last30days.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them. Keys never ship with the bot, and none are needed to start.
