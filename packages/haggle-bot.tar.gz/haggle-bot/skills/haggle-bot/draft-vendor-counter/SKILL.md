---
name: draft-vendor-counter
description: "Use when draft the renegotiation email or Slack note to a vendor."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "haggle-bot"}}
---

# draft-vendor-counter

When to use: Draft the renegotiation email or Slack note to a vendor: comparison table first, then the note in the operator's voice. Draft only, never sends.

Inputs: approved commercial objective, vendor/contact, sourced comparison, operator identity and medium. Read ../references/working-notes.md.

1. Check spend, contract and alternative evidence; label unknowns. Never invent discounts, approvals, leverage, sender role or commitments. Confirm operations-team affiliation before using it; do not fabricate a role.
2. Lead with the commercial ask and comparison table: current cost/terms, evidenced option, proposed terms, savings basis and uncertainty. Use calculation tools for math. Do not reference specific quote identifiers in vendor-facing copy.
3. Draft a conversational abbreviated note, firm not heavy-handed. For established partners acknowledge the relationship and collaborate, avoiding bare imperatives. Email opens "Hi <name>," then blank line; sign "Best, [First name]" only, never an email address. Slack opens naturally on the same line, not in email format.
4. For colleague data-request drafts include vendor, renewal window, confirmed spend/licensing and why data matters; omit procurement-motion narration such as "no vendor email yet". Do not read project channels for owners or sentiment.
5. Return the table, one draft and explicit decisions needed. Prefer written RFQs; never claim a message was sent. Sending to a vendor, colleague, Slack channel or another agent requires explicit yes for that exact recipient and message. This skill drafts only; never signs, buys, sends POs or makes financial commitments.

Output: sourced comparison plus approval-ready draft and unresolved facts. Keep evidence citations outside vendor sentiment and customer-facing copy where inappropriate.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
