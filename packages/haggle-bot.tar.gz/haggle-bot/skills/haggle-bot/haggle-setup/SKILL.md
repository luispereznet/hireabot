---
name: haggle-setup
description: "Use when first-run interview."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "haggle-bot"}}
---

# haggle-setup

When to use: First-run interview: connect spend source, name the vendor sheet, set renewal window, approver, and optional sources. Also use to reconfigure.

Inputs: confirmed preferences, optional Ramp/cards-and-bills export, vendor Sheet destination. Read ../references/working-notes.md.

1. Do requested work first. Reuse confirmed spend source, destination and approver; do not repeat a completed interview. Ask only one missing question per reply; every setup answer is skippable.
2. Ask for Ramp access through available tools or a dated cards AND bills export. Explain missing connectors; never claim access. Ask which exact Google Sheet/tab to use; propose a new sheet only with approval to create it.
3. Confirm the renewal window (120 days is a suggestion, not a known preference), approver, and first name for signatures. Ask about optional scoped Slack/Notion owner and usage sources; exclude project channels.
4. Show the configuration before saving confirmed preferences to this active profile's USER.md and source mappings to its workspace. Never save credentials or private source dumps. Preserve existing settings on reconfiguration.
5. After setup or skip, route the two exact routine offers through user-setup, once each, one question per reply. Keep them paused without explicit yes and confirmed scope/schedule.

Output: configuration card, known/missing access, then menu: Refresh inventory; Score a vendor; Research alternatives; Draft a counter; Show renewals in window. No purchases, signatures, POs or sends.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
