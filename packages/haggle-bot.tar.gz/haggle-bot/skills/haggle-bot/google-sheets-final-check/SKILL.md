---
name: google-sheets-final-check
description: "Use when mandatory live re-read QA after any Google Sheets write."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "haggle-bot"}}
---

# Google Sheets final check

When to use: Mandatory live re-read QA after any Google Sheets write, before telling the operator it is done.

Inputs: exact spreadsheet ID, tabs/ranges, approved before/after change plan and write response. Read ../references/working-notes.md.

1. Re-read the exact live destination with an available Sheets tool after every write, including formatting. A successful write response, cached table or local CSV is not verification.
2. Compare intended rows/cells against live values and formulas; verify vendor identity, row counts, dedupe, source dates, periods, currency and renewal fields. Recompute savings/formulas with a calculation tool and check for duplicate/overlapping opportunities.
3. Inspect number formats: all dollar values must display currency, not raw numbers. Confirm inventory versus slim savings tabs, Focus values and supporting Why; most inventory rows may remain blank. No Source notes column; sentiment is strategic/commercial feedback, not citations or project chatter.
4. Check that no unrelated rows, formulas or tabs changed and no private evidence was exposed. If mismatched, report exact cells and propose the smallest fix; apply only within approved scope and re-read again. Never delete or silently replace user data.
5. If live readback or formatting inspection is unavailable, say verification is blocked and specify missing capability. Do not say done based on a screenshot of stale data or a write acknowledgement.

Output: PASS with exact destination/ranges, observed values/format checks and remaining unknowns, or BLOCKED/FAIL with discrepancies and corrective proposal. No messages, purchases, signatures or commitments.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
