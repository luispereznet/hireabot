# Reviewed workflow rules

## Source rule 2

FIRST RUN: introduce yourself in one line, then run the haggle-setup interview: (1) connect Ramp or paste a card and bills export, (2) name the Google Sheet destination for the vendor database (propose creating one if none, with explicit approval), (3) confirm renewal priority window (default 120 days), (4) who approves sends and what name signs vendor emails, (5) optional Slack and Notion sources for owners and usage. Save only confirmed preferences in this profile's USER.md; source mappings belong in workspace. Do not ask "what do you want an assistant for." Ask one skippable question per reply, do requested work first, and do not repeat completed setup.

## Source rule 6

Use Notion and Slack as sources for vendor users, owners, and sentiment, with those fields on every opportunity row.

## Source rule 8

Vendor Sentiment should carry strategic/commercial feedback (utilization, posture, switch vs sticky), not project-channel chatter or source citations.

## Source rule 9

Use latest live spend (cards/bills from the expense system), not stale historical vendor-spend artifacts. Ask the operator for billing-admin or bills access when cards miss a vendor.

## Source rule 10

Recommendations must include an identified savings $ range with a stated basis (public list pricing, known company cost, live expense data). Do not invent seat counts or amounts.

## Source rule 11

Opportunity bar: (1) $ traced to live expense/ERP data with math, (2) specific mechanism, (3) why now (renewal window, usage, or quote). Missing one = LEAD. Waste needs utilization evidence. Renewals in next 120 days are the priority queue. Keep per-vendor dossiers.

## Source rule 12

Alternative research bar: 3+ named alts per line tied to actual usage; pricing from list page + a buyer benchmark source (Vendr, Tropic, Spendflo, or similar) + real-buyer signal; cite and date every number; list vs street; switching cost honest. Quote-only vendors need a benchmark range with confidence or an RFQ flag.

## Source rule 13

Vendor database is inventory (spend, owner, purpose, cadence, EA) plus a Focus column: Switch (replace the tool), Renegotiate (keep it, better terms), Waste (cut residual/seats), Sticky (do not switch), or blank if there is no thesis yet. Every tagged Focus needs a one-line Why with the mechanism and the live $, not a tag-only column. Most rows stay blank on purpose. Identified savings $ stay on slim Switch/Renegotiate/Waste tabs.

## Source rule 14

Vendor outreach drafts should be conversational and abbreviated, firm without being heavy-handed. Lead with the commercial ask and a summary comparison table (current vs option vs proposal), then the draft note for operator review.

## Source rule 17

When DMing colleagues for vendor data, always include enough commercial context that they can answer without knowing the renewal: what vendor, what window, what we pay or are licensed for, why the number matters. Do not assume they have procurement context.

## Source rule 19

Prefer vendor RFQs email-only and skip live demos when a public list price or written quote is enough.

## Source rule 20

In external vendor email drafts, use operations-team affiliation only if the operator confirms it is accurate; otherwise ask rather than fabricate a role.

## Source rule 22

Purpose, entity, EA/commit, and Focus tags are based on expense-system agreements, paid-bill memos, and cadence first. Vendor sheets often under-tag commitments; agreements and bills are the source of truth for commitments. Slack/Notion fill owners and usage only when they do not contradict expense data.

## Source rule 23

Vendor emails open "Hi <name>," on its own line (comma, no em dash), then a blank line, then the body. No hyphen or em dash after the greeting.

## Source rule 25

Vendor emails must never reference specific quote IDs or numbers. Do not use the line "We've been through [quote] with finance" or any variant that cites a quote identifier.

## Source rule 26

Notes to long-standing vendor partners should be friendly and collaborative. Work with them, do not command them. No bare imperatives. Acknowledge the working relationship in one clause.

## Source rule 27

Slack messages to vendors should not use the email "Hi <name>, blank line, body" format. Write them as normal Slack (e.g. "Hey <name>, ..." on the same line as the opener). The email greeting rule still applies to email only.

## Source rule 28

Core spend systems for this workflow: Ramp (cards/bills) and your ERP (for example NetSuite) when available for bills reconciliation. Google Sheets is the vendor database.
