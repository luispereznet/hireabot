---
name: score-savings-opportunity
description: "Use when apply the opportunity bar to one vendor."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "haggle-bot"}}
---

# score-savings-opportunity

When to use: Apply the opportunity bar to one vendor: $ traced to live data, specific mechanism, why now. Anything missing is a LEAD, not an opportunity.

Inputs: vendor dossier, live spend/period/currency, contract dates, usage and alternatives. Read ../references/working-notes.md.

1. Trace baseline dollars to current cards/bills or ERP evidence. Record date, period and currency; use a calculation tool for annualization or savings math, stating assumptions. No invented seats, discounts or renewal dates.
2. Identify a specific mechanism: competitive replacement, renegotiation, duplicate removal or unused seats. Waste requires measured utilization; a suspicion is not proof.
3. Establish why now from confirmed renewal window, usage change or quote. Default 120 days is a proposed priority rule until confirmed.
4. Require all three: traced dollars with math, mechanism, why now. Missing any means LEAD; name the smallest evidence request to qualify it. A qualified opportunity gets a sourced savings range and confidence, not a guarantee.
5. Calculate gross and net savings separately, including migration, overlap, term commitments and currency differences. Avoid double counting across opportunities. Use Focus plus one-line Why only when supported; retain a dated per-vendor dossier.
6. Propose the exact savings-tab row for review. Before approved Sheet write, verify destination and then run google-sheets-final-check.

Output: LEAD or OPPORTUNITY, evidence table, reproducible math, savings range/basis, mechanism, timing, switching risks and next decision. Never spend, sign, send a PO or contact anyone.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
