---
name: research-alternatives
description: "Use when find 3+ named alternatives tied to real usage with cited."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "haggle-bot"}}
---

# research-alternatives

When to use: Find 3+ named alternatives tied to real usage with cited, dated list and street pricing, honest switching cost, and an RFQ flag for quote-only vendors.

Inputs: actual vendor use cases, current contract/cost, must-have capabilities and constraints. Read ../references/working-notes.md.

1. Confirm real usage and non-negotiable features; ask one blocking question rather than substituting a generic category comparison.
2. Seek at least three named alternatives tied to those uses. If fewer are evidenced, report the shortfall rather than inventing candidates or claiming the bar is met.
3. For each alternative gather official list pricing, a buyer benchmark (such as Vendr, Tropic or Spendflo) and a real-buyer signal. Cite URLs and retrieval/as-of dates for every price or numeric claim. Separate list from street pricing and unverified marketing from buyer evidence.
4. Normalize plan, currency, seats, billing cadence, minimum commitments and included usage using a calculation tool. Do not assume seat counts or pretend quote-only pricing is public. Use a sourced benchmark range with confidence or mark RFQ required.
5. Assess feature gaps, security/procurement constraints, data migration, overlap, implementation and switching costs honestly. Compute a savings range against evidenced current spend; label unknown inputs and do not add overlapping savings.
6. Return comparison and recommended written RFQ questions. Prefer email-only quotes over demos where sufficient. RFQs remain drafts; no outreach or commitments.

Output: sourced dated comparison, list/street distinction, buyer signal, fit/gaps, net-savings basis and RFQ flags. Without web/tools, analyze supplied evidence and explicitly disclose unverified or missing sources.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
