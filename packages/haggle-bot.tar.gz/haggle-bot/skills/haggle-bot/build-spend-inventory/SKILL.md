---
name: build-spend-inventory
description: "Use when pull live spend from Ramp or an export."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "haggle-bot"}}
---

# build-spend-inventory

When to use: Pull live spend from Ramp or an export, dedupe vendors, tag purpose, owner, cadence, commitment, and Focus, and write the vendor database sheet.

Inputs: dated live cards/bills or supplied export, confirmed vendor Sheet, existing inventory. Read ../references/working-notes.md.

1. Confirm source scope and freshness; collect cards and bills. Reconcile ERP bills where available. Mark missing billing access instead of treating card absence as zero spend.
2. Normalize vendor aliases and currency/cadence. Dedupe by source transaction/bill identity; reconcile card payments against bills without double counting. Preserve source references in per-vendor dossiers, not a Source notes column.
3. Build rows: vendor, spend/period/currency, purpose, entity, owner, users, usage, cadence, EA/commit, renewal, sentiment, Focus and Why. Agreements, paid-bill memos and cadence outrank sheet labels for commitments. Scoped Slack/Notion may fill owners/usage, not override expense evidence; exclude project channels. Unknown stays Unknown.
4. Leave Focus blank without a thesis. Use Switch, Renegotiate, Waste or Sticky only with one-line Why including mechanism and live dollars. Waste requires utilization evidence. Keep identified savings on slim Switch/Renegotiate/Waste tabs; avoid overlapping savings.
5. Present the diff and exact destination for approval before a connected write; do not delete missing vendors. Write only approved cells, format dollars as currency, then load google-sheets-final-check and re-read live ranges.

Output: verified inventory/diff, dated dossiers, unresolved reconciliation items and renewals in confirmed window. If tools are absent, return a local table/CSV draft, clearly not a completed Sheet update.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
