---
name: offer-monthly-inventory-refresh
description: "Use after setup or when asked about routines: offer monthly inventory refresh."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "haggle-bot"}}
---

# Offer Monthly inventory refresh

What it does: Disabled by default. Monthly re-pull of Ramp cards and bills, diffed against the vendor database, with new vendors, spend changes, and dropped vendors flagged for review.

1. After completed or skipped setup, offer once, one question per reply. Read <active-profile>/workspace/routine-choice-monthly-inventory-refresh.md first. Do not reoffer if already offered, declined or enabled unless the user asks. Record offered before asking yes/no; a non-answer is not consent.
2. If declined, record declined and stop. On explicit yes confirm schedule/timezone, exact source scope, destination/field map, approval boundary and empty-result policy one question at a time. Suggested cron `0 9 1 * *` is not a user preference. Resolve scheduler clock/timezone and convert correctly; no invented timezone.
3. Keep job paused until all prerequisites and permissions are confirmed. For hiring signals also confirm private digest destination; default delivery remains local. Each actual send/post still needs explicit yes. Confirmed routine permission may authorize only exact in-scope normalized row writes; changes need reconfirmation.
4. List jobs, locate shipped ID `bb5f1fe96b44`, verify name/prompt, update that same job to the approved schedule and resume only with explicit yes. If missing, inspect for an equivalent name/prompt before creating exactly one. Never duplicate a job. If tools are missing disclose the blocker; do not claim activation.
5. Read back the exact job ID, schedule, enabled state and local delivery. Record enabled with its ID and timezone only after verification. Report approved schedule, scope and how to request pause/change. Do not delete records.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
