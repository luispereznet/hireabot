# Haggle Bot

Inventories your SaaS spend from Ramp and bills, finds evidence-backed savings (unused seats, duplicates, cheaper alternatives), and drafts vendor counters for 

## Install and open

```bash
hermes profile import haggle-bot.tar.gz
hermes -p haggle-bot setup
hermes -p haggle-bot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `haggle-bot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Inventories your SaaS spend from Ramp and bills, finds evidence-backed savings (unused seats, duplicates, cheaper alternatives), and drafts vendor counters for your review. Never spends, signs, or sends without you.

- **Haggle setup**
- **Build spend inventory**
- **Score savings opportunity**
- **Research alternatives**
- **Draft vendor counter**
- **Google Sheets final check**
- **Optional renewal window watch:** offered once after setup. It is only enabled if you say yes.
- **Optional monthly inventory refresh:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p haggle-bot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p haggle-bot`.

## Setup

- Import the native archive, run this bot's own AI setup and open the final imported name using Install and open above. No default-profile credentials or model choices are copied.
- Optional MCP declarations and sampling ship disabled. Select and independently verify a compatible server URL for each needed service, authentication and least-privilege scopes. Fill the matching blank variables in the local .env only; a URL alone does not authenticate. Enable only selected services after consent. No endpoint or account access is assumed.
- Available integrations: ramp, google-sheets, gmail, slack, notion, google-drive, granola, erp. ERP is an optional bills-reconciliation adapter, not assumed access. Sources absent from this list may use recipient-supplied exports/CSV/paste; no unavailable connector is claimed.
- All routine definitions ship disabled/paused with null next run and local delivery. Confirm timezone, scope, sources, fields, destination and empty-result policy before explicit yes to activation. Exact offer skills run once after completed/skipped setup; schedule suggestions are not saved user preferences.
- No user facts or neutral domain-fact seed were identified: MEMORY.md and USER.md are intentionally absent. Workflow rules live in referenced skills and behavior in SOUL. No send, post, buy, signature or financial commitment occurs without explicit yes; Haggle Bot never buys/signs/sends POs.
