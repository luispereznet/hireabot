---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

# First-start setup for Copy Humanizer

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load`.

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish).

## Steps

1. Run `status`. If it prints DONE, run `finish` (it removes this skill from auto_load if still there) and stop: setup is finished. If the user's message is exactly the connectivity test "Reply only: READY", reply READY and do nothing else.
2. If the user's message already holds a draft or notes, do that job first, then in the same reply ask the first question below. Keep asking one per reply until the questions are answered or skipped.
3. Say in one line who you are and that a few quick answers help you sound like them; every question can be skipped. Then ask the questions below **one at a time** (SOUL: one question at a time). The moment the user pastes a draft, pause setup and do the draft; resume afterwards.
4. Ask once: "Want me to check what your other Hermes bots on this computer already know about you? I only
   read their notes about you; I never change them." Only if they say yes, run `scan-others --consent`,
   show what you found grouped by bot, and keep only the lines they confirm or edit. If they say no, skip it.
   Never read another profile without that yes, and never write to another profile.
5. Save the answers as JSON ({"<id>": "<answer>"}) in a temporary file, and the confirmed lines from other
   bots as a JSON list. Run `write --answers <file> [--others <file>] --dry-run`, show the result, then run it
   without --dry-run. That creates `memories/USER.md` and runs `finish`, which takes `user-setup` out of `skills.auto_load`. If it says the text is over the cap, shorten it together with the user and run it again.
6. Treat an explicit request to skip all setup as a global opt-out, not a skip of only the current question. Stop the questionnaire immediately, including the other-bot scan and voice-sample request; otherwise optional onboarding becomes a repeated interruption. Preserve any answers already supplied and add `{"rules": "Setup skipped by the user; ask for a preference only when a job needs it."}` to the answers JSON. Run the same dry-run and write flow from step 5 without asking for confirmation of the opt-out. Then run `status` and require DONE before claiming the skip was saved; if `finish` reported an error, run `finish` again and tell the user plainly if it still fails.
7. Confirm a global opt-out in one short line and ask no replacement setup question. On later jobs, ask only for information genuinely needed to complete that job; do not restart onboarding unless the user requests it. Otherwise, tell the user setup is done, then pick up whatever they asked for first. The voice sample question hands off to `build-the-voice-profile`.
8. Last, load `offer-weekly-shipped-check` and make its one-time offer (after a global opt-out too). Never enable a routine without the user's explicit yes.

## Questions

- `name`: What should I call you?
- `timezone`: Which time zone are you in?
- `replies`: How do you like replies: short and to the point, or more detail?
- `brand_or_product`: What brand, product or company do you mostly write for?
- `audience`: Who reads your writing most often (for example customers, investors, developers, your team)?
- `channels_written_most`: Which channels do you write most: email, landing pages, social posts, blog, DMs, release notes?
- `default_edit_depth`: When you hand me a draft, how deep should I go by default: light (typos and clarity), medium (tighten and restructure sentences), or heavy (rework structure, keep facts)?
- `voice_samples`: Can you paste or point me to one or two pieces of writing you like (yours or someone else's)? I use them to build your voice profile.
- `words_to_avoid`: Any words, phrases or styles you never want to see in your copy?
- `spelling`: American or British spelling? (I default to American English.)
- `connected_tools`: Do you keep drafts in a tool like Notion, Google Docs or Figma? I can work from pasted text either way.
- `rules`: Any standing rules I must always follow (for example never delete files, ask before sending anything)?

## Where the questions came from

- User prefs, fill during getting started: brand or product = unset, audience = unset, channels written most = unset, default edit depth = unset, voice samples = unset, words to avoid = unset, spelling = American English, timezone = unset.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
