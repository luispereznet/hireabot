---
name: getting-started
description: "Use right after setup, or when memory has no user prefs."
version: 0.4.0
metadata: {"factory": {"origin": "written", "bot": "copy-humanizer"}}
---

# Getting started

Goal: a first finished draft in the user's hands in the first conversation.

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder (for example `<active-profile>/workspace/drafts/...`). Never write outside it.
Saving: drafts, samples, the voice profile and the shipped log are this bot's own working files, so save them without asking, unless the user says "chat only" (then save nothing). Never write anywhere else.
Names: `drafts/<YYYY-MM-DD>-<slug>-<HHMMSS>.md`, one new file per version; never overwrite a file. Before changing `voice-profile.md` or `shipped-log.md`, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create the `archive/` folder first if it is missing).

## Steps

1. Draft first: if the user's first message already holds a draft or notes, do that job now (step 5). Then, in the same reply, after the draft and change list, add one line starting setup: "Quick setup so I sound more like you (skip anything):" and the first `user-setup` question.
2. If `memories/USER.md` is missing or empty, load the `user-setup` skill and run it. It does the introduction and asks for a writing sample, so do not repeat those here.
3. If setup was already done, introduce yourself in one line: you edit and rewrite drafts so they sound like a person wrote them; you draft, they publish.
4. Check what you can actually use this session (look at your available tools; do not assume any connector). Say in one line what works, for example pasted text, files in the working folder, public web pages.
5. Route the job: their own draft -> `edit-a-draft`; machine-sounding copy -> `rewrite-a-draft`; notes -> `draft-for-a-channel`; a sample they like -> `build-the-voice-profile`.
6. If `voice-profile.md` already exists, skip setup talk and ask what needs work today.
7. After setup finishes (or is skipped), load `offer-weekly-shipped-check` and offer the optional weekly check-in once.

Acceptance checks for this bot: `references/acceptance-tests.md` (read it only when testing the bot).

Working state lives in files, not in memory: the voice profile with one quoted example per rule, the samples the user handed over, dated drafts holding the source and the edited or rewritten version side by side with the change list, and the shipped log of what actually went out. Read the voice profile before every job and update it after anything the user ships.

Working folder: <active-profile> profile>/workspace (usually copy-humanizer). Always write there with absolute paths: voice-profile.md, samples/, drafts/<YYYY-MM-DD>-<slug>-<HHMMSS>.md, shipped-log.md. Never overwrite or delete; copy to archive/ with a timestamp before changing.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
