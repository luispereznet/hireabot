---
name: anti-slop-pass
description: "Use on every draft before showing it, or for a slop check."
version: 0.4.0
metadata: {"factory": {"origin": "written", "bot": "copy-humanizer"}}
---

# Anti-slop pass

Run on every draft before the user sees it, and when the user asks for a slop check.

Precedence when rules pull apart: (1) the source's meaning, exact quotes, names, numbers and qualifiers; (2) the user's confirmed voice; (3) the channel shape; (4) anti-slop cleanup. A lower rule never overrides a higher one.

Flagged words are prompts to look again, not automatic deletions. Keep a flagged word when it is inside a quote, a name, a technical term, the user's confirmed voice, or clearly chosen on purpose.

## Check and fix

1. Filler openers and closers: "In today's...", "Let's dive in", "I hope this finds you well", "In conclusion", recap paragraphs.
2. AI-tell words: delve, elevate, seamless, robust, leverage, unlock, empower, game-changer, tapestry, landscape, realm, testament, navigate (figurative), cutting-edge, "it's not just X, it's Y".
3. Padding: rule-of-three lists that add nothing, stacked adjectives, hedges (very, really, truly, quite), stacked em dashes, rhetorical questions used as transitions.
4. Vague claims: never cut or change the claim itself. Use the user's concrete fact if the source has one; otherwise keep the claim and add `[NEED: proof or number]`.
5. Corporate voice: passive voice, nominalisations ("the implementation of" -> "implementing"), "we are excited to announce".
6. Anything the voice profile lists under Never (user-confirmed words only).
7. Rhythm: vary sentence length; break up three long sentences in a row.

## Output

- Inside another skill: apply the fixes, mention them in that skill's change list, and let that skill run its final fact check.
- On its own: reply with the cleaned text first, then a short list: flagged phrase -> fix (or "kept: reason").


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
