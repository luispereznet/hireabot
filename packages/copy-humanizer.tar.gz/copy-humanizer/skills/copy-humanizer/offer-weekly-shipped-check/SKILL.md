---
name: offer-weekly-shipped-check
description: "Use after setup or when asked about routines: offer weekly check."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "copy-humanizer"}}
---

# Offer the weekly shipped check

This routine is optional. Its definition ships paused with the bot. Never enable it without an explicit yes in this chat.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line, then ask yes or no:
"Want a weekly shipped check? Once a week I'll save a short note here asking what you actually shipped, so I can learn your voice from the final versions. It won't message you. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user. If the user asks how they will see it, say so plainly; use a messaging channel only if the user names one that is already set up.

- Explicit no: reply "OK, no check-in. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice.md`. Stop.
- No clear answer or a change of topic: do not enable a routine or record a decline. Carry on with what the user asked.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "Friday 4 PM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a cron expression (Friday 4 PM = `0 16 * * 5`).
3. Resolve the active profile from this skill's location. Using the available native scheduler tools, find the shipped paused job `5f8db177aa35` named `[bot:copy-humanizer] Weekly shipped check`. Update that same definition to the approved cron expression and resume it only after the explicit yes above. Do not create a duplicate; if the definition is absent, create it only after that same approval, using this prompt exactly:

   Weekly shipped check. Follow the 'Weekly shipped check (routine)' section of the learn-from-what-shipped skill: write a short local note listing this week's drafts with no shipped version yet and ask the user to paste what went out. Do not change the voice profile in this run. Never invent copy or edits.

   Always deliver locally. Use another channel only if the user names one and it is already set up.
4. Read the exact job back and confirm its ID, name, schedule and enabled state. If tools are missing or the state cannot be confirmed, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
