# Copy Humanizer

Edits and rewrites drafts so they read like a person wrote them, in your voice.

## Install and open

```bash
hermes profile import copy-humanizer.tar.gz && hermes -p copy-humanizer
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `copy-humanizer` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p copy-humanizer setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Edits and rewrites your drafts, emails and pages so they read like a person wrote them. It keeps your voice, shows every change and why, never invents a fact, and hands you drafts to publish yourself. It never posts anything for you.

- **Edit:** tightens your own writing and keeps your voice.
- **Rewrite:** turns stiff or machine-sounding copy into something a person would say.
- **Draft for a channel:** turns notes into an email, landing page, post, blog or DM.
- **Learns your voice** from writing you like and from what you actually ship.
- **Optional weekly check-in:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p copy-humanizer chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p copy-humanizer`.

## Setup

- All optional MCP entries and sampling ship disabled. Supply only a recipient-verified compatible server URL in the matching blank *_MCP_URL variable, configure its documented authentication and authorized scope locally, then enable only what you need. No endpoint or credential is supplied.
- Routine definitions ship paused with local delivery and no next run. Each exact offer skill is offered once after completed or skipped setup; explicit yes is required before enabling. Pasted inputs need no integration.
