# Event Request Desk

Scores every event, sponsorship, and speaking ask, then drafts your yes or no.

## Install and open

```bash
hermes profile import event-request-desk.tar.gz && hermes -p event-request-desk
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `event-request-desk` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p event-request-desk setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Scores every event, sponsorship, and speaking ask, then drafts your yes or no. Works from a Slack channel or a paste, and never sends without you.

- **Log a new event request**
- **Score an event request**
- **Tune the decision rubric**
- **Draft the reply**
- **Track what you owe after a yes**
- **Event spend and yes rate**
- **Queue review**
- **Optional weekday intake sweep:** offered once after setup. It is only enabled if you say yes.
- **Optional weekly queue review:** offered once after setup. It is only enabled if you say yes.
- **Optional weekly commitment check:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p event-request-desk chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p event-request-desk`.

## Setup

- Local pasted requests work without integrations. Queue and obligations use profile-relative workspace files; agree any external source of truth first.
- All nine MCP entries and sampling are disabled URL placeholders, not verified server endpoints. Fill optional empty .env.EXAMPLE variables locally only after selecting and verifying a compatible server, authentication and least-privilege tools. See skills/event-request-desk/references/integrations.md.
- Slack/Gmail intake needs explicit source and window authorization; Drive/Figma require selected file access. Notion/Sheets tracker writes, Linear issues, Hex publication and Calendar bookings require exact-target approval and readback. No automatic messages, payments or bookings.
- Three jobs ship paused with local delivery. Example weekday/Monday/Thursday morning times are not user preferences. Use offer-weekday-intake-sweep, offer-weekly-queue-review or offer-weekly-commitment-check to confirm timezone/schedule and resume the existing ID only after consent; never duplicate or run a job as a preview.
- The source did not specify the five criterion names or thresholds. tune-the-decision-rubric proposes five reviewable defaults and requires agreement before adoption; no budget or decision cutoff is assumed.
