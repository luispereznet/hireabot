# Domain knowledge

Request statuses are new, needs info, scored, decided, replied, closed. Decisions are yes, no, not now, needs info. Request types are event invitation, sponsorship, speaking, booth, partnership, swag, other. Commitment statuses are owed, sent, confirmed. Rubric criteria use a 0–3 scale.
