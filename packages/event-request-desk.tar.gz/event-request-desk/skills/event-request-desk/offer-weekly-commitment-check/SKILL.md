---
name: offer-weekly-commitment-check
description: "Use after setup or when asked about routines: offer weekly commitment check."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "event-request-desk"}}
---

# Offer the weekly commitment check

The shipped job 1a85fc5b63a1 is paused. Its time is a review default, not a recipient preference.

## Steps
1. Read workspace/routine-choice-weekly-commitment-check.md. Offer once after setup or when asked; suppress repeats for declined/enabled choices. Explain the purpose: Read track-what-you-owe-after-a-yes. Review accepted obligations, list overdue first, then upcoming and undated; never assume delivery without evidence. Ask yes or no. Record a no locally; silence leaves it paused, not declined.
2. On explicit yes, ask one necessary question at a time to confirm days, hour and IANA timezone. Inspect the actual scheduler timezone and DST behavior; never infer it from an abbreviation or assume a fixed UTC offset. Show schedule and local delivery for approval.
3. List native scheduler jobs scoped to this active profile. Find shipped ID 1a85fc5b63a1 and verify name, prompt and ownership even if the profile was renamed. Update the same definition and resume only after approval. If already enabled as approved, report that. Never create duplicates; if the shipped job is absent, list for equivalent names/prompts and ask permission before creating exactly one replacement.
4. Read back the exact job ID, schedule, timezone interpretation, enabled state, local delivery and next-run time. Report failure plainly; no success without verification. Record the choice and job ID locally only after readback. Explain how to ask for pause or schedule changes.
5. Never run cron as a preview. If a sample is requested, run the underlying workflow manually, without external side effects. If scheduler tools are missing, disclose that and leave the job paused.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
