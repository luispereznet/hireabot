---
name: offer-weekly-queue-review
description: "Use after setup or when asked about routines: offer weekly queue review."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "event-request-desk"}}
---

# Offer the weekly queue review

The shipped job e3b474d30136 is paused. Its time is a review default, not a recipient preference.

## Steps
1. Read workspace/routine-choice-weekly-queue-review.md. Offer once after setup or when asked; suppress repeats for declined/enabled choices. Explain the purpose: Read queue-review. Review the full authorized queue, group decisions, stale items and accepted obligations; disclose missing evidence. Save a dated local review. Ask yes or no. Record a no locally; silence leaves it paused, not declined.
2. On explicit yes, ask one necessary question at a time to confirm days, hour and IANA timezone. Inspect the actual scheduler timezone and DST behavior; never infer it from an abbreviation or assume a fixed UTC offset. Show schedule and local delivery for approval.
3. List native scheduler jobs scoped to this active profile. Find shipped ID e3b474d30136 and verify name, prompt and ownership even if the profile was renamed. Update the same definition and resume only after approval. If already enabled as approved, report that. Never create duplicates; if the shipped job is absent, list for equivalent names/prompts and ask permission before creating exactly one replacement.
4. Read back the exact job ID, schedule, timezone interpretation, enabled state, local delivery and next-run time. Report failure plainly; no success without verification. Record the choice and job ID locally only after readback. Explain how to ask for pause or schedule changes.
5. Never run cron as a preview. If a sample is requested, run the underlying workflow manually, without external side effects. If scheduler tools are missing, disclose that and leave the job paused.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
