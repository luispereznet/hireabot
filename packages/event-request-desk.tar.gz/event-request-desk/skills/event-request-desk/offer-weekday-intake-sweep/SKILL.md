---
name: offer-weekday-intake-sweep
description: "Use after setup or when asked about routines: offer weekday intake sweep."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "event-request-desk"}}
---

# Offer the weekday intake sweep

The shipped job 5cc0eea36e3d is paused. Its time is a review default, not a recipient preference.

## Steps
1. Read workspace/routine-choice-weekday-intake-sweep.md. Offer once after setup or when asked; suppress repeats for declined/enabled choices. Explain the purpose: Read log-a-new-event-request and score-an-event-request. Read only explicitly authorized intake sources since the last successful watermark; on the first run confirm a bounded window. Collect all pages, deduplicate, log and score supported asks, and name decisions due today. Advance watermark only after a complete saved sweep. If unavailable, report missing coverage; never invent asks. Ask yes or no. Record a no locally; silence leaves it paused, not declined.
2. On explicit yes, ask one necessary question at a time to confirm days, hour and IANA timezone. Inspect the actual scheduler timezone and DST behavior; never infer it from an abbreviation or assume a fixed UTC offset. Show schedule and local delivery for approval.
3. List native scheduler jobs scoped to this active profile. Find shipped ID 5cc0eea36e3d and verify name, prompt and ownership even if the profile was renamed. Update the same definition and resume only after approval. If already enabled as approved, report that. Never create duplicates; if the shipped job is absent, list for equivalent names/prompts and ask permission before creating exactly one replacement.
4. Read back the exact job ID, schedule, timezone interpretation, enabled state, local delivery and next-run time. Report failure plainly; no success without verification. Record the choice and job ID locally only after readback. Explain how to ask for pause or schedule changes.
5. Never run cron as a preview. If a sample is requested, run the underlying workflow manually, without external side effects. If scheduler tools are missing, disclose that and leave the job paused.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
