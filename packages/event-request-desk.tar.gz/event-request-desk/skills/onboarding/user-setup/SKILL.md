---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

# First-start setup for Event Request Desk

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load`.

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish).

## Steps

1. Run `status`. If it prints DONE, run `finish` (it removes this skill from auto_load if still there) and stop: setup is finished. If the user's message is exactly the connectivity test "Reply only: READY", reply READY and do nothing else.
2. If the user's message already asks for real work, do that job first, then in the same reply ask the first question below. Keep asking one per reply until the questions are answered or skipped.
3. Say in one line who you are and that a few quick answers help you work well; every question can be skipped. Then ask the questions below **one at a time**. If the user hands you real work, pause setup, do the work, then resume.
4. Ask once: "Want me to check what your other Hermes bots on this computer already know about you? I only
   read their notes about you; I never change them." Only if they say yes, run `scan-others --consent`,
   show what you found grouped by bot, and keep only the lines they confirm or edit. If they say no, skip it.
   Never read another profile without that yes, and never write to another profile.
5. Save the answers as JSON ({"<id>": "<answer>"}) in a temporary file, and the confirmed lines from other
   bots as a JSON list. Run `write --answers <file> [--others <file>] --dry-run`, show the result, then run it
   without --dry-run. That creates `memories/USER.md` and runs `finish`, which takes `user-setup` out of `skills.auto_load`. If it says the text is over the cap, shorten it together with the user and run it again.
6. Treat an explicit request to skip all setup as a global opt-out, not a skip of only the current question. Stop the questions and the other-bot scan at once. Keep any answers already given, add `{"rules": "Setup skipped by the user; ask for a preference only when a job needs it."}` to the answers JSON, and run the step 5 dry-run and write without asking again. Then run `status` and require DONE before saying the skip was saved; if `finish` reported an error, run `finish` again and tell the user plainly if it still fails.
7. Confirm a global opt-out in one short line and ask no replacement question. Later, ask only for what a job really needs; do not restart setup unless the user asks. Otherwise tell the user setup is done, then pick up whatever they asked for first.
8. After setup or a global opt-out, use getting-started to produce the first result. Offer routines one per reply, never all at once. Load `offer-weekday-intake-sweep`, then `offer-weekly-queue-review`, then `offer-weekly-commitment-check` and make each one-time offer (after a global opt-out too). Never enable a routine without the user's explicit yes; use the shipped job rather than duplicating it.

## Questions

- `name`: What should I call you?
- `timezone`: Which time zone are you in?
- `replies`: How do you like replies: short and to the point, or more detail?
- `morning_sweep_hour`: What local hour would suit an optional weekday intake sweep?
- `event_types_tracked`: Which types of event or sponsorship asks should I track?
- `intake_sources`: Where will event asks come from (paste, email, channel or files)?
- `rubric`: Do you have decision criteria, or should I propose five for review?
- `spend_cap`: Is there a per-event spend cap, and in which currency?
- `period_budget`: What event budget and reporting period should I use, if any?
- `blackout_weeks`: Are there weeks when event participation is off limits?
- `travel_limit`: What travel limits should event decisions respect?
- `approver`: Who makes the final event decision?
- `reply_tone_and_signer`: What tone and signer should reply drafts use?
- `queue_lives`: Should the queue stay in local files or use an authorized team tracker?
- `rules`: Any standing rules I must always follow (for example never delete files, ask before sending anything)?


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
