# Ad Spend Watch

Watches your ad spend and performance and flags what's breaking before it burns budget.

## Install and open

```bash
hermes profile import ad-spend-watch.tar.gz && hermes -p ad-spend-watch
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `ad-spend-watch` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p ad-spend-watch setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Watches your ad spend and performance and flags what's breaking before it burns budget. Works from a pasted export, and never pauses a campaign without your yes.

- **Set accounts and thresholds**
- **Read an ad platform export**
- **Pull numbers from a connected source**
- **Run the spend and performance check**
- **Diagnose what broke**
- **Check budget pace**
- **Write the fix list**
- **Answer a spend question**
- **Optional daily spend and performance check:** offered once after setup. It is only enabled if you say yes.
- **Optional midday burn check:** offered once after setup. It is only enabled if you say yes.
- **Optional weekly budget pace check:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p ad-spend-watch chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p ad-spend-watch`.

## Setup

- slack: ships disabled with sampling off; supports approved alert and fix-list delivery. Supply your own verified endpoint via AD_WATCH_SLACK_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- notion: ships disabled with sampling off; supports approved threshold/check/alert storage. Official Notion OAuth endpoint is https://mcp.notion.com/mcp; authorize your account and enable only this profile connection after consent.
- linear: ships disabled with sampling off; supports approved engineering fix tickets. Supply your own verified endpoint via AD_WATCH_LINEAR_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- hex: ships disabled with sampling off; supports read-only warehouse spend queries. Supply your own verified endpoint via AD_WATCH_HEX_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- datadog: ships disabled with sampling off; supports read-only site availability evidence. Supply your own verified endpoint via AD_WATCH_DATADOG_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- sentry: ships disabled with sampling off; supports read-only checkout error evidence. Supply your own verified endpoint via AD_WATCH_SENTRY_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- figma: ships disabled with sampling off; supports read-only creative evidence. Supply your own verified endpoint via AD_WATCH_FIGMA_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- gmail: ships disabled with sampling off; supports read-only emailed ad reports. Supply your own verified endpoint via AD_WATCH_GMAIL_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- google-sheets: ships disabled with sampling off; supports read-only spend sheets. Supply your own verified endpoint via AD_WATCH_GOOGLE_SHEETS_MCP_URL in this profile’s local .env and follow that service’s secure authentication setup before enabling. Endpoint/auth availability is unverified; no package is installed.
- Three jobs ship PAUSED: weekday daily 08:00, weekday midday 12:00 and Monday pace 08:00, expressed in the host clock until reviewed. Use the matching offer skill to confirm timezone, scope, freshness and model cost before resuming; never duplicate-create or cron run a preview.
- Work from a paste/export without any integration. Account preferences are unset, with optional paste/weekends-off/local delivery defaults. No secrets, provider/model choice or user history ship. External delivery and Notion/Linear writes require approval and readback.
