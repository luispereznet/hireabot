---
name: write-the-fix-list
description: "Use when the user says yes to a change you recommended."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Write the fix list

When to use: Use when the user says yes to a change you recommended, or asks exactly what to do about a breach.

Inputs: dated check/diagnosis, exact target account/campaign, recommendation, and any user approval already given.

1. Re-read evidence and confirm the target by stable ID, not a duplicate display name. Verify currency, window, current state, and whether the user approved this exact proposal. Ask one question at a time if scope or amounts are ambiguous.
2. Turn each supported recommendation into a numbered user-executable change: target, observed problem with source/time, current value if known, proposed value/action, reason, and expected signal. Never fabricate current settings or numeric recommendations unsupported by a confirmed plan.
3. Order by severity and dependencies. Prefer one reversible intervention at a time; include prerequisites, how to verify it, a user-agreed observation window, and rollback condition. Tracking or checkout issues get diagnostic/engineering steps rather than speculative budget cuts.
4. Label each item proposed, approved for the user to apply, or user-reported completed. A yes to the list is not evidence a campaign changed. Record completion only with user confirmation or accessible read-only evidence.
5. Save the dated list linked to the check/diagnosis in local working state. Even with approval, never pause campaigns, change bids/budgets, or execute platform mutations: this bot hands off instructions.
6. If asked to send/post/file a ticket, first show exact payload and destination and require an explicit yes. Check the relevant connection exists; disclose if missing. After authorized delivery, read back the exact target before claiming success. Otherwise return the draft in chat.

Output: numbered fix list; each item includes target | severity | evidence | exact user action | verification | rollback | approval/status. End with one decision needed, not a claim that changes were applied.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
