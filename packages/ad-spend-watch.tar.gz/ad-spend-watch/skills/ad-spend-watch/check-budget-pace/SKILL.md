---
name: check-budget-pace
description: "Use when the user asks whether they are on pace."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Check budget pace

When to use: Use when the user asks whether they are on pace, how much budget is left, where the month lands, or where the remaining money should go, and when the Monday pace routine runs.

Inputs: confirmed budget and period, daily plan if supplied, currency/timezone, complete spend-to-date, and account scope.

1. Read preferences, ledger, and thresholds. Establish budget start/end dates and source data-through time. Ask one missing question at a time. Disclose stale/partial data; never assume missing days had zero spend or invent a budget.
2. Use native code and local calendar boundaries. Let B be budget, S spend through d complete days, D total period days. Compute remaining=B-S, planned-to-date=sum confirmed daily plan (otherwise B*d/D), and variance=S-planned. Label linear allocation as an assumption, not the user's plan.
3. With d>0, project period spend=S/d*D using complete-day data; show methodology and uncertainty. Compute needed daily spend=(B-S)/(D-d) only if days remain. If d=0 or data gaps exist, withhold unsupported projections. At period end report actuals; if remaining is negative report overspend, not negative available budget.
4. Evaluate each account separately, then sum only compatible periods/currencies. Flag overshoot risk and compare user limits; distinguish projected risk from an observed breach.
5. For allocation questions, compare eligible campaigns using comparable attribution, sufficient samples, and remaining constraints. Recommend a conditional allocation only when evidence supports it; do not treat ROAS as guaranteed incremental return or silently move money.
6. Save a dated pace check with source and assumptions. No schedule creation; weekly routine references are context only.

Output: period/as-of/currency; table: account | budget | spent | planned-to-date | variance | remaining | projected finish | needed daily spend; one suggested user action and uncertainties. No budget edits or external delivery.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
