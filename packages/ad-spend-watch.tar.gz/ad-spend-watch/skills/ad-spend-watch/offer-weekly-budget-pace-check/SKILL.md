---
name: offer-weekly-budget-pace-check
description: "Use after setup or when asked about routines: offer weekly budget pace check."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "ad-spend-watch"}}
---

# Offer the weekly budget pace check

Inputs: explicit opt-in, approved account/source/thresholds, user timezone and shipped job ef2ef1f6b13b.

1. Offer this optional routine once after setup or on request. Read workspace/routine-choice-weekly-budget-pace-check.md first; do not repeat declined/accepted offers unless asked. Ask one question at a time. No clear yes leaves it paused, not installed afresh.
2. Verify real read access and required coverage, confirmed accounts, currency, thresholds and timezone. A scheduled fetch requires a verified source; if only a paste exists, explain the freshness limit and leave paused until the user agrees a workable input plan. Explain local delivery and future model usage/cost. Missing tools are a blocker; never invent access.
3. Resolve the actual installed profile from this skill's ancestor with SOUL.md and skills/. For named profiles set HERMES_HOME to its containing Hermes root and use its actual import name. Inspect `hermes -p <actual-name> cron list`; match job ef2ef1f6b13b and check equivalent duplicates. Never create a second job. If the shipped definition is missing, report it and ask for approved repair.
4. Review the saved five-field schedule `0 8 * * 1` against the user's time zone, day/time and DST. It uses the host clock until deliberately configured otherwise. Read local help before any supported schedule update, obtain explicit approval, and verify changed schedule before resuming. Do not silently assume timezone conversion.
5. Only after explicit approval and prerequisites, run `hermes -p <actual-name> cron resume ef2ef1f6b13b`. List again and verify exact ID, schedule, enabled state and next run before reporting success. Never use cron run as a preview. If anything disagrees, disclose it, not a successful setup.
6. On explicit pause/cancel use `hermes -p <actual-name> cron pause ef2ef1f6b13b`, list again and verify paused/disabled. Pause instead of delete. Save consent, scope, timezone, actual job state and offer choice in this profile's workspace.

Output: actual job ID, verified state, approved schedule/timezone, local delivery and unmet requirements. Never mutate campaigns, send/post externally without approval, install plugins or make paid service calls. Never invent results.
