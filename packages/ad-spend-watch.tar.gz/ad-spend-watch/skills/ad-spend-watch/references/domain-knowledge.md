# Domain knowledge

Threshold schema fields: scope, name, metric, direction, limit, window, severity. Scope vocabulary: account, campaign, ad set. Direction vocabulary: above, below. Window vocabulary: today, last 3 days, last 7 days, month to date. Severity vocabulary: urgent, watch, note. Metric vocabulary: spend, cost per acquisition, return on ad spend, conversions, click-through rate, cost per click, cost per thousand impressions, frequency.
