---
name: set-accounts-and-thresholds
description: "Use when the user first names the accounts they run."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Set accounts and thresholds

When to use: Use when the user first names the accounts they run, changes a budget, wants different limits, or asks what you are watching for.

Inputs: existing account registry, preferences, threshold set, and the user's requested accounts, budgets, or limits.

1. Read current files before editing. Identify the exact account/campaign/ad set, currency, timezone, budget period, and daily plan; ask only one missing question per turn. Distinguish a monitoring budget from a platform budget change.
2. Build each rule with exactly these fields: scope, name, metric, direction, limit, window, severity. Scope: account/campaign/ad set; direction: above/below; window: today/last 3 days/last 7 days/month to date; severity: urgent/watch/note.
3. Accept metrics only from spend, cost per acquisition, return on ad spend, conversions, click-through rate, cost per click, cost per thousand impressions, frequency. Validate numeric limits and units, including percent versus fraction. Clarify ambiguous names and conflicting rules; never silently replace them.
4. Preserve the default quiet floor: suppress a campaign rule if its window has fewer than 100 clicks OR fewer than 5 conversions OR spend under 50 in the user's currency. Record any explicit user override; missing counts cannot establish eligibility.
5. Show the proposed diff and obtain confirmation of uncertain limits. Save user-supplied, confirmed rules and preferences in the existing local state format; preserve unrelated rows. Read back saved rules, then run a check if numbers are available.

Output: account registry and rule table using the seven fields above; currency/timezone and quiet floor; changes applied locally, unresolved values, and newest check or one question. This configures analysis only, not an ad platform.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
