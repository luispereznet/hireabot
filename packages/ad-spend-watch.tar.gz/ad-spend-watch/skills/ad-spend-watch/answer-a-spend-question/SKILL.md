---
name: answer-a-spend-question
description: "Use when the user asks a direct question about their numbers."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Answer a spend question

When to use: Use when the user asks a direct question about their numbers, like what a campaign cost last week or which one has the best return.

Inputs: direct question, account scope, requested period/metric, ledger, and source metadata.

1. Read existing preferences and ledger. Resolve account identifiers and dates in the user's timezone; “last week” means the previous complete calendar week, with boundaries stated. Ask one question if ambiguity changes the answer; do not repeat known preferences.
2. Find the exact data needed. Refresh through an available authorized read source or parse a supplied export. If tools/connections or dates are missing, disclose the gap and request a targeted export instead of guessing. Do not present stale numbers as current.
3. Filter and calculate with native code. Sum spend/conversions/revenue and derive ratios from totals, never average row CPA/ROAS. Handle zero denominators as undefined, missing cells as unknown, overlapping rows as duplicates, and currencies separately.
4. For rankings compare the same period, attribution basis, currency, and coverage. Apply the recorded quiet floor to campaign claims; label excluded/low-sample campaigns. “Best return” requires observed revenue and spend, not an invented profitability or causal claim.
5. Answer the narrow question first with units, date range, data-through timestamp, source, and calculation. If thresholds are relevant, route to the check skill; if why is asked, route to diagnosis; if pace is asked, route to check-budget-pace. Avoid turning a simple query into weekly reporting.
6. Preserve ledger provenance if refreshed; save a dated calculation only when it forms part of a check. No campaign changes or background schedules.

Output: one-sentence answer; compact supporting table if needed (account/campaign | period | metric | value | source); coverage/assumptions; at most one follow-up question. Never invent missing values, causes, or evidence.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
