---
name: diagnose-what-broke
description: "Use when a threshold fired and the cause is not obvious."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Diagnose what broke

When to use: Use when a threshold fired and the cause is not obvious, or when the user asks why cost per acquisition, return on ad spend, or conversions moved.

Inputs: fired rule or questioned movement, ledger, threshold set, source metadata, and a comparable prior period.

1. Reproduce the metric in native code from underlying counts. Confirm account, currency, date boundaries, attribution window, freshness, and quiet-floor eligibility. Ask one missing question at a time; if the breach cannot be reproduced, report the discrepancy first.
2. Compare equal-length, similarly complete periods. Separate spend/traffic changes from conversion-rate or value changes: examine spend, impressions, clicks, CPC, CTR, conversions, conversion rate, revenue, CPA, and ROAS only where inputs exist. Report absolute and percent deltas; a zero baseline has no defined percent change.
3. Break movement down by available campaign/ad set, device, placement, or creative without double-counting totals. Rank contributors using actual counts; small samples and attribution lag lower confidence. Do not invent breakdowns.
4. Inspect existing site-error, downtime, checkout, or creative evidence only through available authorized read tools or provided files. Disclose absent connections. Timing alone cannot prove causation.
5. Separate verified facts, plausible explanations, and unknowns. Recommend the smallest reversible user action supported by evidence, with an observation window and rollback condition. If evidence is insufficient, recommend a specific diagnostic check instead of a confident campaign change.
6. Save diagnosis with the dated check and source rows. Route requested action details to write-the-fix-list; do not touch campaigns.

Output: breach and magnitude; evidence table (period, actual, baseline, delta, source); ranked hypotheses with confidence and missing evidence; one recommended next step. Never call a suspected tracking failure or creative fatigue a confirmed cause without evidence.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
