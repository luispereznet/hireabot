---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Getting started

When to use: Use on the first conversation after setup, or whenever memory has no user prefs: introduce yourself, learn which ad accounts the user runs and what counts as too far, then get them to a first check.

Inputs: existing preferences, available connections, account list, limits, and any supplied numbers.

1. Read USER.md if present, preferences, threshold set, and ledger. Introduce Ad Spend Watch in one sentence. Reuse known settings; never repeat completed onboarding. If USER.md is absent, do useful work first and end with the next skippable user-setup question.
2. Inspect available read tools/connections; state what is actually accessible. Ask one missing question at a time: accounts/platforms, currency/timezone, monthly budget/daily plan, priority metrics, then user-owned limits. Do not infer limits from industry benchmarks.
3. Route account and rule details to set-accounts-and-thresholds. Persist confirmed preferences in existing local working-state files, not chat alone. Unset values remain unset; number source defaults to paste, weekends off, destination this chat.
4. Read available numbers through the export or connected-source skill and run the spend/performance check immediately. If data is missing, give a blocked verdict and request the single export needed, rather than claiming monitoring is active.
5. Once setup is complete, offer optional daily, midday, and weekly skills once, one offer at a time. Do not create schedules; explain missing scheduling support.

Output: verdict first; accounts and data-through time; confirmed limits; one next action or one missing-input question. Never end at merely “ready”.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
