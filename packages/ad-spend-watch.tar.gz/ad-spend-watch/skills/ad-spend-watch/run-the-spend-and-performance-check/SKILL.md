---
name: run-the-spend-and-performance-check
description: "Use when the user asks whether anything is off, right after new numbers land."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ad-spend-watch"}}
---

# Run the spend and performance check

When to use: Use when the user asks whether anything is off, right after new numbers land, or when the daily check routine runs.

Inputs: threshold set, numbers ledger, account preferences, user timezone, and latest source coverage.

1. Re-read threshold and ledger files before every check. Refresh via `pull-numbers-from-a-connected-source` if available; otherwise use supplied exports. State stale/partial coverage and unavailable tools. Never imply background monitoring.
2. Resolve today, last 3 days, last 7 days, and month to date in the user's timezone with code. Include today in rolling calendar windows; label partial days. If timezone or reporting basis is unknown, ask one question rather than mix boundaries.
3. Aggregate each rule's scope/window with native code. Sum components then derive ratios; undefined denominators and absent fields are unknown, not zero. Never combine currencies or incompatible attribution bases.
4. Apply the quiet floor to campaign rules: suppress if clicks<100 OR conversions<5 OR spend<50 in user currency, unless the user recorded an override. Missing floor inputs mean insufficient evidence. Compare strict above/below limits only after eligibility is established.
5. Rank breaches urgent, watch, note. For each show observed metric, limit, window, evidence source, and one recommended change. Route unexplained movement to diagnose-what-broke. No rules means “not configured”, not “healthy”; no data means “not assessed”.
6. Save a dated check with evaluated/suppressed/unknown rows and source timestamps. Write back validated threshold/ledger state without discarding history. Record alerts locally and deduplicate against the same rule/window/evidence; external delivery needs explicit yes.

Output: verdict first; as-of and coverage; table: scope | metric/window | actual | limit | severity | evidence | recommended action. End with gaps and one next action. Only say no breaches for rules actually evaluated.

Guardrails: Ask one question at a time. Never invent evidence. Native tools only; no installs, paid calls, or cron. Disclose missing tools/connections. Never mutate campaigns. Explicit yes before send/post/buy. No personal data or marketplace/creator names in public text.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
