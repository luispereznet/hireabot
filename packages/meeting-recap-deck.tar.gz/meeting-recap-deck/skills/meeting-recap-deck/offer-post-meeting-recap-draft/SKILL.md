---
name: offer-post-meeting-recap-draft
description: "Use after setup or when asked about routines: offer post-meeting recap draft."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "meeting-recap-deck"}}
---

# Offer the post-meeting recap draft

This routine is optional. Its native definition ships paused. Never enable it without an explicit yes in this chat.

What it does: Every weekday at 5 PM, drafts a recap for any new meeting notes from today and leaves them here for you to check.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-post-meeting-recap-draft.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the post-meeting recap draft? Every weekday at 5 PM, drafts a recap for any new meeting notes from today and leaves them here for you to check. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-post-meeting-recap-draft.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays, 5 PM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 17 * * 1-5`).
3. Resolve this active profile from the loaded skill location. Use the native scheduler tools scoped to this profile to update the shipped paused job `fb1b3c7b2426` (`[bot:meeting-recap-deck] Post-meeting recap draft`) to the agreed cron expression, then resume that same job only after the explicit yes. Do not create a duplicate. If scheduler tools are unavailable, explain that it remains paused.

   Deliver locally. Use another channel only if the user names one and it is already set up.
4. Read that exact job back with the native scheduler tools and confirm the ID, schedule, enabled state and local delivery. If it is not correct, say so plainly; do not claim success.
5. After verified activation, write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-post-meeting-recap-draft.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause or resume: use the native scheduler tools for this same job ID
   - remove: ask to remove this same job using the native scheduler tools
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
