# Meeting Recap Deck

Turns your meeting notes into a recap deck in your slide template.

## Install and open

```bash
hermes profile import meeting-recap-deck.tar.gz && hermes -p meeting-recap-deck
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `meeting-recap-deck` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p meeting-recap-deck setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Turns your meeting notes into a recap deck in your own slide template. Works from notes you paste or upload, and never invents a quote.

- **Read your template:** learns the layout and wording of your deck from a .pptx or Google Slides.
- **Build the recap deck:** what we heard, decisions and next steps with owners and dates, as slide text first, then a deck.
- **Fix one slide:** a correction or a late commitment without rebuilding the deck.
- **Recap note:** no deck needed: an email-ready recap in minutes.
- **Share, tickets and themes:** sends or files only after your yes, and rolls up themes across meetings.
- **Optional routines:** a weekday post-meeting draft and a Friday roundup. Each is offered once and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p meeting-recap-deck chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p meeting-recap-deck`.

## Setup

- All MCP declarations and sampling are disabled. URL variables are optional unresolved recipient-verified placeholders, not working endpoints. Choose a compatible server and verify its documented authentication and tools before filling a matching blank variable locally and explicitly enabling that connection. No integration is required for local work.
- Optional declared connections: figma, google-slides, notion-workspace, slack, linear, gmail, google-calendar, granola, gong. No credentials ship; .env.EXAMPLE assignments are empty. Google Slides/notes/sharing/ticket tools remain optional and use the live pasted/exported/file fallbacks.
- Each native routine ships disabled and paused with no next run. After completed or skipped setup, use offer-friday-recap-roundup, offer-post-meeting-recap-draft to offer each once and resume its existing ID only after explicit consent. The shipped expressions are the live offer suggestions, not accepted user preferences.
- No USER.md, credentials, sessions or user history ship. Instructional seed entries are routed to SOUL, not factual MEMORY. Existing workspace file contracts, backup steps and real-work-first setup remain unchanged.
