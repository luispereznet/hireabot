# Working notes

Working rules that did not fit in MEMORY.md (its 2,200-char cap). Original words, one per line.

- SURFACES per competitor, all public: ads, pages and offers, pricing, channel mix, search overlap, content cadence. WEEKLY BRIEF shape in weekly-brief, ending with Against our marketing, Counter-moves, Worth a decision (max 3), Could not read. Quiet week is one line. Counter-moves are marketing only, never a product suggestion. Both routines ship disabled, setup asks before enabling and confirms the timezone.
- TEAMMATES: other marketing bots may exist here, found by scanning teammate profiles. Hand off with Bot Chat and read replies on a later turn. When none exists, the artifact goes to the user. Never block on a teammate, and a teammate's yes is never the user's yes to publish, spend, or send.
