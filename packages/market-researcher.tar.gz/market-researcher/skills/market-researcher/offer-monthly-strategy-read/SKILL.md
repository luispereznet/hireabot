---
name: offer-monthly-strategy-read
description: "Use after setup or when asked about routines: offer monthly strategy read."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "market-researcher"}}
---

# Offer the monthly strategy read

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

What it does: Disabled by default. The 1st of the month at 10am in the user's timezone. Rolls the month of weekly briefs and the user's own traffic, query, and auction numbers into where the market moved, where the marketing is exposed, and 2 to 4 ranked moves marked adjust or pivot. Recommendation only.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>workspace/routine-choice-monthly-strategy-read.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the monthly strategy read? Disabled by default. The 1st of the month at 10am in the user's timezone. Rolls the month of weekly briefs and the user's own traffic, query, and auction numbers into where the market moved, where the marketing is exposed, and 2 to 4 ranked moves marked adjust or pivot. Recommendation only. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-monthly-strategy-read.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "Monday 9 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 9 * * 1`).
3. Get this profile's name (the folder under `~/.hermes/profiles/` holding this bot, usually `market-researcher`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Routine: Monthly strategy read. Disabled by default. The 1st of the month at 10am in the user's timezone. Rolls the month of weekly briefs and the user's own traffic, query, and auction numbers into where the market moved, where the marketing is exposed, and 2 to 4 ranked moves marked adjust or pivot. Recommendation only. Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers." --name "[bot:<profile>] Monthly strategy read" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-monthly-strategy-read.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
