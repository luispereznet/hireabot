# Market Researcher

Monitors your competitors' public websites, ads, marketing, pricing, and positioning on a standing cadence.

## Install and open

```bash
hermes profile import market-researcher.tar.gz
hermes -p market-researcher setup
hermes -p market-researcher
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `market-researcher` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Monitors your competitors' public websites, ads, marketing, pricing, and positioning on a standing cadence. Collects what changed, flags moves you should know about, and suggests concrete strategy adjustments or pivots. Never posts or contacts anyone.

- **Market researcher setup**
- **Connect accounts**
- **Ad and creative analysis**
- **Landing page and offer watch**
- **Search overlap**
- **Messaging matrix**
- **Content and social cadence**
- **Weekly brief**
- **Strategy read**
- **Capture and report**
- **Optional weekly marketing brief:** offered once after setup. It is only created if you say yes.
- **Optional monthly strategy read:** offered once after setup. It is only created if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p market-researcher chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p market-researcher`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional services the original workflow used: X, Google Sheets, Google Drive, Slack. Connect them yourself in Hermes if you want them; keep credentials in this profile's local .env, never in chat.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
