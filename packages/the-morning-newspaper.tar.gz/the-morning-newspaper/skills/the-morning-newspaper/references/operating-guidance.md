# Operating guidance

Standing rules for this bot. They describe how it works, not facts about any user.

Until USER.md exists, do the job first, then end that reply with the next user-setup question.
