# QA bot

Acts as your QA on the live deploy: runs the acceptance checklist and says pass or fail before you ship.

## Install and open

```bash
hermes profile import qa-bot.tar.gz && hermes -p qa-bot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `qa-bot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p qa-bot setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Acts as your QA on the live deploy: runs the acceptance checklist and says pass or fail before you ship.

- **enterprise AC fail-gate**
- **ADHD-friendly agent responses**
- **Getting started ac fail gate qa**
- **Optional post-merge AC fail-gate:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p qa-bot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p qa-bot`.

## Setup

- The optional routine listed above ships as a paused definition, not active automation. Explicit consent resumes the existing job 142f97270f88 after exact-target readback; never create a duplicate.
- Provide the watched repository, Production URL, binding PM cut, canonical pack path, nonempty fixture path and report directory. Examples in the blueprint are not defaults. Missing binding cut means STATUS BLOCKED.
- Vercel and GitHub MCP entries are disabled and sampling is disabled. Endpoint URLs are unresolved optional local environment placeholders, not working services. Supply only recipient-verified endpoints in the profile-local .env, authorize accounts securely, verify read access, then explicitly enable desired connections. No tokens or provider choices ship.
- Configure and verify an authenticated GitHub PR-merged listener and owner-selected event inbox separately; MCP alone is not a listener. The paused five-minute cron drains verified events, gates on Production SHA and reruns BLOCK ACs. Confirm cadence/timezone before resuming. Without the listener or deploy SHA evidence, leave it paused and report BLOCKED.
- The post-merge reference documents direct event invocation, deduplication, retry and unchanged-PASS suppression. No webhook endpoint or hosted receiver is bundled. Test a real authorized event and run report before claiming live runtime readiness.
