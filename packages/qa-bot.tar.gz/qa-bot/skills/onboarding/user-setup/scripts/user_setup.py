#!/usr/bin/env python3
"""user_setup.py: first-start onboarding helper for a converted Hermes bot. Ships inside the bot at
skills/onboarding/user-setup/scripts/user_setup.py and finds its own profile from its location.

    user_setup.py status                       PENDING while USER.md is missing, empty or the old placeholder, else DONE
    user_setup.py finish [--dry-run]           take user-setup out of skills.auto_load (writes only this profile's config)
    user_setup.py questions                    the bot's question list (JSON)
    user_setup.py scan-others --consent        READ-ONLY: what this machine's other Hermes profiles keep in
                                               memories/USER.md. Refuses without --consent. Never writes anywhere.
    user_setup.py write --answers A.json [--others O.json] [--dry-run]
                                               write USER.md from the answers (+ the facts the user confirmed from
                                               other bots), within the cap, then runs finish. USER.md is created here;
                                               an older USER.md is copied to USER.md.before-<time> first.

Answers file: {"<question id>": "<answer>", ...}. Blank or "skip" answers are left out.
Others file: a JSON list of strings the user confirmed or edited after scan-others.
"""
from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, time
from pathlib import Path

MARKER = '<!-- user-setup:pending -->'
SEP = '\n§\n'
HERE = Path(__file__).resolve()
SKILL = HERE.parent.parent
PROFILE = HERE.parents[4]                  # <profile>/skills/onboarding/user-setup/scripts/user_setup.py
USER_MD = PROFILE / 'memories' / 'USER.md'


def cap() -> int:
    try:
        return int(json.loads((SKILL / 'questions.json').read_text()).get('user_cap', 1375))
    except Exception:  # noqa: BLE001
        return 1375


def status() -> int:
    t = USER_MD.read_text() if USER_MD.is_file() else ''
    pending = (not t.strip()) or MARKER in t
    print('PENDING' if pending else 'DONE')
    return 0


def profile_args() -> list:
    """`-p <name>` for this bot's own profile (found from this file's location), or [] for the default profile."""
    return ['-p', PROFILE.name] if PROFILE.parent.name == 'profiles' else []


def finish(dry: bool = False) -> int:
    """Remove this skill from skills.auto_load so new sessions stop loading it. Touches only this profile."""
    if PROFILE.parent.name != 'profiles':
        print('refused: finish requires an installed named profile', file=sys.stderr)
        return 5
    env = os.environ.copy()
    env['HERMES_HOME'] = str(PROFILE.parent.parent)
    env.pop('HERMES_PROFILE', None)
    me = SKILL.name
    r = subprocess.run(['hermes', *profile_args(), 'config', 'get', 'skills.auto_load', '--json'],
                       capture_output=True, text=True, env=env)
    if r.returncode != 0:
        print('could not read auto_load: ' + r.stderr.strip(), file=sys.stderr)
        return 5
    try:
        cur = json.loads(r.stdout.strip() or '[]')
    except ValueError:
        cur = []
    if not isinstance(cur, list):
        cur = []
    if me not in cur:
        print(f'auto_load already without {me}: {cur}')
        return 0
    new = [x for x in cur if x != me]
    cmd = ['hermes', *profile_args(), 'config', 'set', 'skills.auto_load', json.dumps(new)]
    print('$ ' + ' '.join(cmd))
    if dry:
        return 0
    w = subprocess.run(cmd, capture_output=True, text=True, env=env)
    if w.returncode != 0:
        print(f'could not update auto_load: {w.stderr.strip()}', file=sys.stderr)
        return 5
    print(f'onboarding finished: {me} removed from skills.auto_load (now {new})')
    return 0


def questions() -> int:
    print((SKILL / 'questions.json').read_text())
    return 0


def other_user_files() -> list[tuple[str, Path]]:
    profiles = PROFILE.parent if PROFILE.parent.name == 'profiles' else PROFILE / 'profiles'
    root = profiles.parent
    found = []
    if (root / 'memories' / 'USER.md').is_file() and root.resolve() != PROFILE.resolve():
        found.append(('default', root / 'memories' / 'USER.md'))
    if profiles.is_dir():
        for p in sorted(profiles.iterdir()):
            f = p / 'memories' / 'USER.md'
            if p.is_dir() and p.resolve() != PROFILE.resolve() and f.is_file():
                found.append((p.name, f))
    return found


def scan_others(consent: bool) -> int:
    if not consent:
        print('refused: ask the user first. Re-run with --consent only after they say yes.', file=sys.stderr)
        return 3
    out = []
    for name, f in other_user_files():
        with open(f, 'r', encoding='utf-8') as fh:          # read-only; nothing is ever written to other profiles
            text = fh.read()
        if MARKER in text:
            continue
        entries = [e.strip() for e in text.replace('\r', '').split('§') if e.strip()]
        if entries:
            out.append({'profile': name, 'entries': entries})
    print(json.dumps({'read_only': True, 'profiles_with_facts': out}, indent=2, ensure_ascii=False))
    return 0


def write(answers_path: str, others_path: str | None, dry: bool) -> int:
    q = json.loads((SKILL / 'questions.json').read_text())
    labels = {x['id']: x.get('label', x['id']) for x in q['questions']}
    ans = json.loads(Path(answers_path).read_text())
    entries = []
    for qid, v in ans.items():
        v = ' '.join(str(v).split())
        if not v or v.lower() in ('skip', 'n/a', 'none'):
            continue
        entries.append(f'{labels.get(qid, qid)}: {v}')
    if others_path:
        for e in json.loads(Path(others_path).read_text()):
            e = ' '.join(str(e).split())
            if e and e not in entries:
                entries.append(e)
    if not entries:
        print('nothing to write: no answers', file=sys.stderr)
        return 2
    text = SEP.join(entries) + '\n'
    if len(text) > cap():
        sizes = sorted(((len(e), e[:60]) for e in entries), reverse=True)
        print(f'over the USER.md cap: {len(text)}/{cap()} chars. Shorten with the user; longest entries:', file=sys.stderr)
        for n, e in sizes[:5]:
            print(f'  {n:4}  {e}', file=sys.stderr)
        return 4
    if dry:
        print(text)
        print(f'(dry run) {len(text)}/{cap()} chars')
        return 0
    if USER_MD.is_file():
        shutil.copy2(USER_MD, USER_MD.with_name(f'USER.md.before-{time.strftime("%Y%m%d-%H%M%S")}'))
    USER_MD.parent.mkdir(parents=True, exist_ok=True)
    tmp = USER_MD.with_suffix('.tmp')
    tmp.write_text(text)
    tmp.replace(USER_MD)
    print(f'USER.md written: {len(entries)} entries, {len(text)}/{cap()} chars')
    return finish()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('status')
    sub.add_parser('questions')
    s = sub.add_parser('scan-others')
    s.add_argument('--consent', action='store_true', help='the user said yes to reading their other bots')
    w = sub.add_parser('write')
    w.add_argument('--answers', required=True)
    w.add_argument('--others')
    w.add_argument('--dry-run', action='store_true')
    f = sub.add_parser('finish')
    f.add_argument('--dry-run', action='store_true')
    a = ap.parse_args()
    if a.cmd == 'finish':
        return finish(a.dry_run)
    if a.cmd == 'status':
        return status()
    if a.cmd == 'questions':
        return questions()
    if a.cmd == 'scan-others':
        return scan_others(a.consent)
    return write(a.answers, a.others, a.dry_run)


if __name__ == '__main__':
    sys.exit(main())
