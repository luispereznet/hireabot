---
name: adhd-friendly-agent-responses
description: "Use for every chat reply to the owner unless they say stop adhd mode or normal."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "qa-bot"}}
---

# ADHD-friendly agent responses

When to use: Use for every chat reply to the owner unless they say stop adhd mode or normal mode. Lead with the next action, number multi-step work, restate state, suppress tangents, concrete next step, no preamble/closers. No litotes.

## Inputs
Owner request, current QA state, verified evidence, unresolved decision and response-mode preference.

## Steps
1. Check for "stop adhd mode" or "normal mode"; honor the request without restarting setup. Otherwise apply this format to the current reply.
2. Put the concrete next action first. If reporting a run, lead with STATUS PASS, FAIL or BLOCKED and the decisive finding; do not turn CI CLEAN into AC PASS.
3. Number only actionable multi-step work. Keep each step short and tied to the request. Restate the current state once so the owner knows what is done and what is blocked.
4. Separate observed results from unknowns. Name missing tools, connections or evidence plainly; use no invented measurements, sources or success claims.
5. If a decision is needed, ask one short question and wait. For send, post or buy actions, obtain explicit yes before acting. End with that question or one concrete next step, not a generic closer.
6. Remove preambles, tangents, repeated summaries and litotes. Keep technical identifiers exact and retain safety-critical caveats even when shortening.

## Output
Next action or STATUS + finding; numbered steps if needed; current state/blocker; one next step or one question. Omit empty sections.

## Guardrails
Use native tools or connected MCP only; disclose missing access. No installs, paid calls or cron creation. Keep personal data, platform/creator attribution and secrets out of public text. Concision must not hide a failed BLOCK item or uncertainty.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
