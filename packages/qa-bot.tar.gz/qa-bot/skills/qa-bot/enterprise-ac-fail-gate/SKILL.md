---
name: enterprise-ac-fail-gate
description: "Use when a QA bot must turn a binding PRD cut into a canonical AC pack."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "qa-bot"}}
---

# enterprise AC fail-gate

When to use: Use when a QA bot must turn a binding PRD cut into a canonical AC pack, run it on a live deploy with BLOCK vs WARN severity, emit a swarmable PASS|FAIL|BLOCKED report (SHA gate + YAML footer), and hard-fail ship blockers for staff/senior IC ship loops. Also use when Eng claims done and QA must judge the same AC map.

## Inputs
Binding PM cut, repo/target SHA, live URL, owner-set QA paths, access and severities.

## Steps
1. Read the cut and existing pack. If the cut is absent, report BLOCKED and ask for it. Ask one missing-input question at a time; never invent ACs or paths.
2. Map each requirement to an AC ID, BLOCK/WARN, preconditions, fixed fixture, exact steps and expected result. Resolve unclear severity with the owner. Append and dedupe; an empty fixture array is a pack defect. Save the canonical pack at the owner-set path.
3. Verify Production SHA with deploy/repo evidence; record expected/observed SHA. Missing or mismatched proof blocks a verdict; CI CLEAN is not AC PASS. Disclose missing access; ask the named password owner for secure access.
4. Run each AC on the live target using native tools or connected MCP. Freeze fixtures during comparison. Record actual result, evidence, repro and AC ID; never edit expectations to go green. Keep ambiguous names/locations owner-only until resolved; no invented default or false multi-entity failure.
5. FAIL if a BLOCK AC fails; otherwise BLOCKED if a required BLOCK check or SHA gate is unresolved; otherwise PASS with WARN findings listed. QA judges independently of Eng. Save every attempted run as run-YYYY-MM-DD-<slug>.md at the agreed path and read it back.

## Output
Header: STATUS, cut/pack revision, URL, expected/observed SHA, fixture reference, run time. Table: AC ID | severity | result | expected/actual | evidence | repro/owner. State blockers and next action. End with YAML footer using status, target_sha, observed_sha, pack, fixtures, failed_ids, blocked_ids, warning_ids, evidence. Use null for unknowns, never guessed data.

## Guardrails
Never soft-pass BLOCK. No installs, paid calls or cron. Explicit yes before send/post/buy. No secrets, personal data or platform/creator attribution in public text. Disclose missing tools/evidence; never simulate.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
