---
name: offer-post-merge-ac-fail-gate
description: "Use after setup or when asked about routines: offer post-merge AC fail-gate."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "qa-bot"}}
---

# Offer the post-merge AC fail-gate

## When to offer
Once after setup or a global skip, or when asked about routines. Resolve the active profile from this skill's ancestor containing SOUL.md and skills/. Read workspace/routine-choice-post-merge-ac-fail-gate.md first; do not repeat declined/resumed offers unless asked.

## Inputs
Explicit consent, watched repository, Production URL, binding cut, pack/fixture/report paths, authenticated PR-merged listener and event inbox. Read references/post-merge-gate.md.

## Steps
1. Explain: the paused routine processes verified merged-PR events, verifies Production SHA and reruns BLOCK checks; unchanged PASS stays quiet. Ask one yes/no question. No clear yes means leave it paused; record a clear decline only. A global setup skip is not consent.
2. On yes, collect missing setup one question at a time. Verify the listener and deployment evidence tools are available. MCP alone does not install a listener. No listener, missing fixtures or absent cut means BLOCKED, not activation. Never ask for secrets in chat.
3. Read the native scheduler's existing job with ID 142f97270f88 and name [bot:qa-bot] Post-merge AC fail-gate. Inspect its actual prompt, paused state, five-minute inbox-check schedule and local delivery. Explain that the timer drains events; it is not a daily QA run. Confirm recipient timezone and consent to that cadence, or agree an updated cadence.
4. Resume only the existing matching job after explicit consent; never create a duplicate. Use the available native scheduler tool and its discovered schema. If the job is absent, mismatched or the tool is missing, stop and explain; do not invent commands or recreate it.
5. Read back the exact ID. Verify enabled state, schedule, prompt and local delivery before claiming activation. Record resumed date, ID and agreed schedule in the choice file. If verification fails, report uncertainty and leave activation unclaimed.

## Output and guardrails
Report paused/BLOCKED or verified active, job ID and next action. Pause/change only on request and read back the exact job afterward. No installs, paid calls, sending or posting without explicit approval. No credentials or owner-only data in public reports.
