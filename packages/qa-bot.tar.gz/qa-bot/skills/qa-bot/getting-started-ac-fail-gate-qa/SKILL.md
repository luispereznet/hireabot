---
name: getting-started-ac-fail-gate-qa
description: "Use this when a newly imported AC fail-gate bot runs its first conversation."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "qa-bot"}}
---

# getting-started-ac-fail-gate-qa

When to use: Use this when a newly imported AC fail-gate bot runs its first conversation with its new owner.

## Inputs
Current request, SOUL.md, MEMORY.md, existing USER.md/setup state, owner-provided repo, deploy URL, binding cut and QA paths.

## Steps
1. If the message is exactly "Reply only: READY", reply READY only. Otherwise read local setup state; never repeat completed setup or restart after a global opt-out.
2. If work was requested, do that first using enterprise-ac-fail-gate. Without a binding PM cut, return STATUS BLOCKED and ask for the cut instead of inventing acceptance criteria.
3. While setup is incomplete, use user-setup for skippable preferences. Ask only one short question per reply, after any job result; do not add a second technical question. Never read another profile without consent or modify it.
4. Gather missing job inputs one at a time: watched repo, Production URL, binding cut, canonical pack path, fixture path and report directory. Confirm owner-set paths; examples are not defaults. Identify the named password owner when access is uncertain; request secure access, never secrets in chat.
5. Inspect available native tools and connected MCP access. Explain what can be verified and what is missing. Do not claim integrations are connected. First-run readiness requires a binding cut, nonempty fixtures, an agreed AC map and verifiable Production SHA.
6. Summarize known inputs and the next unresolved item. Hand an executable job to enterprise-ac-fail-gate; keep CI CLEAN separate from QA PASS. After setup, offer the optional post-merge gate once, explaining that a merged-PR listener and deploy SHA proof are needed. Do not create cron or automation; disclose missing support.

## Output
Current state: ready or BLOCKED with reason. List confirmed repo/URL/QA paths without secrets, then one next action or one question. For an attempted run, use the enterprise run report, not a setup-based PASS.

## Guardrails
Never invent numbers, evidence, credentials, ACs or default locations. No installs or paid calls. Require explicit yes before send/post/buy. Keep personal data and platform/creator attribution out of public text; no routine without explicit consent.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
