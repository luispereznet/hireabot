# Company Docs Q&A

Answers product and how-to questions from live docs first, then connected knowledge sources, and always cites sources.

## Install and open

```bash
hermes profile import company-docs-q-a.tar.gz
hermes -p company-docs-q-a setup
hermes -p company-docs-q-a
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `company-docs-q-a` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Answers product and how-to questions from live docs first, then connected knowledge sources, and always cites sources. Built for anyone who wants a trustworthy internal knowledge bot.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p company-docs-q-a chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p company-docs-q-a`.

## Setup

- Core workflows: skills/company-docs-q-a/docs-first-answer/SKILL.md, connected-knowledge-search/SKILL.md and verified-message-draft/SKILL.md under the same bot folder. Provide the real company docs URL; no company, version, account or connector is presumed. Public docs retrieval needs available search/fetch or browser tools; disclose missing tools and use supplied excerpts without claiming live retrieval.
- slack: Search authorized internal channels; sending requires exact-message approval. Leave SLACK_MCP_URL blank unless wanted. Select a compatible remote MCP implementation and verify its documented URL, authentication, account scope and least-privilege tools before filling the local .env and explicitly enabling it. Sampling stays disabled. No endpoint, installed plugin, OAuth support or account access is asserted.
- notion: Search permitted knowledge pages; no plugin is shipped or installed. Leave NOTION_MCP_URL blank unless wanted. Select a compatible remote MCP implementation and verify its documented URL, authentication, account scope and least-privilege tools before filling the local .env and explicitly enabling it. Sampling stays disabled. No endpoint, installed plugin, OAuth support or account access is asserted.
- google-workspace: Optional native Google Workspace MCP for Drive, Docs, Sheets, Calendar, Gmail and Slides, used after public docs. Leave GOOGLE_WORKSPACE_MCP_URL blank unless wanted. Select a compatible remote MCP implementation and verify its documented URL, authentication, account scope and least-privilege tools before filling the local .env and explicitly enabling it. Sampling stays disabled. No endpoint, installed plugin, OAuth support or account access is asserted.
- linear: Optional authorized issue evidence explicitly mentioned in source memory. Leave LINEAR_MCP_URL blank unless wanted. Select a compatible remote MCP implementation and verify its documented URL, authentication, account scope and least-privilege tools before filling the local .env and explicitly enabling it. Sampling stays disabled. No endpoint, installed plugin, OAuth support or account access is asserted.
- internal-wiki: Optional authorized internal wiki evidence; public docs still come first. Leave INTERNAL_WIKI_MCP_URL blank unless wanted. Select a compatible remote MCP implementation and verify its documented URL, authentication, account scope and least-privilege tools before filling the local .env and explicitly enabling it. Sampling stays disabled. No endpoint, installed plugin, OAuth support or account access is asserted.
