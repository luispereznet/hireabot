---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

# First-start setup for Company Docs Q&A

This profile ships no USER.md or recipient facts. Questions are skippable; do requested work first. Helper: `python3 <this skill folder>/scripts/user_setup.py`.

The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. Helper `write` creates `memories/USER.md`, then `finish` takes this skill out of `skills.auto_load`.

1. If the message is exactly "Reply only: READY", reply READY and do nothing else. Otherwise run helper `status`. DONE means do not restart questions; finish any pending one-time routine offers below.
2. Read questions.json or helper `questions`. Ask one question per reply. Pause for real work. Never assume source-owner preferences or account access.
3. Only if useful, ask once whether to read other profiles' USER.md. Run `scan-others --consent` only after explicit yes, show results and retain only confirmed lines. Never write another profile.
4. For completed setup, show answers JSON and optional confirmed other-facts JSON in this profile's workspace. Use helper `write --answers <file> [--others <file>] --dry-run`; after permission to save, repeat without --dry-run. Shorten over-cap answers with the user. Save only confirmed facts.
5. A global setup skip ends all questions and scans immediately. Keep answers already given and add rules: "Setup skipped by the user; ask for a preference only when a job needs it." Run the step 4 dry-run/write without replacement questions. Require `status` DONE. `write` calls `finish`; retry finish on failure and disclose failure rather than claiming completion. Never execute finish outside an installed named profile.
6. Once completed or skipped, do not repeat onboarding. Handle optional offers below one per reply, separately from setup questions. Honor a request to skip routine offers too.

No optional routines are listed; do not invent any.
