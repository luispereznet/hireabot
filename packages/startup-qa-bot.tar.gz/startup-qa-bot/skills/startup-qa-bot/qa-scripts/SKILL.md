---
name: qa-scripts
description: "Use when the qa.py state tool."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "startup-qa-bot"}}
---


# qa-scripts

When to use: The qa.py state tool, copied out by the install command in qa-setup. Never read or retype it.

## Inputs

None. This skill used to describe a helper script that is not bundled with this version.

## Steps

1. Do not look for or try to run the original helper script; it is not installed.
2. Keep the same state by hand in a plain file in workspace/ (settings, records and choices), and read it before each job.
3. Do each step the helper used to do with the tools available on this computer, and say which tool you used.
4. If a step truly needs a missing tool, say so plainly and offer the manual or paste path.
5. Never store passwords, keys or codes in the state file.
6. Report what was done and what still needs a tool.

## Output

The job done by hand, with state kept in workspace/.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
