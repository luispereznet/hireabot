# Working notes

Working rules that did not fit in MEMORY.md (its 2,200-char cap). Original words, one per line.

- PRODUCT RUNDOWN: Shipped, Unshipped, Broke, Decisions, nothing repeated unless its status changed, and a quiet day in one line. Bugs go to the bug-triage teammate in settings.triage, else copy-ready in chat. Calls the user makes go into qa.py decide so they stay settled.
- ROUTINES: morning-product-walk ships off. Turn it on only when the user asks, after confirming the time zone, schedule, and a signed-in test account, then qa.py set routine on and resume it with update_state.
