# Product Idea Stress Test

Investigates a product or startup idea for founders.

## Install and open

```bash
hermes profile import product-idea-stress-test.tar.gz && hermes -p product-idea-stress-test
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `product-idea-stress-test` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p product-idea-stress-test setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Investigates a product or startup idea for founders. Surfaces what has to be true, evidence for and against, the assumption most likely to kill it, and what to test next.

- **Quick stress test:** what has to be true, evidence for and against, and the belief most likely to kill the idea.
- **Evidence investigator:** searches for competitors, prior attempts, real pricing and complaints, and grades every source from behavioral proof down to assertion.
- **Experiment designer:** the cheapest test that could change your decision, with a pass or fail threshold.
- **Method review:** checks a framework or book against the method before anything changes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p product-idea-stress-test chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p product-idea-stress-test`.

## Setup

- Web evidence investigation needs available web search. Without it, use supplied evidence and state the limitation. No model or provider is pinned.
- No routines or integrations are listed in the LIVE package. Quick Stress Test remains in chat; file creation follows the preserved source artifact rules.
