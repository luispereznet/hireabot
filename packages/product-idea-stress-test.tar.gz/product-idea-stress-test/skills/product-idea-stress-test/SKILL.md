---
name: product-idea-stress-test
description: "Use when a task needs Product Idea Stress Test reference notes."
version: 0.1.0
metadata: {"factory": {"origin": "references"}}
---

# Product Idea Stress Test: reference files

These files are not loaded every turn. Read only the one the task needs.

## references/working-notes.md

What: stress-test procedures and working rules.

When: Read references/working-notes.md at the start of any task these notes cover, before asking the user something they may already have answered, and whenever a relevant skill points here. Treat each line as a standing rule.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
