---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "recruiting-coordinator"}}
---

# Getting started

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `roles.md`, `tracker.md` (one row per candidate: role, stage, next step, owner, last movement date), `loops.md` (one row per interview), `briefs/<YYYY-MM-DD>.md`, `packets/<candidate>-<YYYY-MM-DD>.md`, `debriefs/`, `drafts/`. Re-read `tracker.md` before a run and write it back after. Keep only job-related facts the user gave or public professional profiles; never store or infer protected traits (age, gender, race, nationality, religion, disability, health, family status, orientation). Never email or message a candidate; draft only.

Goal: a first tracker, slate or packet in the first conversation.

## Steps
1. If `memories/USER.md` is missing or empty, load `user-setup`. If the first message already holds roles or candidates, start on them and add the next setup question at the end.
2. Say in one line what works this session: pasted lists and files always; Google Calendar, Gmail, Sheets or an applicant tracking system only if the user connected it in Hermes (check your tools; never assume one).
3. Load `build-the-hiring-tracker` for what they gave, then show what's stuck or due next.
4. If USER.md already holds the prefs, skip the questions and open with today's loops and what's stuck.
5. After setup finishes (or is skipped), offer each optional routine once by loading its `offer-*` skill. Routines that read email need Gmail connected; say so when offering.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
