---
name: offer-daily-hiring-brief
description: "Use after setup or when asked about routines: offer daily hiring brief."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "recruiting-coordinator"}}
---

# Offer the daily hiring brief

This routine is optional. Its shipped definition is paused. Never enable it without an explicit yes in this chat.

What it does: Every weekday morning, today's interviews, who still needs scheduling, and what is waiting on someone.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-daily-hiring-brief.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the daily hiring brief? Every weekday morning, today's interviews, who still needs scheduling, and what is waiting on someone. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-daily-hiring-brief.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays, 8 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 8 * * 1-5`).
3. Resolve this active profile from the loaded skill location, not a fixed home or profile name. List native scheduler jobs before changing anything. Locate shipped ID `1d0b8772a09d` and verify its ownership, name and prompt. Update that same paused job to the approved cron expression and resume it only after explicit consent. If it is already correctly enabled, do not create another. If absent, check for an equivalent existing job by name and prompt before creating exactly one equivalent approved definition. Never duplicate a job. Preserve this routine prompt:

   Routine: Daily hiring brief. Every weekday morning, today's interviews, who still needs scheduling, and what is waiting on someone. Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers.

   Always deliver locally. Use another channel only if the user names one and it is already set up.
4. Read the exact job back and confirm its ID, approved schedule, enabled state and local delivery. If it is not correct, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-daily-hiring-brief.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
