---
name: stalled-loop-follow-ups
description: "Use when the user asks what is stuck."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "recruiting-coordinator"}}
---

# Stalled loop follow-ups

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `roles.md`, `tracker.md` (one row per candidate: role, stage, next step, owner, last movement date), `loops.md` (one row per interview), `briefs/<YYYY-MM-DD>.md`, `packets/<candidate>-<YYYY-MM-DD>.md`, `debriefs/`, `drafts/`. Re-read `tracker.md` before a run and write it back after. Keep only job-related facts the user gave or public professional profiles; never store or infer protected traits (age, gender, race, nationality, religion, disability, health, family status, orientation). Never email or message a candidate; draft only.

## Steps
1. Read `tracker.md` and `loops.md`. List items past the stalled bar: candidates without a next step, missing scorecards, a hiring manager decision owed.
2. For each, say who owes what since when, and draft one short nudge (candidate, interviewer or manager).
3. Draft only. Save drafts to `drafts/`. Never send.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
