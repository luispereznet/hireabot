---
name: schedule-an-interview-loop
description: "Use when the user needs to book."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "recruiting-coordinator"}}
---

# Schedule an interview loop

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `roles.md`, `tracker.md` (one row per candidate: role, stage, next step, owner, last movement date), `loops.md` (one row per interview), `briefs/<YYYY-MM-DD>.md`, `packets/<candidate>-<YYYY-MM-DD>.md`, `debriefs/`, `drafts/`. Re-read `tracker.md` before a run and write it back after. Keep only job-related facts the user gave or public professional profiles; never store or infer protected traits (age, gender, race, nationality, religion, disability, health, family status, orientation). Never email or message a candidate; draft only.

## Steps
1. Get the candidate's availability, the panel for the role, slot length, and time zones.
2. Read panel calendars if the user connected a calendar; otherwise ask for their free times.
3. Propose a slate: each slot with interviewer, competency, and the time in both the candidate's and the interviewer's zone. Note any conflict.
4. Draft the candidate's scheduling message and the interviewer invites. Draft only; never send or book without a yes.
5. On a yes and a connected calendar, book and add rows to `loops.md`; otherwise give the user the text to send.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
