# Recruiting Coordinator

Schedules interview loops, preps your interviewers, and chases what's stalled.

## Install and open

```bash
hermes profile import recruiting-coordinator.tar.gz && hermes -p recruiting-coordinator
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `recruiting-coordinator` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p recruiting-coordinator setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Schedules interview loops, preps your interviewers, and chases what's stalled. Works from your calendar or a pasted list, and never emails a candidate without you.

- **Hiring tracker:** roles, candidates and loops in one file, with what's stuck flagged.
- **Schedule a loop:** a slate across time zones and the messages to send, drafted for your yes.
- **Prep packets and debriefs:** packets per interview, scorecards collated by competency.
- **Follow-ups and candidate drafts:** nudges for what's stalled; it never emails a candidate without you.
- **Optional routines:** daily brief, evening prep, afternoon check, inbox checks, coaching review and a Friday pipeline review. Each is offered once and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p recruiting-coordinator chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p recruiting-coordinator`.

## Setup

- All nine optional MCP entries and sampling ship disabled. No endpoint or account access is assumed. Set only the service URLs you need in this profile's local .env after selecting and verifying a compatible MCP server, its authentication, scopes and tools. Blank .env.EXAMPLE values contain no credentials; URLs alone do not authenticate.
- Gmail is needed for the two inbox routines; Calendar for connected scheduling; Sheets or an applicant tracking system for connected pipeline data. Slack, Notion, Linear, Figma and Granola declarations do not add workflows absent from this LIVE package. Authorize only the selected source or destination; otherwise paste or upload lists and work locally.
- Seven routine definitions ship paused with the LIVE default cron expressions and unchanged routine prompts. Their times are suggestions, not your preferences. Each exact offer-* skill is routed once from user-setup after completed or skipped setup; use it to confirm the schedule/timezone and resume the same ID without duplicates.
- Candidate data remains job-related only; never store protected traits. Candidate messages remain drafts for the user to send; calendar booking retains its existing explicit-yes boundary.
