# Apple Search Ads Review

Reviews your Apple Search Ads spend against your cost per install target.

## Install and open

```bash
hermes profile import apple-search-ads-review.tar.gz && hermes -p apple-search-ads-review
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `apple-search-ads-review` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p apple-search-ads-review setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Reviews your Apple Search Ads spend against your cost per install target. Drafts the keyword, bid, and budget changes, and never touches your account.

- **Set spend targets**
- **Spend review**
- **Search terms and negatives**
- **Bids and budgets**
- **Weekly ad review**
- **Change sheet**
- **Optional weekly ad review:** offered once after setup. It is only enabled if you say yes.
- **Optional daily spend check:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p apple-search-ads-review chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p apple-search-ads-review`.

## Setup

- Use pasted/uploaded CSV exports by default; no Apple Search Ads account write connection is included. Confirm app, account/storefront, currency, reporting timezone and CPI targets before comparing.
- All seven optional MCP entries are disabled and sampling is disabled. No endpoint has been verified or supplied. Obtain a trusted recipient-verified endpoint (and its documented OAuth/auth requirements), fill the corresponding blank optional URL variable locally, then explicitly opt in before enabling. Never enter secrets in chat.
- Slack posts, Notion writes, Linear tasks, Gmail sends/management and Google Sheets writes need exact destination/content approval and readback; Hex and Databricks queries must be read-only and scoped to approved modeled reports. Without tools or connections return local drafts.
- Both included local routine jobs are paused. Their schedules are placeholders, not recipient preferences. Use offer-weekly-ad-review or offer-daily-spend-check to confirm time/timezone and resume the shipped job after explicit yes; daily checks are weekdays.
- Working files resolve under this active profile workspace/: targets.csv, exports/, reviews/, changes/, applied-log.csv and routine-choice files. Back up before replacement; no user facts or USER.md ship.
