---
name: bids-and-budgets
description: "Use when the user wants to know what to bid."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Bids and budgets

When to use: Use when the user wants to know what to bid, how much to change a bid by, where to move budget, or why a campaign is capped.

Inputs: observed spend, taps, installs, current bid/budget and caps, period, targets and campaign/group IDs; delivery constraints if provided.
1. Reuse spend-review validation and aggregate only comparable non-overlapping rows. Ask one question at a time for the current bid, budget or constraint if missing; never infer a cap solely from low delivery.
2. Calculate CPI = spend/installs, CPT = spend/taps and observed tap-to-install rate = installs/taps with tools. Label zero denominators undefined and distinguish observed rates from forecasts.
3. If evidence permits, show target CPI × observed tap-to-install rate as a rough target CPT, not a guaranteed auction bid or future outcome. Compare current bid and user-approved step limits; do not invent a multiplier, platform limit or lift estimate.
4. Draft bounded bid scenarios with old/new values and arithmetic. For reallocations, show before/after campaign budgets and reconcile the total to the user's cap in the same currency. No net spend increase without an explicit yes; missing caps leave proposals incomplete. Explain tradeoffs, small samples and attribution lag.
5. Output prioritized draft rows: IDs, current/proposed bid or budget, delta, source period, rationale, risk and rollback observation. Send approved rows to change-sheet for manual application.
Guardrails: do not edit accounts or buy media even with approval. No invented numbers. Native files/terminal, web/browser or recipient-connected MCP only; disclose missing tools. Explicit yes before sending/posting/buying or external writes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
