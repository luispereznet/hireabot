---
name: offer-daily-spend-check
description: "Use after setup or when asked about routines: offer daily spend check."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "apple-search-ads-review"}}
---

# Offer daily spend check

1. Read workspace/routine-choice-daily-spend-check.md under the active profile. Offer once after setup (including opt-out), or when requested; skip an already declined/enabled offer unless raised again. Ask one yes/no question: want a daily spend check? It reviews supplied exports locally, never the live ad account.
2. No means record declined locally and stop. Ambiguous or absent consent means leave paused, not declined. On explicit yes, gather weekday/time and IANA timezone one question at a time. The shipped schedule is only a disabled placeholder; confirm the actual schedule and data coverage before activation.
3. Use the recipient's native scheduling capability; if missing, disclose it and leave paused. List/read this profile's existing jobs and locate stable ID 7f2be6b7fa72, named [bot:apple-search-ads-review] Daily spend check. Confirm the job prompt, schedule, timezone semantics and local delivery with the user. Convert to the scheduler clock with timezone-aware tools if needed; do not use a guessed fixed UTC offset across DST.
4. Update that existing paused job to the confirmed schedule, read it back while still paused, then resume only after the explicit yes covers activation. Never create a duplicate or use cron run as a preview. If missing, stop and disclose the missing shipped definition; do not silently recreate it.
5. Read back the exact job ID, enabled state, schedule and next run after resume. Record enabled, ID and confirmed schedule locally only after verification. Report failures plainly; never claim activation from an attempted write. Explain pause/resume via available native scheduling tools.

Guardrails: local delivery only; any external delivery needs separate explicit yes and a working connection. Do not invent exports or account access; do not buy media, apply changes or send/post without approval. Daily checks are weekdays only; weekly reviews cover the last complete week. No live execution to test the schedule.
