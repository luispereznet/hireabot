---
name: weekly-ad-review
description: "Use when the user asks for a weekly read on their Apple Search Ads spend."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Weekly ad review

When to use: Use when the user asks for a weekly read on their Apple Search Ads spend, or when the weekly review routine runs.

Inputs: last complete week's dated exports, targets, prior comparable review and user-reported applied log; user's reporting timezone.
1. Establish week boundaries in the user's timezone; ask one question at a time if unknown. Read workspace/targets.csv, workspace/reviews/ and workspace/applied-log.csv. Check for a fresh export and complete coverage; if absent report the data gap, not a current-week finding.
2. Use spend-review to validate/reconcile at one grain and calculate totals and CPI. Compare like currencies, storefronts, attribution definitions and equal periods. Tool-calculate changes versus the prior week; missing or zero baselines mean no valid percentage change.
3. Separate observed movements from possible explanations. A recorded applied change is not proof of causation; identify timing, lag, partial periods and missing data.
4. Prioritize supported waste and growth opportunities via search-terms-and-negatives and bids-and-budgets. List proposed actions, source rows, downside and the next observation needed. Do not imply extra budget will deliver projected installs.
5. Save a dated weekly review and draft change list, preserving originals and earlier versions. Return the headline, spend/installs/CPI versus target table, week comparison, applied-change follow-up and next priorities. Scheduling belongs only to offer-weekly-ad-review.
Guardrails: never invent figures or apply account changes. Native files/terminal, web/browser or recipient-connected MCP only; disclose missing tools. Explicit yes before sending/posting/buying or external writes; never buy media.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
