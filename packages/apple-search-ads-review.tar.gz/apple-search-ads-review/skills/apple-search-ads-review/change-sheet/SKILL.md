---
name: change-sheet
description: "Use when the user approves recommendations."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Change sheet

When to use: Use when the user approves recommendations and wants them in a form they can apply in their ad account.

Inputs: recommendations the user explicitly approved, their source review/export, current values and account/campaign/group/keyword IDs.
1. Read approval scope and the dated draft in workspace/changes/. Ask one question at a time about ambiguous rows; do not treat general praise or silence as approval. Separate unapproved recommendations.
2. Build a dated manual-application CSV/table with row ID, entity IDs, storefront, action, match type where relevant, old/new bid or budget, currency, source rows, rationale, approval date and status. Preserve blanks as unknown rather than inventing current values.
3. Tool-check duplicate/conflicting edits, numeric deltas and budget totals against targets and the approved cap. Flag actions whose current value cannot be verified. Mark the sheet draft/manual application, not an upload-ready platform schema unless verified against current official documentation.
4. Show the sheet and unresolved risks; save locally with version/date. Never apply it to the ad account. Ask explicit yes for each scoped external post, message, task or document write, showing destination and exact content first. Use recipient-connected MCP only and read back the exact target after any approved write; if unavailable return a local draft.
5. When the user reports execution, append date, row IDs and their stated result to workspace/applied-log.csv. Distinguish reported from independently verified execution; never mark an action applied merely because approved.
Output: manual change sheet, validation findings, approval scope and pending items.
Guardrails: no invented data; no ad-account edits or media purchases. Native files/terminal and web/browser are available only if the recipient has them; disclose missing tools. No send/post/buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
