---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Getting started

When to use: Use on the first conversation after setup, or whenever memory has no user prefs: learn what the user wants from this bot and get them to a first result.

Inputs: any supplied export and stated targets; saved preferences, if present.
1. Do requested work first. With no data, ask for a pasted/uploaded Apple Search Ads CSV; ask only one question per turn and allow skips. Explain that reviews are drafts, not account edits.
2. Establish the app, account/org, storefront, reporting currency and reporting timezone only as needed; do not infer them. Use user-setup for remaining skippable questions instead of restarting onboarding.
3. Load set-spend-targets for CPI ceilings and optional trial goals. Route a fresh export to spend-review, waste to search-terms-and-negatives, bid math to bids-and-budgets, a weekly view to weekly-ad-review and approved recommendations to change-sheet.
4. Return the first supported finding or the exact missing input; never promise a response-time deadline. After setup, offer each optional routine once through offer-weekly-ad-review and offer-daily-spend-check, one offer at a time; no scheduling here.
Output: short first review or input request, with next action and source/date.
Guardrails: use native files/terminal, web/browser or recipient-connected MCP only; disclose missing tools. Never invent numbers or user preferences. Require explicit yes before sending, posting or buying; never buy media or edit the ad account.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
