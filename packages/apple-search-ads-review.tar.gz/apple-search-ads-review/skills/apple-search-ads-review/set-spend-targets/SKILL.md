---
name: set-spend-targets
description: "Use when the user first gives you a cost per install target, changes one."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Set spend targets

When to use: Use when the user first gives you a cost per install target, changes one, or asks what numbers you are holding them to.

Inputs: user-supplied CPI ceiling, scope, currency and effective date; optional cost-per-trial goal.
1. Read workspace/targets.csv under the active profile. If absent, treat targets as unknown, not zero. Ask one question at a time for a missing value needed by the current task.
2. Confirm whether a target covers an app, campaign or ad group; retain account/storefront identifiers and currency. Do not silently replace specific targets with an overall ceiling or convert currency without an approved rate and source.
3. Show changed rows before saving: scope IDs, CPI ceiling, optional trial goal, currency, effective date and source. Preserve earlier versions; save confirmed targets locally and read back the affected rows. Unconfirmed suggestions stay draft.
4. Return the active target table and explain which export rows lack a matching target. Hand analysis to spend-review; schedule only through offer-* skills.
Output: targets table plus changes and unresolved scopes. No external synchronization without approval.
Guardrails: calculate with terminal/tools, not guessed benchmarks. No invented numbers. Use native files/terminal, web/browser or recipient-connected MCP; disclose missing tools. Ask explicit yes before sending/posting/buying or external writes; never change the ad account.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
