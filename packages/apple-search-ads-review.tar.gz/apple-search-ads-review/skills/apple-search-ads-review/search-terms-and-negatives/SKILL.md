---
name: search-terms-and-negatives
description: "Use when the user wants to cut wasted search spend."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Search terms and negatives

When to use: Use when the user wants to cut wasted search spend, harvest new keywords, or build a negative keyword list on Apple Search Ads.

Inputs: search-term export with campaign/group, matched keyword, match type, spend, taps, installs, dates; confirmed targets and existing keyword/negative lists if available.
1. Validate data with spend-review; keep currencies, periods and storefronts separate. Distinguish the actual query from its matched keyword and preserve source rows.
2. Calculate term CPI with tools; label spend without installs separately. Inspect relevance to the user's app and target, asking one question at a time if intent is ambiguous. Low volume alone is not proof of waste; disclose attribution lag.
3. Separate proposed negatives from exact-keyword harvests and watch-list terms. Check existing lists for duplicates/conflicts when supplied; otherwise mark conflict checking incomplete. Specify campaign/group scope and proposed match type, explaining potential blocked relevant traffic. Verify current platform match behavior with official web/browser sources if needed; never guess syntax.
4. Return draft rows: term, source IDs/rows, period, spend/installs/CPI/target, proposed action and match type, rationale, uncertainty. Route approved rows to change-sheet; do not upload or apply them.
Guardrails: native files/terminal, web/browser or recipient-connected MCP only; disclose missing access. No invented evidence or universal cutoffs. Require explicit yes before sending/posting/buying or external writes; never buy media or edit the account.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
