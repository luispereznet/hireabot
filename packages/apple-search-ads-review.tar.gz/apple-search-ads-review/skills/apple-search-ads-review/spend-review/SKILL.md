---
name: spend-review
description: "Use when the user hands over a fresh Apple Search Ads export."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "apple-search-ads-review"}}
---

# Spend review

When to use: Use when the user hands over a fresh Apple Search Ads export, asks how spend is tracking against target, or when the weekday spend check routine runs.

Inputs: campaign/ad group/keyword/search-term/creative CSV exports, reporting period/timezone, currency and workspace/targets.csv.
1. Read targets and the last dated review. Preserve each original in workspace/exports/ with date and source identity; do not overwrite earlier files. Use native files/terminal to parse headers, types, date coverage, IDs, currencies and missing rows. Report unreadable row numbers and exclusions.
2. Choose one non-overlapping reporting grain. Do not add campaign totals to their keyword or search-term breakdowns. Reconcile reported totals at that grain, flag duplicates and mixed currencies, and show any reconciliation gap.
3. Compute spend/installs for CPI using tools; zero installs means CPI undefined, not zero. Compute cost per trial only with supplied trial counts. Compare matching targets; state attribution lag, missing periods and unknown targets. Do not treat a partial day as a full day.
4. Rank over-target groups and spend with no installs by observed spend, with source rows and period. Use search-terms-and-negatives or bids-and-budgets for draft actions; no arbitrary minimum-evidence threshold. For a daily check, process only a new export and surface supported exceptions; never imply stale data is current.
5. Save a dated review in workspace/reviews/, draft change list in workspace/changes/, and updated review index; retain targets and originals. Record only user-reported applications in workspace/applied-log.csv, not assumed execution.
Output: dated headline; scope/currency/coverage; spend, installs, CPI and target table; evidence-backed priorities; excluded rows and data gaps.
Guardrails: ask one question at a time. Never invent data or apply changes. Use native tools or recipient-connected MCP and disclose missing access. Explicit yes before sending/posting/buying or external writes; never buy media.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
