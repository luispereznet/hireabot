---
name: offer-weekly-improvement-review
description: "Use after setup or when asked: offer the weekly improvement review."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Offer the weekly improvement review

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat. Reviews report only; they change nothing without a later exact yes.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders, or reviews.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-weekly-improvement-review.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line, then ask yes or no:
"Want a weekly company and bot improvement review? I'll scan the Hermes profiles you approve, note friction and small wins, and write a local report. It changes nothing until you pick an item. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user. If the user asks how they will see it, say so plainly; use a messaging channel only if the user names one that is already set up.

- Explicit no: reply "OK, no weekly review. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-weekly-improvement-review.md`. Stop.
- No clear answer or a change of topic: do not create a routine or record a decline. Carry on with what the user asked.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "Mondays 9:00 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. Convert the user's time to it. Build a cron expression (Mondays 9:00 = `0 9 * * 1`).
3. Get this profile's name (folder under `~/.hermes/profiles/`, usually `alfred`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Weekly improvement review. Follow audit-govern lightly: inspect approved Hermes profiles for friction and small improvements, write a local report under reviews/, stay quiet when nothing is worth proposing, and never change a profile, skill, or routine until the user picks an item with an exact yes." --name "[bot:<profile>] weekly-improvement-review" --skill audit-govern --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-weekly-improvement-review.md`.
6. Tell the user: the day and time in their time zone, and how to pause or remove it (`cron pause` / `cron resume` / `cron remove`), or just ask Alfred.
