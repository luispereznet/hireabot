---
name: system-design
description: "Use after an approved workflow decision needs a Hermes bot or skill design."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Hermes system design

Use only after the user approves a Workflow Decision Brief, when that decision needs a Hermes bot, skill, routine, or small multi-bot handoff design.

Working folder: `~/.hermes/profiles/alfred/workspace`. Drafts under `org/<YYYY-MM-DD>-design-<slug>/`.

## Inputs required

- Path to the approved `decision-brief.md`
- Exact yes quoting that brief (or a clear approval of that version)

If either is missing, stop and ask. Do not design from a vague request.

## Design rules

- One job. One voice. Explicit anti-jobs. No leftover tools. No stub skills.
- Prefer a skill when a parent bot already owns the outcome.
- A routine is eligible only after the manual workflow already worked, the trigger is stable, sources are reliable, a human owner exists, missing/stale/retry/duplicate/approval behavior is defined, and a safe test plan exists.
- Recommended new bots are Hermes profiles: `SOUL.md`, `MEMORY.md`, `skills/`, `bot.yaml` / `profile.yaml` specs. Package shape omits USER.md, config.yaml, cron, auth, .env, BOOTSTRAP, AGENTS.
- Shipped copy never names other agent platforms, plugins, or creators.

## Write the build pack

Create a versioned folder `build-pack-v<N>/` with:

1. `SUMMARY.md` — what will be built, why, and what stays human-owned
2. For a new bot: draft `SOUL.md`, `memories/MEMORY.md` (under 2200 chars), `bot.yaml`, `README.md`, skill SKILL.md files with real steps, and onboarding/user-setup if needed
3. For a skill-only change: the SKILL.md and which existing profile receives it
4. For a routine: offer wording, suggested schedule in the user's time zone, cron prompt, and `--deliver local` default
5. `TEST-PLAN.md` — how to pilot without activation as the first test
6. `APPROVAL.md` — exact actions that still need a yes (create profile, save skill, create cron, activate)

## Stop at the approval gate

Show the build pack path and audit checklist. Do not write under `~/.hermes/profiles/<other>/`, do not create cron, and do not install. On approval of the build pack, load `pilot-test`. If the user wants a package handoff, note they should run `python3 <factory-scripts>/audit_bot.py` on the package before install — still only after the exact yes.
