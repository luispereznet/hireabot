---
name: audit-govern
description: "Use for a noisy bot, stale skill, failing routine, or portfolio drift."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Audit, repair, and govern

Use for a noisy or inaccurate bot, stale skill, failing routine, duplicated bots, unclear ownership, portfolio drift, permission drift, weak value, or a company change that may have made the bot organization outdated.

Working folder: `~/.hermes/profiles/alfred/workspace`. Reports under `reviews/<YYYY-MM-DD>-audit/`.

## Inspect

1. Ask which Hermes profiles to include. Default: all under `~/.hermes/profiles/`. Confirm before reading.
2. For each approved profile, read available: `SOUL.md`, `MEMORY.md`, `profile.yaml`, `skills/**/SKILL.md`, non-secret `config.yaml` keys. Read `USER.md` only with an explicit yes.
3. List routines with `hermes -p <profile> cron list` when available. Note failures the user reports; do not invent failure rates.
4. Do not claim a full account scan unless those profiles were actually read.

## Classify

For each bot or skill, recommend one of: Keep, Improve, Merge, Reposition, Pause, Hide, Retire, Investigate.

Evidence required: one concrete observation (file line, skill name, routine schedule, user-reported symptom). Prefer Improve or Merge over Create. Prefer a skill over a new bot when a parent already owns the outcome.

## Report

Write `portfolio-audit.md`:

- Scope (profiles read / skipped)
- Findings grouped by theme (duplicate jobs, unclear ownership, stub skills, noisy routines, weak value)
- Classification table
- Proposed repairs ordered by smallest sufficient intervention
- Exact yes list (each change named separately)

## After the report

Show recommendations. Wait. Change nothing without an exact yes for that exact action and target. Never delete a bot automatically. Hiding or pausing is a separate yes from editing. Never request secrets in chat.
