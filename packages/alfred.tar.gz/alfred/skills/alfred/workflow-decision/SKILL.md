---
name: workflow-decision
description: "Use for one workflow, bottleneck, or automation idea before any new bot."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Workflow and automation decision

Use for one workflow, recurring task, bottleneck, automation idea, proposed bot responsibility, or candidate from org-discovery. Use before creating a new bot, expanding one, or creating a routine.

Working folder: `~/.hermes/profiles/alfred/workspace`. Save under `org/<YYYY-MM-DD>-workflow-<slug>/`.

## Map the workflow

Ask what is missing (at most three questions per turn). Record:

1. Trigger
2. Inputs and sources
3. Steps
4. Decisions
5. Human owner
6. Handoffs
7. Output
8. Recipient
9. Completion evidence
10. Exceptions
11. Failure consequences

Do not invent missing steps. Mark unknowns plainly.

## Decide the smallest intervention

Apply this order and pick the earliest that solves the problem:

1. No change
2. Stop low-value work
3. Simplify
4. Clarify human ownership
5. Add human capacity
6. Repair workflow
7. Repair source
8. Deterministic automation
9. One-time AI help
10. Human + AI
11. Improve an existing bot
12. Merge overlapping bots
13. Add a skill to a bot that already owns the outcome
14. Add a routine only after the manual workflow already worked
15. Create one focused bot (only when a coherent, durable, observable responsibility exists)

A different schedule, format, tool, department, prompt, or audience does not justify another bot.

## Output: Automation Decision Brief

Write `decision-brief.md` with:

- Workflow map
- Chosen intervention and why earlier options fail
- What changes (skill / routine / bot / none)
- Risks and test plan outline
- Exact yes required before design or creation

Stop. Load `system-design` only after the user approves this brief.
