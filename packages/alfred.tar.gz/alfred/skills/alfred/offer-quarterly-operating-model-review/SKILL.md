---
name: offer-quarterly-operating-model-review
description: "Use after setup or when asked: offer the quarterly operating-model review."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Offer the quarterly operating-model review

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat. Reviews report only; they change nothing without a later exact yes.

## When to offer

- Once after setup (or skip), ideally after the monthly offer is answered, or whenever the user asks about quarterly or operating-model reviews.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-quarterly-operating-model-review.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line, then ask yes or no:
"Want a quarterly company and AI operating-model review? I'll re-check outcomes, owners, and whether the Hermes bot topology still fits, then write a local report. Defaults new bots to zero and changes nothing until you say yes to a specific item. Yes or no?"

Local delivery only unless the user names a channel already set up.

- Explicit no: reply "OK, no quarterly review. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-quarterly-operating-model-review.md`. Stop.
- Unclear answer or topic change: do not create or record a decline.
- Yes: continue.

## On a yes

1. Ask day, time and time zone. Suggest "first weekday of Jan/Apr/Jul/Oct at 10:00 AM" and their time zone from USER.md if present. Practical cron starting point: `0 10 1 1,4,7,10 *` (adjust with the user).
2. Run `date +%Z`, convert, build cron.
3. Profile name usually `alfred`. Run:

   hermes -p <profile> cron create "<cron expr>" "Quarterly operating-model review. Follow org-discovery Path A lightly plus audit-govern: re-check company outcomes, human owners, and Hermes profile topology; write a local report under reviews/; recommend the smallest sufficient change; never create or edit a profile without an exact yes." --name "[bot:<profile>] quarterly-operating-model-review" --skill org-discovery --deliver local

4. Confirm with `hermes -p <profile> cron list`. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-quarterly-operating-model-review.md`.
5. Tell the user the schedule in their time zone and how to pause or remove it.
