---
name: org-discovery
description: "Use when starting from zero or redesigning the Hermes bot organization."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Org discovery and architecture

Goal: the smallest Hermes bot topology that matches real company outcomes, with clear human owners and no duplicate jobs. Never ask "what bots do you want?"

Working folder: `~/.hermes/profiles/alfred/workspace`. Save drafts under `org/<YYYY-MM-DD>-discovery/`. Archive before replacing.

## Collect (at most three material questions per turn)

1. Company scope (what the company sells or does, and who it serves).
2. Whether they already have Hermes bots (yes / no / unsure).
3. The three most important company outcomes right now.
4. Human owners for those outcomes (names or roles).
5. Time zone.
6. Where advice and reports should land (chat only, a folder, or a named channel already set up).
7. Registry source if they want one (a note file or sheet they name; never assume).
8. Approval boundaries (what Alfred may draft alone vs what always needs an exact yes).

A rough answer is enough. Skip any question they already answered. Do not invent owners or outcomes.

## Path A — existing Hermes bots

1. Ask which profiles to include (default: all under `~/.hermes/profiles/`). Confirm before reading.
2. For each approved profile, read what exists among: `SOUL.md`, `MEMORY.md`, `USER.md` (only with an explicit yes for USER.md), `config.yaml` (non-secret keys only), `skills/`, `profile.yaml`.
3. Map: job, skills, any routines found via `hermes -p <profile> cron list` when available, owner if known, sources, handoffs, and value to the three outcomes.
4. Classify each bot: Keep, Improve, Merge, Reposition, Pause, Hide, Retire, or Investigate. One line of evidence per classification.
5. Do not claim a full scan unless those profiles were actually read. Say which were skipped and why.

## Path B — starting from zero

1. Do not ask for a bot wish list.
2. From outcomes → value streams → required capabilities → human ownership → workflows → sources → AI opportunities.
3. Recommend the smallest topology. Default new-bot count to zero. Prefer skills on an existing or single focused bot over many bots.
4. Show intervention order used: no change → stop low-value work → simplify → clarify ownership → … → create one focused bot only when necessary.

## Output

Write `org/<YYYY-MM-DD>-discovery/brief.md` with:

- Outcomes and owners (labeled as user-provided or assumed)
- Current map (Path A) or proposed topology (Path B)
- Classifications / recommendations
- Open questions
- What needs an exact yes next

Change nothing live. Stop at the approval gate.
