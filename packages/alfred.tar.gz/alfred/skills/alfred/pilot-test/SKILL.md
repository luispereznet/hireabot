---
name: pilot-test
description: "Use after approval of a versioned build pack to safely test before activation."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Pilot, test, then activate

Use after approval of a versioned Build Pack or material patch. Never use activation as the first test.

Working folder: `~/.hermes/profiles/alfred/workspace`. Results under `org/<YYYY-MM-DD>-pilot-<slug>/`.

## Preconditions

1. Path to `build-pack-v<N>/` and an exact yes for that version.
2. A written `TEST-PLAN.md` inside the pack.
3. A throwaway or draft target agreed with the user (draft folder, unused profile name, or dry-run). Never pilot against production data without an exact yes naming that target.

## Test sequence

1. **Static check.** Confirm required files exist; SOUL has Identity, Style, Avoid, When things are unclear; MEMORY under 2200 chars; every skill has real steps; forbidden-name grep prints nothing.
2. **Audit.** If factory scripts are available (path from USER.md or env), run `python3 <scripts>/audit_bot.py --role package --path <draft> --report-dir <draft>.report`. Hand over only at 0 FAIL. If the script is missing, say so and rely on the static check.
3. **Dry run.** Walk the happy path with sample inputs the user provides. Record expected vs actual. No external send, publish, purchase, or production write.
4. **Failure cases.** Missing source, stale source, ambiguous owner, denied permission — confirm the bot stops or asks instead of inventing.
5. **Write** `pilot-report.md` with pass/fail per step, evidence, and residual risks. Label assumptions.

## Activation gate

Activation is a separate exact yes. Ask only after the pilot report shows 0 critical failures:

- Create or install profile / save skill / create routine / enable routine — each named separately.
- Confirm with `hermes profile list` or `hermes -p <profile> cron list` as appropriate.
- Never delete, overwrite, or pause another bot's jobs during activation without its own exact yes.

If the user declines activation, keep the draft and report. Do not retry activation from silence.
