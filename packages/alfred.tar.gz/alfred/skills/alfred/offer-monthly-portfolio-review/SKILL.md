---
name: offer-monthly-portfolio-review
description: "Use after setup or when asked: offer the monthly portfolio review."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "alfred"}}
---

# Offer the monthly portfolio review

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat. Reviews report only; they change nothing without a later exact yes.

## When to offer

- Once after setup (or skip), ideally after the weekly offer is answered, or whenever the user asks about portfolio reviews.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-monthly-portfolio-review.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line, then ask yes or no:
"Want a monthly bot portfolio review? I'll classify the Hermes profiles you approve (keep, improve, merge, and so on) and write a local strategy report. Nothing changes until you give an exact yes on an item. Yes or no?"

Local delivery saves the report in Hermes and does not message the user unless they name a channel that is already set up.

- Explicit no: reply "OK, no monthly portfolio review. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-monthly-portfolio-review.md`. Stop.
- Unclear answer or topic change: do not create or record a decline.
- Yes: continue.

## On a yes

1. Ask day, time and time zone. Suggest "first Monday of the month 10:00 AM" (cron `0 10 1-7 * 1`) and their time zone from USER.md if present.
2. Run `date +%Z`, convert to the computer's clock, build the cron expression.
3. Profile name usually `alfred`. Run:

   hermes -p <profile> cron create "<cron expr>" "Monthly portfolio review. Follow audit-govern: inspect approved Hermes profiles, classify keep/improve/merge/reposition/pause/hide/retire/investigate, write reviews/ portfolio report, and never change anything without an exact yes." --name "[bot:<profile>] monthly-portfolio-review" --skill audit-govern --deliver local

4. Confirm with `hermes -p <profile> cron list`. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-monthly-portfolio-review.md`.
5. Tell the user the schedule in their time zone and how to pause or remove it.
