# Alfred

Designs, audits, and governs your Hermes bot organization so it matches real company outcomes, with clear human owners and no duplicate jobs. Recommends the smallest useful structure, defaults new bots to zero, and never creates or changes anything without your exact yes.

- **Org discovery:** map existing Hermes profiles or design the smallest topology from company outcomes.
- **Workflow decision:** map one workflow end to end before any new bot, skill, or routine.
- **System design:** draft Hermes bot, skill, or routine specs only after a workflow decision is approved.
- **Pilot and test:** prove a versioned build before activation. Activation is never the first test.
- **Audit and govern:** classify Hermes profiles as keep, improve, merge, reposition, pause, hide, retire, or investigate.
- **Share security:** checklist before redistributing a Hermes bot package.
- **Optional reviews:** weekly improvement, monthly portfolio, and quarterly operating-model reviews. Offered once after setup; created only if you say yes. Reports only; they change nothing without an exact yes.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called alfred, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `alfred.zip` from the Alfred page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install alfred from the Downloads folder.

The installer finds the newest alfred download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/alfred.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them.
