---
name: collect-local
description: "Use when packing allowed files on the user's computer."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Collect local files

Pack allowed config and project files from Claude Cowork, Codex, ChatGPT desktop/local data, and OpenClaw on the user's computer. Use Hermes local filesystem and shell access on the machine where this profile runs. Do not invent platform-specific remote machine or box-copy tools.

## Allowed (pack these)

- Claude / Cowork: project folders the user names, exported chats, local project settings that are not credential stores.
- Codex: project notes, agent configs without secrets, conversation exports.
- ChatGPT: official export zip if already on disk; local conversation backups the user points to.
- OpenClaw: workspace configs and skill folders without auth files.
- Never pack: `.env`, keychains, `credentials`, `auth.json`, token files, browser cookie stores, SSH keys, wallet data.

## Steps

1. Detect OS (macOS, Linux, Windows) via a short shell check. Note paths in `state.md`.
2. Ask the user which project folders to include if not already listed. Default to known app data locations for the four source tools only; skip anything missing.
3. Build a staging folder under `workspace/migration/pack/local/`. Copy allowed files there. Prefer `cp -R` / `robocopy` style copies; never delete source files.
4. Run the scrub helper from the import-scripts skill over the staging folder. Re-run until the scrub report is clean.
5. Write a short inventory note of what was packed (counts only for internal notes). If local access is refused or unavailable, stop and load fallback-collect-script.
