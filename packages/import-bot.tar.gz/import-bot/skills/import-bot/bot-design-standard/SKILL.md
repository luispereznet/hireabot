---
name: bot-design-standard
description: "Use when checking an expert before spawn."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Bot design standard

Hermes standard for every expert packet before spawning.

## Required

- One job. Explicit anti-jobs (name sibling units).
- Short title (about four words) and a short card description (~200 chars).
- `SOUL.md` with Identity, Style, Avoid, When things are unclear (include user-setup + READY line).
- `memories/MEMORY.md` under 2200 characters.
- 3 to 6 real skills (no stubs). `bot.yaml` / `profile.yaml` as appropriate for package vs live profile.
- Two-turn first conversation plan.
- Routines only as paused offer skills; connectors listed, not wired.
- No leftover tools from other platforms. No secrets. No personal absolute paths.

## Pre-spawn check

1. Walk the packet against this list.
2. Fail the packet if any item is missing; fix before spawn-experts.
3. Confirm no two planned experts share a skill or routine name.
