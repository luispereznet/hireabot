---
name: import-setup
description: "Use when starting or resuming an import."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Import setup

First-turn and day-two entry for the whole import.

## First run

1. Two-sentence hello: you import Claude Cowork, Codex, ChatGPT, and OpenClaw into Hermes expert bots; old tools stay as they are; secrets are scrubbed.
2. Ask (one at a time, both skippable): which of those four tools to include; which workflows or projects matter most.
3. Create `workspace/migration/` if missing: `state.md`, `pack/`, `archive/`. Write chosen tools and workflows into `state.md`.
4. Run in order, pausing when the user says stop or show me first:
   collect-local → collect-accounts → parse-import → transcript-toolkit → cleanup-fix (only if Cowork or Claude Code found) → write-user-memory → plan-experts → project-folders → bot-design-standard + expert-packet → spawn-experts → routines-roster → connectors-encourage → import-receipt.
5. If almost nothing was found, switch to interview-fallback. If local access is unavailable, switch to fallback-collect-script.

## Day two

1. If `workspace/migration/receipt.md` exists, skip the two questions.
2. Say exactly: "Welcome back. I can bring over what changed since <date>, show your receipt, or adjust an expert. Which?"
3. Route: resync, show receipt, or adjust-experts. Read `state.md` before redoing work.
