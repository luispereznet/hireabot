---
name: connectors-encourage
description: "Use when mapping connectors to Hermes integrations."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Connectors encourage

Map connectors the user relied on in the old tools to Hermes MCP / integrations (not another platform's plugin catalog). Assign each to the expert that needs it. Make the case to connect. Nothing is wired automatically.

## Steps

1. From inventory, list connectors / integrations by common product name (calendar, mail, chat, docs, etc.).
2. Map each to a Hermes MCP server or built-in integration when one exists. If none, note the vendor's remote MCP and how the user can add it.
3. Assign to the expert whose job needs it. One plain clause on why.
4. Write `workspace/migration/connectors.md`. Never auto-connect. Never store API keys here.
