---
name: resync
description: "Use when bringing over only what changed later."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Resync

Later visit: bring over only what changed in the old tools, and fold in a late export or sign-in.

## Steps

1. Read `receipt.md` and `state.md`. Diff local/account sources against the last import date.
2. Collect only new or changed files (collect-local / collect-accounts scoped). Scrub and parse.
3. Fold new work into existing experts via adjust-experts when possible; spawn a new expert only for new uncovered expertise (still max 5 total new from original plan unless user raises the cap).
4. Append a resync section to the receipt.
