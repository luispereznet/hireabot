---
name: project-folders
description: "Use when placing imported project folders."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Project folders

For every project that used a folder on the user's computer: choose a home.

## Options (ask per project if unclear)

1. Copy into this profile's workspace under `migration/projects/<name>/` (never delete the original).
2. Leave in place; read on request via local filesystem.
3. Point at a cloud drive the user already uses.

## Steps

1. From inventory, list project folders.
2. For each, record the choice in `state.md` and `plan.md`.
3. Copy only when chosen. Scrub after copy. Never move or delete the source.
