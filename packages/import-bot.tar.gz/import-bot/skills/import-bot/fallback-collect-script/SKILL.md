---
name: fallback-collect-script
description: "Use when local filesystem access is unavailable."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Fallback collect script

When local access is unavailable: give the user a collector for their system, then bring the archive in without direct local access.

## Steps

1. Detect OS from what the user tells you.
2. From the import-scripts skill, provide the matching collector for macOS, Linux, or Windows. Tell them to run it themselves and place the zip where Hermes can read it (Downloads, or paste a path).
3. Do not run privileged installers. Do not ask for passwords to store.
4. When the archive arrives, scrub, then continue parse-import.
5. Admin-cap path: the zip may arrive via Drive or email the user controls; plus account exports via collect-accounts.
