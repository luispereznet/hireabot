---
name: interview-fallback
description: "Use when little was importable and answers must fill gaps."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Interview fallback

When there is little to import or a gap remains: six questions, then memory and experts from the answers.

## Questions (one at a time, all skippable)

1. What work do you want covered first?
2. Which recurring tasks or routines matter weekly?
3. What should these bots never do?
4. Any tools or inboxes they must connect to?
5. Existing Hermes bots to extend?
6. Voice preference for the experts?

## Then

1. Distill answers into write-user-memory proposals.
2. Plan at most a few experts from the answers (still existing-bots first).
3. Continue with expert-packet → spawn-experts as usual.
