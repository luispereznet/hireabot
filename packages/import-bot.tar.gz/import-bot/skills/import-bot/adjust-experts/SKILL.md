---
name: adjust-experts
description: "Use when renaming, merging, splitting, or adding experts."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Adjust experts

After experts exist: rename, move a project, merge, split, or add.

## Steps

1. Confirm which expert(s) with the user.
2. Rename: update folder slug only after archive copy; fix SOUL/README display names.
3. Move a project: update project-folders choice and packet notes; copy files if needed; never delete the source.
4. Merge: combine jobs only when still one job; otherwise refuse and suggest a clearer split.
5. Split / add: run plan-experts + bot-design-standard + spawn-experts for the new piece; audit before handoff.
6. Live profile changes need a yes for that bot. Re-audit after edits.
