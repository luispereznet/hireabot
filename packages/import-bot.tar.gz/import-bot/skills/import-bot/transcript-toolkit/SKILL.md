---
name: transcript-toolkit
description: "Use when normalizing transcripts into one shape."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Transcript toolkit

Normalize every imported transcript into one shape, search across sessions, and build each expert's history seed.

## Shape

Each session file under `workspace/migration/pack/transcripts/`:
- `id`, `source` (one of the four tools), `title`, `started_at`, `messages[]` with `role` and `text` (scrubbed).

## Steps

1. Run the normalize helper from the import-scripts skill on account and local conversation files.
2. Drop unreadable or empty sessions; note the count in `state.md`.
3. Index titles and first-user lines for planning. Do not dump transcripts into chat.
4. When plan-experts names an expert, write a short history seed skill or reference file for that expert from matching sessions only. Cap size; keep originals in the pack.
