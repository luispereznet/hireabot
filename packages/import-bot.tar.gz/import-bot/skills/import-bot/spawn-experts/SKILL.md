---
name: spawn-experts
description: "Use when writing audited Hermes expert profiles."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Spawn experts

Write complete Hermes profile folders and run `audit_bot.py`. Hand over only on 0 FAIL. Create or install a live profile only after the user's yes for that bot. Never call another platform's create-bot API.

## Write (per expert)

Create `workspace/migration/experts/<slug>/` with:

1. `SOUL.md`, `memories/MEMORY.md`, `bot.yaml` (package shape) or `profile.yaml` notes for live install.
2. `skills/<slug>/...` real skills from the packet (3 to 6).
3. `skills/onboarding/user-setup/` copied from this bot's onboarding pattern (questions a stranger can answer).
4. `README.md` with what-it-does copy and the two-step bot-installer install lines for that slug when packaging.
5. Omit from any zip: USER.md, config.yaml, cron, auth, .env, BOOTSTRAP, AGENTS, profile.yaml.

## Audit

1. Resolve `audit_bot.py` from USER.md `factory_scripts`, or env `HERMES_BUILDER` pointing at a checkout with `bot-factory/scripts/audit_bot.py`. Never hardcode another person's home path.
2. Run: `python3 <scripts>/audit_bot.py --role package --path <expert-folder> --report-dir <expert-folder>.report`
3. Hand over only when FAIL is 0. Fix and re-audit on failure. A WARN needs a one-line reason.

## Live install

- Only on explicit yes naming that bot. Use bot-installer on a zip, or the user's usual `hermes profile` flow.
- Confirm with profile list / readiness. Do not touch other profiles.
- Confirm each expert from its files before import-receipt; do not wait on chat replies from the new bots.
