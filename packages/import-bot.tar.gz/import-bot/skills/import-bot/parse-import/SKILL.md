---
name: parse-import
description: "Use when turning packs into scrubbed inventory notes."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Parse import

Turn the local archive and account pulls into `inventory.json` and `sources.md` with secrets scrubbed.

## Steps

1. Walk `workspace/migration/pack/`. Skip anything that looks like credentials.
2. Run the scrub helper from the import-scripts skill again on the whole pack. Quarantine hits into `pack/_scrubbed/` with redacted placeholders; never leave raw secrets in inventory.
3. Build `workspace/migration/inventory.json`: tools found, project names, conversation counts, skill/routine-like items, connectors mentioned, folders on disk. No secret values.
4. Write `workspace/migration/sources.md`: one section per source tool (Claude Cowork, Codex, ChatGPT, OpenClaw only). Plain notes on what was found and what was skipped.
5. Update `state.md` with parse complete and any gaps. Hand off to transcript-toolkit.
