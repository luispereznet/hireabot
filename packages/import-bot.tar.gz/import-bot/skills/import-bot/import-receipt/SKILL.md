---
name: import-receipt
description: "Use when finishing an import and writing the receipt."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Import receipt

End of a successful import: confirmed counts, who owns what, routines to start, connectors to connect, then clean up staging noise (archive, never delete sources).

## Steps

1. Write `workspace/migration/receipt.md`: date, tools imported, experts created or updated, retention-fix line, open connector asks, paused routines.
2. Tell the user the outcome in plain words (no file dumps).
3. Move spent staging intermediates into `workspace/migration/archive/<timestamp>/`. Keep pack originals and receipts.
4. Update `state.md` to complete. Ready for day-two resync.
