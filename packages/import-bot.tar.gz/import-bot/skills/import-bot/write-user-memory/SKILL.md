---
name: write-user-memory
description: "Use when distilling old-tool facts into Hermes memory."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Write user memory

When the end user runs this bot: distill what the old tools knew about them into Hermes `memories/USER.md` / profile memory. Show the list. Keep originals verbatim in the pack. Do not bake any person's facts into a shareable package.

## Caps

- At most 16 short profile facts (~150 chars each) and 5 log facts (~200 chars), fewer when others already exist.
- Originals stay in `workspace/migration/pack/memories.md` verbatim (after scrub).

## Steps

1. Read existing Hermes USER.md / memory if present. Never overwrite silently; merge with show-and-confirm.
2. Mine scrubbed sources for stable facts (name preference, timezone, recurring projects, standing rules). Skip secrets and one-off chatter.
3. Show the proposed list in plain words. Strike any line on request.
4. Write only after the user confirms. Update `state.md`.
