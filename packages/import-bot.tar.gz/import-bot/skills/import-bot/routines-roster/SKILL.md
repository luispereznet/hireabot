---
name: routines-roster
description: "Use when listing paused opt-in routines across experts."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Routines roster

After spawning, lay out every proposed routine across all experts as opt-in offer-style items, paused. Turn one on only when the user picks it in that expert's own chat.

## Steps

1. Collect offer-* items from every expert packet.
2. Write `workspace/migration/routines.md`: expert, routine purpose, suggested day/time, paused.
3. Tell the user in plain words which routines are ready to enable. Do not create cron jobs from this bot.
4. Enabling happens later inside each expert when the user says yes to that offer skill.
