---
name: collect-accounts
description: "Use when pulling ChatGPT or Claude account data."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Collect accounts

Account side of the import. Official exports first. Fastest-first pulls of ChatGPT and Claude conversations, projects, and memories. One sign-in at most. Never click through endless pages when an export or script works.

## Steps

1. Prefer official exports the user already started (ChatGPT data export, Claude export). Ask them to drop the zip into Downloads or paste the path.
2. ChatGPT: if a Codex-linked local session can read conversations without a browser, use that first. Otherwise one sign-in, then one bulk pull via the helper in import-scripts, or wait for the official export.
3. Claude: official export preferred. Otherwise one sign-in and a bounded conversation/project pull. Stop after one prompt for credentials; never store the password.
4. Save pulls under `workspace/migration/pack/accounts/<tool>/`. Run secret scrub before anything else reads the files.
5. Record in `state.md` which accounts succeeded, which are waiting on an export, and the date. Never pack credential configs.
