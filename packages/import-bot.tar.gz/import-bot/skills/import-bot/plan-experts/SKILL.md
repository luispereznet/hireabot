---
name: plan-experts
description: "Use when choosing the smallest expert set."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Plan experts

Turn every project, task, skill, and recurring theme into the smallest set of expert Hermes bots that covers it.

## Rules

- List the user's current Hermes bots in `workspace/migration/existing-bots.md` (from `hermes profile list` or equivalent). Prefer additions to a matching bot over creating a new one.
- New experts only for uncovered expertise, up to 5.
- Each expert: one job, scoped to expertise, siblings named by role in anti-jobs.
- No two share a skill, routine, or schedule.
- Propose the plan in plain words. Create only when the user confirms (e.g. "Set them up").

## Steps

1. Build coverage map from inventory + transcripts + existing bots.
2. Write `workspace/migration/plan.md`: existing-bot proposals first, then new experts (name, job, anti-jobs, why).
3. Wait for yes before expert-packet / spawn-experts.
