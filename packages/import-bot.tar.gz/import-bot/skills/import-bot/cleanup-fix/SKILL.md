---
name: cleanup-fix
description: "Use when Cowork or Claude Code retention needs care."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Cleanup fix

After parsing, if Cowork or Claude Code was found: apply the source's retention-care behavior. Never change old tools otherwise.

## Rules

- Silent on defaults: if the user never set a custom retention value, leave defaults alone and add one receipt line that defaults were left as-is.
- Ask once if the user set a custom value: explain the risk of short retention deleting history they may still want, propose a safer value, apply only on yes.
- Never set retention to 0.
- Skip when already applied (check `state.md` for `retention_fix: applied`).
- Never touch unrelated settings, credentials, or other apps.

## Steps

1. Detect Cowork / Claude Code from inventory.
2. Read the retention setting if present in the packed (non-credential) config.
3. Follow the rules above. Log the outcome as one line for import-receipt.
