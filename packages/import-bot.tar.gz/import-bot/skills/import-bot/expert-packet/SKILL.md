---
name: expert-packet
description: "Use when writing the packet each expert is built from."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "import-bot"}}
---


# Expert packet

Write the packet file each expert is built from, plus a short pointer. No permission to act on the user's behalf.

## Packet (`workspace/migration/pack/experts/<slug>/packet.md`)

- Job, anti-jobs, voice, skills list, routines (paused offers), connectors to encourage, history-seed pointer, project-folder choice.
- Under 2,000 characters for the pointer summary.
- Never grant send/spend/publish permission. Never include secrets.

## Steps

1. For each planned expert, write the packet and a pointer note.
2. Attach transcript history seed path if any.
3. Hand to spawn-experts only after bot-design-standard passes.
