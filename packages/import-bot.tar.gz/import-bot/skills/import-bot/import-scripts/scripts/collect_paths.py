#!/usr/bin/env python3
"""Print candidate allowed paths for Claude Cowork, Codex, ChatGPT, OpenClaw on this OS."""
from __future__ import annotations
import os, platform, sys
from pathlib import Path

home = Path.home()
system = platform.system()
cands = []
if system == "Darwin":
    cands += [
        home / "Library/Application Support/Claude",
        home / "Library/Application Support/Codex",
        home / "Library/Application Support/ChatGPT",
        home / ".codex",
        home / ".claude",
        home / ".openclaw",
        home / "Documents/Claude",
        home / "Downloads",
    ]
elif system == "Linux":
    cands += [
        home / ".config/Claude",
        home / ".config/codex",
        home / ".config/ChatGPT",
        home / ".codex",
        home / ".claude",
        home / ".openclaw",
        home / "Downloads",
    ]
else:
    app = Path(os.environ.get("APPDATA", str(home)))
    cands += [
        app / "Claude",
        app / "Codex",
        app / "ChatGPT",
        home / ".codex",
        home / ".claude",
        home / ".openclaw",
        home / "Downloads",
    ]

print(f"OS={system}")
for p in cands:
    print(("EXISTS" if p.exists() else "MISSING"), p)
