#!/bin/bash
# User-run collector for Linux.
set -euo pipefail
OUT="${HOME}/Downloads/hermes-import-pack-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUT"
echo "Copy allowed project folders into: $OUT"
echo "Then run: tar -czf "${OUT}.tar.gz" -C "$(dirname "$OUT")" "$(basename "$OUT")""
echo "Do not copy .env, auth.json, or credential stores."
