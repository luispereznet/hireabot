# User-run collector for Windows PowerShell.
$stamp = Get-Date -Format "yyyyMMdd-HHmmss"
$out = Join-Path $env:USERPROFILE "Downloads\hermes-import-pack-$stamp"
New-Item -ItemType Directory -Path $out | Out-Null
Write-Host "Copy allowed project folders into: $out"
Write-Host "Then zip that folder. Do not copy .env, auth.json, or credential stores."
