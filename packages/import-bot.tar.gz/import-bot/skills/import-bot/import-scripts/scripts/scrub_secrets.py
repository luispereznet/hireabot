#!/usr/bin/env python3
"""Redact common secret patterns under a folder. Report only; never print secret values."""
from __future__ import annotations
import argparse, re, sys
from pathlib import Path

PATTERNS = [
    ("openai_anthropic_key", re.compile(r"\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{20,}")),
    ("slack_token", re.compile(r"\bxox[abposr]-[A-Za-z0-9-]{10,}")),
    ("github_token", re.compile(r"\b(?:ghp|gho|ghu|ghs|github_pat)_[A-Za-z0-9_]{20,}")),
    ("aws_access_key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("google_api_key", re.compile(r"\bAIza[0-9A-Za-z_-]{35}\b")),
    ("private_key_block", re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----.*?-----END [A-Z ]*PRIVATE KEY-----", re.S)),
    ("bearer", re.compile(r"Bearer\s+[A-Za-z0-9._~+/=-]{20,}")),
    ("assignment", re.compile(r"(?im)^(\s*[\w.-]*(?:api[_-]?key|secret|password|passwd|token)[\w.-]*\s*[:=]\s*)([\"']?)([^\s\"']{12,})(\2)")),
]
SKIP = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf", ".zip", ".gz", ".db", ".pyc", ".woff", ".woff2"}

def scrub_text(text: str) -> tuple[str, list[str]]:
    hits = []
    out = text
    for label, pat in PATTERNS:
        if label == "assignment":
            def repl(m):
                hits.append(label)
                return f"{m.group(1)}{m.group(2)}<redacted>{m.group(4)}"
            out, n = pat.subn(repl, out)
            continue
        if pat.search(out):
            hits.append(label)
            out = pat.sub("<redacted>", out)
    return out, hits

def main() -> int:
    ap = argparse.ArgumentParser(description="Scrub secrets under a folder")
    ap.add_argument("root", type=Path)
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    root = args.root.expanduser().resolve()
    if not root.is_dir():
        print(f"NOT_A_DIR {root}", file=sys.stderr)
        return 2
    total = 0
    changed = 0
    for f in root.rglob("*"):
        if not f.is_file() or f.suffix.lower() in SKIP or f.stat().st_size > 5_000_000:
            continue
        try:
            raw = f.read_text(errors="ignore")
        except OSError:
            continue
        new, hits = scrub_text(raw)
        if not hits:
            continue
        total += len(hits)
        print(f"{f.relative_to(root)}: {', '.join(sorted(set(hits)))}")
        if new != raw and not args.dry_run:
            f.write_text(new)
            changed += 1
    print(f"DONE hits={total} files_rewritten={changed} dry_run={args.dry_run}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
