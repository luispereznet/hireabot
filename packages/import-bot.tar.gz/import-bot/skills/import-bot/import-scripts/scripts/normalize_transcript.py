#!/usr/bin/env python3
"""Normalize common chat export JSON/JSONL into a simple session schema."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

def as_messages(obj):
    if isinstance(obj, list):
        msgs = []
        for m in obj:
            if isinstance(m, dict):
                role = m.get("role") or m.get("author") or m.get("speaker") or "user"
                text = m.get("text") or m.get("content") or m.get("message") or ""
                if isinstance(text, list):
                    text = " ".join(str(x) for x in text)
                msgs.append({"role": str(role), "text": str(text)})
        return msgs
    if isinstance(obj, dict):
        for key in ("messages", "mapping", "items", "conversations"):
            if key in obj:
                return as_messages(obj[key])
    return []

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("src", type=Path)
    ap.add_argument("dest", type=Path)
    ap.add_argument("--source-label", default="unknown")
    args = ap.parse_args()
    src = args.src.expanduser().resolve()
    dest = args.dest.expanduser().resolve()
    dest.mkdir(parents=True, exist_ok=True)
    n = 0
    files = list(src.rglob("*.json")) + list(src.rglob("*.jsonl"))
    for f in files:
        try:
            if f.suffix == ".jsonl":
                sessions = [json.loads(line) for line in f.read_text(errors="ignore").splitlines() if line.strip()]
            else:
                sessions = json.loads(f.read_text(errors="ignore"))
                sessions = sessions if isinstance(sessions, list) else [sessions]
        except Exception as e:
            print(f"SKIP {f}: {e}")
            continue
        for i, sess in enumerate(sessions):
            msgs = as_messages(sess)
            if not msgs:
                continue
            title = ""
            if isinstance(sess, dict):
                title = str(sess.get("title") or sess.get("name") or "")
            out = {
                "id": f"{f.stem}-{i}",
                "source": args.source_label,
                "title": title,
                "started_at": (sess.get("create_time") or sess.get("created_at") or "") if isinstance(sess, dict) else "",
                "messages": msgs,
            }
            (dest / f"{out['id']}.json").write_text(json.dumps(out, indent=2)[:500_000])
            n += 1
    print(f"DONE sessions={n}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
