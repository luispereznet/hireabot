#!/bin/bash
# User-run collector for macOS. Packs allowed folders the user selects into a zip in Downloads.
set -euo pipefail
OUT="${HOME}/Downloads/hermes-import-pack-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$OUT"
echo "Copy allowed project folders into: $OUT"
echo "Then run: ditto -c -k --sequesterRsrc --keepParent "$OUT" "${OUT}.zip""
echo "Do not copy .env, auth.json, keychains, or cookie stores."
