# Import Bot

Brings your setup from Claude Cowork, Codex, ChatGPT, and OpenClaw into Hermes. It packs local files and official account exports, scrubs secrets, plans the smallest set of expert bots that cover the work, writes Hermes profiles, audits them, and hands them over only after a clean pass. It never changes the old tools (aside from an opt-in retention fix) and never stores keys or passwords.

- **Collect and scrub:** local files plus ChatGPT and Claude account pulls; secrets stripped before anything is saved.
- **Plan experts:** existing Hermes bots first; new experts only for uncovered expertise (up to five).
- **Write and audit:** each expert gets a full Hermes profile; audit must pass before handoff.
- **Later visits:** resync what changed, or adjust, merge, or split experts.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called import-bot, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `import-bot.zip` from the Import Bot page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install import-bot from the Downloads folder.

The installer finds the newest import-bot download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/import-bot.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them.
