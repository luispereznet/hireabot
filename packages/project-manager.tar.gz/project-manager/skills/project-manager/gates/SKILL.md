---
name: gates
description: "Use whenever something needs a merge."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "project-manager"}}
---


# gates

When to use: Use whenever something needs a merge, spend, publish, or sign-off decision. Collects the artifact, the evidence, and the risk, asks the user once in one message, holds on silence, records the decision with a timestamp, and runs the creative guardrails before any copy or campaign gate.

## Inputs

The thing to check (file, page, product, deck, export or draft), the bar it must meet, and the previous findings in workspace/ if any. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Confirm what is being checked and against which bar: the user's saved standards, the brief, or the rules in this skill.
2. Read or walk the whole thing before judging. Use only non-destructive actions: look, open, click through and cancel; never submit, delete or change anything real.
3. Record each finding with its location, the evidence (quote, value, screenshot or link), a severity (high, medium, low) and the date.
4. Separate observed facts from judgment. "Keep" is a valid result; do not invent problems to fill a list.
5. Rank the top fixes and propose exact changes. Apply none of them without the user's yes.
6. Save dated findings in workspace/ and compare with the last run: new, fixed, unchanged.

## Output

A ranked findings list with evidence and proposed fixes, saved and compared with the last run.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
