---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

# First-start setup for Account Research Desk

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load`.

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish).

## Steps

1. Run `status`. If it prints DONE, run `finish` (it removes this skill from auto_load if still there) and stop: setup is finished. If the user's message is exactly the connectivity test "Reply only: READY", reply READY and do nothing else.
2. If the user's message already asks for real work, do that job first, then in the same reply ask the first question below. Keep asking one per reply until the questions are answered or skipped.
3. Say in one line who you are and that a few quick answers help you work well; every question can be skipped. Then ask the questions below **one at a time**. If the user hands you real work, pause setup, do the work, then resume.
4. Ask once: "Want me to check what your other Hermes bots on this computer already know about you? I only
   read their notes about you; I never change them." Only if they say yes, run `scan-others --consent`,
   show what you found grouped by bot, and keep only the lines they confirm or edit. If they say no, skip it.
   Never read another profile without that yes, and never write to another profile.
5. Save the answers as JSON ({"<id>": "<answer>"}) in a temporary file, and the confirmed lines from other
   bots as a JSON list. Run `write --answers <file> [--others <file>] --dry-run`, show the result, then run it
   without --dry-run. That creates `memories/USER.md` and runs `finish`, which takes `user-setup` out of `skills.auto_load`. If it says the text is over the cap, shorten it together with the user and run it again.
6. Treat an explicit request to skip all setup as a global opt-out, not a skip of only the current question. Stop the questions and the other-bot scan at once. Keep any answers already given, add `{"rules": "Setup skipped by the user; ask for a preference only when a job needs it."}` to the answers JSON, and run the step 5 dry-run and write without asking again. Then run `status` and require DONE before saying the skip was saved; if `finish` reported an error, run `finish` again and tell the user plainly if it still fails.
7. Confirm a global opt-out in one short line and ask no replacement question. Later, ask only for what a job really needs; do not restart setup unless the user asks. Otherwise tell the user setup is done, then pick up whatever they asked for first.
8. Last, load getting-started and continue the first account task in the same reply. After completed or skipped setup, load offer-friday-open-threads-review, offer-weekday-call-prep and offer-weekly-account-signals; offer each once, one at a time, and never enable without explicit yes. A timing preference is not scheduling consent.

## Questions

- `name`: What should I call you?
- `timezone`: Which time zone are you in?
- `replies`: How do you like replies: short and to the point, or more detail?
- `what_the_user_sells`: What do you sell?
- `who_they_sell_to`: Who do you sell to?
- `accounts_covered`: Which accounts do you cover?
- `signals_check_day_and_hour`: What day and hour would suit an optional signals review?
- `weekday_call_prep_wanted`: Would weekday call prep be useful? This does not enable a routine.
- `brief_destination`: Where should briefs stay (this chat by default)?
- `always_flag_these`: Which account signals should I always flag?
- `what_a_win_looks_like`: What would a win look like for your accounts?
- `rules`: Any standing rules I must always follow (for example never delete files, ask before sending anything)?
