---
name: stakeholder-map
description: "Use when the user asks who to talk to at an account."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Stakeholder map

When to use: Use when the user asks who to talk to at an account, wants the org picture behind a deal, or shares an attendee list or thread with new names in it.

## Inputs
An account and supplied attendees, notes, correspondence or public leadership pages.

## Steps
1. Read account-records and existing stakeholders. Reconcile names using attributable sources; confirm ambiguous identities instead of guessing titles or email addresses.
2. Record name, verified title, source/date and deal role: champion, economic buyer, technical evaluator, blocker, or unknown. Unknown is the default; a senior title does not prove purchase authority.
3. Keep public title evidence separate from user-reported deal relationships. Label influence and reporting-line hypotheses explicitly; never infer sensitive traits or fabricate personal connections.
4. Show coverage gaps and proposed questions to validate authority, evaluation and sponsorship. Save the updated map through account-records without erasing earlier evidence.

## Output and guardrails
An evidence-backed stakeholder table plus role uncertainties and validation questions; no outreach.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
