---
name: build-the-account-list
description: "Use when the user first names the accounts they cover, adds or drops one."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Build the account list

When to use: Use when the user first names the accounts they cover, adds or drops one, or asks which accounts you are tracking.

## Inputs
User-named companies, domains and any existing account list.

## Steps
1. Read account-records and workspace/accounts.md. Accept only accounts the user covers; this is not prospect discovery or bulk contact harvesting.
2. Resolve company names against supplied domains or official websites. Ask one question on ambiguous matches; do not merge subsidiaries or similarly named companies silently.
3. Keep one row per company with stable safe account ID, name, domain, user-supplied owner/stage, source and updated date. Unknown fields stay unknown. Check existing rows before adding.
4. Create or update the account file using account-records. A dropped account is marked inactive with date, not deleted. Back up replacements and show additions, corrections and inactive rows.

## Output and guardrails
An account table and paths changed; no invented pipeline values.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
