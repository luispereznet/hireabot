---
name: account-brief-before-a-call
description: "Use when the user has a call or meeting with a company coming up."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Account brief before a call

When to use: Use when the user has a call or meeting with a company coming up, names an account they want to understand, or asks for a brief.

## Inputs
Company/domain, meeting time and purpose if known, participants and authorized notes.

## Steps
1. Read account-records and the account file; confirm the target company before researching. Use the supplied meeting details or a selected event via authorized recipient Calendar tools; never assume access.
2. Use account-signals-refresh for changes, stakeholder-map for attendees, incumbent-and-competitor-check if relevant, and open-threads-and-next-steps for unresolved commitments. Read selected Linear issues or Granola notes only when authorized.
3. Use available web search/extraction or browser to check official company pages and dated primary news. Attach source URL and publication or retrieval date to every public claim. Mark stale or inaccessible evidence and separate user notes from web facts.
4. Write a compact brief: company context, call objective, verified attendees, relevant changes, known tools, open threads, three proposed discovery questions and one proposed next step. Label hypotheses and unknowns.
5. Save the dated brief through account-records and return it locally. Never contact attendees or imply a proposed step is agreed.

## Output and guardrails
A call-ready brief with evidence links, dates, uncertainties and account file reference.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
