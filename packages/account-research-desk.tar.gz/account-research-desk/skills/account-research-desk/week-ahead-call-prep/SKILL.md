---
name: week-ahead-call-prep
description: "Use when the user asks what is coming up."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Week ahead call prep

When to use: Use when the user asks what is coming up, wants to get ready for the week, or pastes a calendar, a schedule, or a set of invites.

## Inputs
A pasted schedule or permission to read a selected calendar and an explicit date window/timezone.

## Steps
1. Read account-records. Establish the week and IANA timezone, one necessary question at a time. Use terminal date for current boundaries; confirm timezone interpretation rather than using an abbreviation.
2. Read only authorized events in that window or the pasted schedule. If calendar tools are absent, request an export; never invent meetings. Deduplicate rescheduled events by event ID and latest status.
3. Match external calls to tracked companies; leave ambiguous attendees/accounts unmatched for confirmation. Order by local meeting time and use account-brief-before-a-call for each matched call.
4. Return a dated agenda with account, participants as supplied, objective, changed signals, open threads and prep gaps. Distinguish no events returned from incomplete calendar access.
5. Save prep notes through account-records. Do not modify events, invite anyone or post the agenda.

## Output and guardrails
A week-ahead prep agenda with explicit coverage window, sources and missing inputs.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
