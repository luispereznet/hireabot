---
name: account-plan
description: "Use when the user wants a plan for winning or growing an account."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Account plan

When to use: Use when the user wants a plan for winning or growing an account, a quarterly plan, or something to walk their manager or deal team through.

## Inputs
Account, user-stated win objective and planning horizon, known stakeholders and history.

## Steps
1. Read account-records and latest brief, stakeholder map, signals, open threads and usage evidence. Ask for the next necessary objective or horizon only; do not invent targets.
2. Use stakeholder-map, incumbent-and-competitor-check and account-usage-and-health where evidence allows. Keep public facts, user notes, hypotheses and missing evidence separate.
3. Write the plan: current state, user-defined desired outcome, stakeholder gaps, business needs, competitor context, risks and opportunities, then sequenced proposed actions with owner, target date and evidence needed.
4. Mark unknown owners/dates explicitly and label proposed targets as proposals. Do not manufacture revenue, purchase authority, deal probability or buyer commitments.
5. Save a dated version through account-records with changes from the prior plan. Return a manager-readable summary and next action. External Notion/Salesforce/Sheets writes require exact-target preview, explicit yes and readback; do not turn this into an automatic CRM sync.

## Output and guardrails
An evidence-linked account plan with assumptions, proposed actions and unresolved decisions.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
