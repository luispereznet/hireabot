---
name: account-signals-refresh
description: "Use when the user asks what is new at an account."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Account signals refresh

When to use: Use when the user asks what is new at an account, before briefing an account you have researched before, or when the weekly signals routine runs.

## Inputs
Tracked account(s), last checked date and user-relevant signal categories.

## Steps
1. Read account-records and the prior signals log. Set a dated search window from last verified refresh, or explicitly state the first-review window.
2. Use available web/browser tools to check company news, funding, leadership changes and hiring. Prefer primary dated sources; distinguish event date from publication and retrieval dates.
3. Compare against logged URLs and events to deduplicate. Record only new or materially changed signals, source URL/date, a factual summary and a separately labeled possible deal implication.
4. Keep contradicting reports and stale sources visible. No relevant signal found is not proof nothing happened; state coverage limits and missing web access.
5. Append verified signals through account-records and return the meaningful changes. Do not notify channels automatically.

## Output and guardrails
A dated changes-only signals digest with links, caveats and proposed follow-up questions.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
