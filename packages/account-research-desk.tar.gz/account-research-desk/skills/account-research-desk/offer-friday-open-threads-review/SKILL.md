---
name: offer-friday-open-threads-review
description: "Use after setup or when asked about routines: offer friday open threads review."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "account-research-desk"}}
---

# Offer friday open threads review

When to use: Once after completed or skipped setup, or when the user asks about this routine.

## Inputs
The shipped paused job 2c76c1d2239b, routine choice history and the recipient's chosen schedule.

## Steps
1. Resolve this active profile from the loaded skill location. Read workspace/routine-choice-friday-open-threads-review.md if present. A declined or enabled choice suppresses repeat offers unless requested. Explain: Read account-records and open-threads-and-next-steps. Review active tracked accounts, show open threads with owner/raised date and stated due dates, age or agreed staleness threshold, and evidence-backed closures since last review or the stated last seven-day window if none. Separate proposed next steps from commitments. Deliver locally only; do not send nudges. Ask one yes/no question. On no, record declined locally; on unclear or silence, leave paused without recording a decline as consent.
2. After explicit yes, confirm day, local hour, IANA timezone and authorized input scope one necessary question at a time. The shipped expression `0 8 * * 5` is a review default, not an agreed preference. Inspect the native scheduler's actual timezone and DST interpretation; do not convert using a timezone abbreviation alone. Show the resulting schedule and local delivery for approval.
3. List native scheduler jobs scoped to this active profile. Find ID 2c76c1d2239b, verify ownership, name and prompt, and update that same paused definition to the approved schedule. Resume only after explicit approval. If already enabled correctly, do not duplicate. If missing or mismatched, stop and explain; do not create a replacement or duplicate job.
4. Read the exact job back and verify ID, name, schedule/timezone interpretation, enabled state, local delivery and computed next run. Only then record enabled with ID/schedule locally and confirm the recipient-local time. If scheduler tools are unavailable or readback fails, disclose that and leave it paused; never claim success.
5. Preview by executing the relevant research skill locally on authorized supplied inputs, not by cron run or force-trigger. Share pause/resume options using available native scheduler tools only; do not delete jobs or change other profiles. Scheduling is not permission to send/post or change external records.

## Output and guardrails
A declined, still-paused or verified-enabled status. No invented data, duplicate creation, external delivery or automatic connection. Missing tools must be disclosed.
