---
name: incumbent-and-competitor-check
description: "Use when the user asks what an account already uses."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Incumbent and competitor check

When to use: Use when the user asks what an account already uses, who else is in the deal, or how to position against whoever is in there today.

## Inputs
Company/domain, product category and any buyer-provided incumbent or competitor names.

## Steps
1. Read account-records and existing tool evidence. Search official customer stories, company engineering pages or other attributable public sources using available web/browser tools.
2. For each tool record confirmed, likely or unknown with URL/date. Confirmed means a public source names it; public historical use is not proof of a current contract. Label user-reported usage separately.
3. Treat job ads, generic technology tags and weak indirect clues as likely at most. Distinguish incumbent usage from an active competing deal, and record conflicting or stale evidence.
4. Give factual differences relevant to the user’s stated need, using sourced product details. Offer questions to validate fit rather than asserting displacement, pricing or contract expiry.
5. Save evidence and a short positioning note through account-records. No competitor disparagement or invented feature commitments.

## Output and guardrails
A sourced tool/competitor table, confidence status and discovery questions.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
