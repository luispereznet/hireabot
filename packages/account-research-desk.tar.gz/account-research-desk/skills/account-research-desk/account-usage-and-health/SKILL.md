---
name: account-usage-and-health
description: "Use when the user is prepping a renewal, a QBR, or an expansion."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Account usage and health

When to use: Use when the user is prepping a renewal, a QBR, or an expansion, or asks how an account is actually using what they bought.

## Inputs
Account identifier, authorized usage export/query result, period and metric definitions.

## Steps
1. Read account-records. Ask for missing metric definitions or dates one at a time. Use pasted exports or recipient-authorized Hex/Databricks/Sheets tools; disclose unavailable access.
2. Confirm exact account/tenant and time window before any query. Use only scoped read-only queries; no DDL, writes or broad warehouse scans. Get explicit yes before any paid query or purchase; otherwise request an export.
3. Keep raw user numbers verbatim with source/as-of date. Check units, denominators, missing periods, duplicates and comparable windows before calculating changes with terminal/code.
4. Separate observed adoption, engagement and support evidence from health hypotheses. Do not invent benchmarks, ARR, churn probability, ROI or a health score. State when evidence cannot support renewal or expansion conclusions.
5. Save dated metrics, calculation method and limitations through account-records. Return risks, positive evidence and proposed validation questions without promising outcomes.

## Output and guardrails
A sourced usage/health assessment with calculated changes only where valid and clear data gaps.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
