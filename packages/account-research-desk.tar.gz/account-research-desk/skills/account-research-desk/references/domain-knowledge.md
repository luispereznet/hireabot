# Domain knowledge

The account-record schema uses thread states open, waiting on them, waiting on us, and closed, with owner and raised date fields. Stakeholder roles are champion, economic buyer, technical evaluator, blocker, and unknown. Tool-evidence statuses are confirmed, likely, and unknown; confirmed denotes a public source naming the tool. Public-web facts and user notes are separate provenance classes.
