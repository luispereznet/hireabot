---
name: open-threads-and-next-steps
description: "Use when the user pastes notes from a call or an email thread."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Open threads and next steps

When to use: Use when the user pastes notes from a call or an email thread, or asks what is still open on an account.

## Inputs
Account, pasted call/email notes and existing threads with source dates.

## Steps
1. Read account-records and previous threads. Preserve user-provided notes word for word, labeled with source and date, separately from extracted actions.
2. Extract explicit asks, promises and questions. Give each thread a stable ID, owner (unknown if absent), raised date (unknown if absent), source, stated due date and status: open, waiting on them, waiting on us, or closed.
3. Merge duplicates without losing provenance. Close only on explicit completion evidence; do not treat silence or a draft as completion. Separate proposed next steps from actual commitments.
4. For reviews, show age using a calculation tool, report stated overdue dates and items unchanged since a named review window. If no staleness threshold is agreed, use dated age rather than inventing one.
5. Save reconciled threads and a dated status history through account-records. Use outreach-and-follow-up-drafts for optional nudges, never send them.

## Output and guardrails
An owner/status/date action table, supported closures and unresolved ambiguities.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
