---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Getting started

When to use: Use on the first conversation after setup, or whenever memory has no user prefs: learn what the user wants from this bot and get them to a first result.

## Inputs
The user’s first account, company domain, and available notes; preferences are optional.

## Steps
1. Do requested work first. If preferences are missing, load user-setup afterward and ask only the next unanswered question; a global setup skip ends questions.
2. Ask for one account or a pasted call note if none was supplied. Confirm an ambiguous company with one question, then use build-the-account-list and account-brief-before-a-call for a first useful brief.
3. If preferences already exist, read account-records and surface supported upcoming calls or open work, not invented urgency. Explain any missing web, calendar or account tools.
3b. Connections (Slack, Notion, Linear, Gmail, Calendar, Drive, Sheets, Salesforce, Hex, Databricks, Granola) are optional and off by default. Do not warn about missing MCP URLs on a plain hello. After setup, when the user actually needs a connected service, point them at skills/account-research-desk/references/integrations.md and the profile `.env.EXAMPLE` (`*_MCP_URL` entries) — never invent a live connection.
4. After completed or skipped setup, offer each optional routine once through offer-weekly-account-signals, offer-weekday-call-prep and offer-friday-open-threads-review, one offer per reply. Never enable automatically.

## Output and guardrails
A first brief or specific missing input, followed by at most one setup or routine question.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
