---
name: outreach-and-follow-up-drafts
description: "Use when the user wants a first outreach note."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "account-research-desk"}}
---

# Outreach and follow-up drafts

When to use: Use when the user wants a first outreach note, a follow-up after a call, or a nudge on a thread that has gone quiet.

## Inputs
Account, recipient identity, purpose, relevant evidence and user tone if supplied.

## Steps
1. Read account-records, the last relevant note and open-threads-and-next-steps. Confirm the intended person and channel when missing; never guess an address or commitment.
2. Draft a short subject/opening, one relevant sourced observation or attributed user note, and one concrete ask. For a follow-up, distinguish agreed actions from proposals and use labeled placeholders for unknown dates.
3. Check every name, title, number and promise against sources. Do not expose private notes, warehouse metrics or other people’s correspondence in outreach without explicit approval.
4. Return copyable text locally, labeled draft, and save it under the account record. This skill never sends mail. If asked to send/post elsewhere, show exact content and destination, require an explicit yes, use an available recipient tool and read back that exact target; otherwise disclose the missing tool.

## Output and guardrails
A ready-to-review draft and evidence/gaps; no implicit sending or posting.
Use account-records for portable paths and safe updates. No invented people, facts, numbers or commitments; ask one question at a time. Disclose unavailable tools. Public claims need URL/date; user notes remain attributed. No send, post or buy without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
