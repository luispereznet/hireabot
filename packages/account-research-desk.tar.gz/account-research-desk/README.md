# Account Research Desk

Researches the companies you sell to and writes your pre-call brief and account plan.

## Install and open

```bash
hermes profile import account-research-desk.tar.gz && hermes -p account-research-desk
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `account-research-desk` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p account-research-desk setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Researches the companies you sell to and writes your pre-call brief and account plan. Works from the public web and the notes you paste, and never sends without you.

- **Build the account list**
- **Account brief before a call**
- **Week ahead call prep**
- **Stakeholder map**
- **Incumbent and competitor check**
- **Account signals refresh**
- **Open threads and next steps**
- **Account usage and health**
- **Outreach and follow-up drafts**
- **Account plan**
- **Optional weekly account signals:** offered once after setup. It is only enabled if you say yes.
- **Optional weekday call prep:** offered once after setup. It is only enabled if you say yes.
- **Optional friday open threads review:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p account-research-desk chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p account-research-desk`.

## Setup

- No integration is required: use public web/browser and pasted notes or authorized exports. Missing calendar/warehouse/email tools must be disclosed.
- All eleven MCP entries and sampling ship disabled. Their URLs are unresolved placeholders; select and verify compatible server, authentication (OAuth only if documented), least-privilege tools and account scope before enabling. See skills/account-research-desk/references/integrations.md.
- Fill only the optional matching *_MCP_URL variable locally after verification; .env.EXAMPLE has blank assignments and no credentials. Do not treat configured entries as working connections.
- Three local routine definitions ship paused, with no next run. Use offer-weekly-account-signals, offer-weekday-call-prep or offer-friday-open-threads-review to approve scope/timezone and resume the same ID. No duplicates or cron-run previews.
- Onboarding is skippable and domain-specific; no USER.md or personal history ships. Account working state is in profile-local workspace files, not memory. External sends/posts/writes/purchases need explicit yes and target readback.
