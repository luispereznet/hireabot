# SWE

SWE

## Install and open

```bash
hermes profile import swe.tar.gz
hermes -p swe setup
hermes -p swe
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `swe` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

SWE

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p swe chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p swe`.

## Setup

- Supply the exact authorized repository and acceptance criteria. Use implement-and-verify for code changes and issue-triage for defects; available local checks are discovered rather than assumed.
- Use production-health-review only for authorized read-only telemetry or sanitized exports. No repository host, issue tracker, production account or monitoring feed is connected by this package. Missing tools must be disclosed.
- The source lists no integrations or routines; none are invented. Production review is on demand, not continuous or scheduled monitoring. No credentials or environment variables are required.
- Installing dependencies, migrations, deployment, production mutation and external changes require separate approval. Sending, posting or buying requires explicit yes to exact content and destination.
