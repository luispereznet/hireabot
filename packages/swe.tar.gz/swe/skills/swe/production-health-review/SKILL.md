---
name: production-health-review
description: "Use when a user asks to assess production health, investigate an alert or review telemetry."
version: 1.0.0
---

# On-demand production health review

When to use: a user asks to assess production health, investigate an alert or review telemetry.

## Inputs
Explicitly authorized service/environment, observation window and timezone, and read-only telemetry tools or sanitized exports. Optional documented SLOs, baseline and recent deployment/change records. No production access is bundled.

## Steps
1. Confirm the requested service, environment and observation window from supplied context. Verify read-only authorization and available telemetry tools before querying. If no connection exists, disclose it and request a sanitized export or approved read-only tool. Never imply continuous monitoring or invent a healthy state from missing data.
2. Inspect telemetry schema, units, sampling, aggregation and ingestion lag. Query the narrow authorized window and scope. Obtain actual timestamps through tools. Check source coverage and freshness; distinguish zero events from absent ingestion, failed queries or missing instrumentation. Keep query cost and load bounded.
3. Review error rates, latency distributions, traffic and saturation only where data exists. Compare with the supplied baseline and documented SLOs; if absent, describe observations without claiming a breach. Compute rates, deltas and time comparisons using tools and preserve denominators and units. Do not equate correlation with causation.
4. Correlate observed anomalies with read-only logs, traces, deployments and configuration history within the approved scope. Redact secrets and customer data. Build a timestamped evidence trail, naming the source and query/filter for each material claim. Distinguish symptoms, plausible causes and verified causes.
5. Prioritize findings by demonstrated user impact and uncertainty. Recommend low-risk next checks and describe a possible mitigation and rollback plan without executing either. Restarts, scaling, config changes, rollbacks, incident creation, paging and external messages require separate explicit approval and exact targets.
6. Return a local report with time window/timezone, sources and coverage, verified findings, confidence, gaps and next actions. If data is incomplete, say health is unverified rather than green. This workflow runs on demand only; recurring monitoring requires a separately requested and approved schedule, not an invented routine.

## Output
A local production-health or incident-assessment report grounded in actual read-only evidence, with query provenance, timestamps, coverage limits, impact, hypotheses and prioritized next checks. No fabricated metrics, alerts or monitoring history.

## Guardrails
Do not deploy, mutate infrastructure, buy capacity, install agents or run load tests. Do not expose secrets in reports. Require explicit yes before sending/posting/paging or making any external change; read back the exact target afterward. Do not claim persistence or background monitoring after a one-time review.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
