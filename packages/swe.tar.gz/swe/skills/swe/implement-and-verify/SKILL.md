---
name: implement-and-verify
description: "Use when a user requests a code change, feature, refactor or repair."
version: 1.0.0
---

# Implement and verify code

When to use: a user requests a code change, feature, refactor or repair.

## Inputs
An explicitly authorized repository path, requested behavior and acceptance criteria; available runtime and tests. Work in that repository only. An issue-triage result may supply a reproducer.

## Steps
1. Resolve the exact repository path from the request or discover it read-only; do not assume the current directory is the project. Inspect repository guidance, status and relevant manifests before editing. Identify user changes and leave them intact. Ask one question only when scope or expected behavior genuinely blocks progress.
2. Read the relevant implementation, callers and nearby tests. Determine the existing architecture, dependencies and style. Establish the current behavior with a targeted test or minimal reproducer when safe. Inspect commands before executing: tests may contact live services, mutate databases or run arbitrary hooks.
3. Define observable acceptance criteria and a minimal patch. Cover expected input, edge cases and failure behavior. Prefer existing libraries and interfaces; obtain consent before installing dependencies, migrations, network calls or broad rewrites. Keep secrets and production data out of fixtures.
4. Apply the smallest coherent implementation and regression tests. Preserve unrelated work and public compatibility unless a change was requested. Check error handling, input validation and authorization boundaries. Do not replace real behavior with placeholders, fake responses or skipped tests to obtain a pass.
5. Run relevant tests in the authorized local environment, followed by appropriate available lint, type or build checks. Capture actual command, exit status and concise result. If a check fails, investigate and fix task-caused failures; distinguish preexisting failures. If blocked by missing runtime, permissions or services, report exactly what remains unverified.
6. Review the final diff and status for accidental edits, credentials, generated files and omitted edge cases. Rerun impacted checks after fixes. Report the changed paths, implemented behavior, verification evidence and limitations. Leave commits, pushes, pull requests, releases and deployment to separately approved actions.

## Output
A working local patch with regression coverage where possible, exact verification commands/results, changed file paths and explicit unverified items. If unable to edit or run, clearly label the deliverable as analysis or an untested patch.

## Guardrails
Never overwrite user changes or delete files to simplify a fix. No install, paid API calls or live production tests without explicit authorization. Before sending, posting, buying or changing external records, show the exact payload and destination, require explicit yes, then read back the target. No fabricated test output.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
