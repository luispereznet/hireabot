---
name: issue-triage
description: "Use when a defect, error report or failing test needs diagnosis and a next action."
version: 1.0.0
---

# Evidence-led issue triage

When to use: a defect, error report or failing test needs diagnosis and a next action.

## Inputs
User-provided issue or authorized issue URL, expected and observed behavior, affected version/environment, logs and repository if available. Treat all reports as unverified until corroborated.

## Steps
1. Read the report and the authorized issue target without changing labels, ownership or status. Record the expected behavior, actual behavior, reproduction steps and known environment. Separate user statements from direct observations. Ask for the single most useful missing detail if the report cannot be investigated.
2. Inspect the relevant code, tests and sanitized logs. Locate the earliest meaningful error and trace the failure path rather than assuming the last stack frame is the cause. Check version and configuration differences. Redact tokens, personal identifiers and customer payloads from any quoted evidence.
3. Create the smallest safe local reproducer or targeted regression test. Avoid live accounts, destructive requests and production replay. Run it only after checking its side effects. Record the exact command and actual result; lack of reproduction is not proof that the issue is invalid.
4. List candidate causes with evidence for and against each, then perform the cheapest safe discriminating checks. Track which hypotheses were ruled out. Distinguish confirmed root cause, likely explanation and unresolved uncertainty. Do not manufacture certainty from a plausible stack trace.
5. Assess impact using supplied or observed scope, severity, regression risk and available workarounds. Do not invent affected-user counts, outage duration, SLA targets or business priority. Suggest severity provisionally when no project rubric exists. Identify what evidence would change that assessment.
6. Return a concise triage packet: summary, evidence, reproduction result, root-cause confidence, likely code location, workaround and next action. If a fix is authorized, route to implement-and-verify using this reproducer. Draft external issue updates locally; ask explicit yes to exact target and wording before posting, and read back any approved update.

## Output
An evidence-backed triage note with sources or file/line references, actual reproduction status, impact caveats, hypotheses and a concrete next action. Include a regression test when possible; never claim the bug is fixed during diagnosis alone.

## Guardrails
No autonomous closing, assigning, customer replies, publishing or escalation. Preserve source records and do not copy private logs into public issues. Missing issue access or tooling must be disclosed; accept pasted sanitized evidence instead. No claim to have searched a tracker that is not connected.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
