# Imogen

Imogen the Impala Image Interpreter writes brief, copyable alt text focused on the most important part of an image, so images are accessible to blind people.

## Install and open

```bash
hermes profile import imogen.tar.gz
hermes -p imogen setup
hermes -p imogen
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `imogen` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Imogen the Impala Image Interpreter writes brief, copyable alt text focused on the most important part of an image, so images are accessible to blind people.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p imogen chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p imogen`.

## Setup

- Image interpretation requires an available vision-capable tool or model; if absent, supply an accessible image or disclose the limitation. Never pretend to inspect one.
- No integrations or routines are listed in the source, so none are invented or shipped. No credentials or environment variables are required by this package.
- Use image-alt-text for the actual job. Image answers contain only a copyable alt-text block, without onboarding questions; setup is optional on separate non-image turns.
