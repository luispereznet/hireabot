---
name: image-alt-text
description: "Use when an image needs concise, copyable alt text."
version: 1.0.0
---

# Brief image alt text

When to use: an image needs concise, copyable alt text.

## Inputs
The actual attached image or an authorized accessible image URL; optional page context, intended purpose and language supplied by the user. Do not require personal onboarding to describe an image.

## Steps
1. Check that the image is actually available to a visual inspection tool. Open it using the available image tool, or inspect a browser image when authorized. A filename, inaccessible link or surrounding caption alone is not visual evidence. If blocked or no vision tool exists, state the limitation and ask for an accessible image in one short question; do not invent a description.
2. Inspect the whole image before zooming. Identify the main subject, meaningful action and relationship or setting that makes it understandable. Use page context to choose relevance, but do not treat a caption as proof of details not visible. Crop or zoom only when necessary to verify small text or a salient detail.
3. Choose the smallest set of details needed for the image purpose. For a photo, describe the subject and action; for a screenshot, the key interface state; for a chart, its type and plainly visible message. Include visible text only if essential, preserving verified wording. Do not calculate chart values by eye or pretend an unreadable label is known.
4. Draft one short plain-language sentence, adding another only when meaning would otherwise be lost. Start with the subject rather than "image of". Use neutral visual description. Avoid decorative minutiae, speculation, evaluation and redundant surrounding prose. There is no universal character cap: brevity must not erase essential meaning.
5. For diagrams or complex charts, provide a concise identifying summary rather than a fabricated full transcription; if the user separately requests a long description, explain its distinction and use verified details. Do not silently label an image decorative or prescribe empty alt text without knowing its page purpose.
6. Review every noun and claim against what you inspected. Remove unsupported identities, precise locations, inferred feelings and sensitive traits. Check text for accuracy and trim repeated details. Return only one fenced plain-text block containing the alt text; no label, greeting, setup question, commentary or offer. For multiple supplied images, keep image-order lines within that single block unless the user specifies a different format.

## Output
A single copyable plain-text block of concise, evidence-grounded alt text, and nothing else. An unavailable image produces an honest access limitation instead of fictitious alt text.

## Guardrails
Never send, post or replace website alt attributes without explicit yes to the exact target and text. Respect privacy; do not identify unknown people or reproduce irrelevant personal information. Do not save image contents to MEMORY or USER. Tool failures are not successful image inspection.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
