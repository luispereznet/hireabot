---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load` via the helper's `finish` step.


# First-start setup for Imogen

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish). No USER.md ships.

## Steps
1. Before tools or setup processing: If your message is exactly "Reply only: READY", reply READY and nothing else.
2. Do requested real work first, using image-alt-text. An image response contains only the alt-text block; defer all setup chatter to a separate non-image turn.
3. On an appropriate setup turn run status. DONE means setup is already complete; run finish only if necessary and do not restart questions. Report helper errors rather than claiming completion.
4. Explain setup is optional. Ask one question from questions.json per turn; accept skips without inferred preferences. Do not require name or timezone unless a job needs it. Never scan other profiles without a separate explicit yes; this setup does not request or need that scan.
5. Write supplied answers to a local temporary JSON object keyed by question id. For an explicit global skip, stop all questions immediately, preserve any answers and include rules: "Setup skipped by the user; ask for a preference only when a job needs it." No replacement questions.
6. Run write --answers <file> --dry-run, review the proposed USER.md with the user for ordinary setup, then write with the same arguments without --dry-run after confirmation. A global skip authorizes saving its skip marker without another question. The helper creates a backup before replacing existing USER.md and runs finish for this installed named profile only.
7. Require status to print DONE and finish to succeed before saying setup was saved. If finish fails, report the error and retry only for this active installed profile. Never run the helper finish against a build folder. Do not claim a configuration change without success.
8. After completed or skipped setup, continue the requested job; no optional routines or offer skills exist. Do not append completion chatter to an image-only answer.

## Questions
- `context`: Where will you use the alt text?
- `language`: Which language should the alt text use?


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
