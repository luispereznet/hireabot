---
name: offer-warm-path-follow-through-queue
description: "Use after setup or when asked about routines."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "gtm-connections"}}
---

# Offer warm-path follow-through queue

A native job ships paused, not active. Surface evidenced warm paths and intro requests whose next action is due or stalled; draft follow-through, never send.

## Steps
1. After completed or skipped user-setup, read workspace/routine-choice-offer-warm-path-follow-through-queue.md in the active profile. If already offered, declined or enabled, do not repeat unless the user asks. Record the offer with approval; an unanswered offer is not consent.
2. Ask once: "Want to enable the warm-path follow-through queue? Yes or no?" No or no clear yes leaves it paused. Record declined or offered, not enabled; missing storage/tool access must be disclosed.
3. On yes, gather cadence, time zone, account/request scope, source permissions, private destination, empty-result behavior and approval boundaries, one question at a time. Weekly monitoring must remain weekly unless the user chooses otherwise. Do not assume the sample shipped schedule is their preference.
4. Show the exact schedule, scope and draft-only/local behavior. Get explicit yes for this activation. Use the recipient's native scheduler tools; if unavailable, explain the blocker and provide the approved plan without claiming activation.
5. List/read jobs and find ID d2d60e03b151 or name `[bot:gtm-connections] Warm-path follow-through queue`. Reconfigure/resume the existing paused job only as approved; create a missing job only after approval and duplicate checks. Do not edit scheduler files behind the runtime. Never create a duplicate or activate unrelated jobs.
6. Read back the exact job and verify schedule, enabled state, scope and local delivery. Record the verified choice/job ID in the local choice file; report failures honestly. On each run use the relevant domain skill, source receipts, freshness/conflict checks and Unknowns. No external sends or silent record writes.

## Output and guardrails
Return choice, approved configuration, actual state and read-back receipt. Ask one question at a time; never invent findings or numbers. Explicit yes is required before sending, posting, buying or external record changes. Local private drafts only; public creator/owner information never belongs in artifacts.
