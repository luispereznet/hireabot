---
name: connections-and-intros
description: "Use when find evidenced connections into target accounts."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-connections"}}
---

# connections-and-intros

When to use: Find evidenced connections into target accounts, rank warm paths, draft introduction asks, and track outcomes.

## Inputs
Target person/account, reason for access, approved relationship sources, connector owners, suppression rules, intro tone and any existing request/outcome log. Read ../references/working-notes.md.

## Steps
1. Resolve the target's identity and affiliation using provided or connected evidence. Ask one clarifying question if names collide; do not build a path to a guessed person.
2. Search only authorized CRM, mail, calendar, Slack or supplied exports for mutual contacts, shared history and prior meetings. Record person IDs, source links, event dates, retrieval dates and exact evidence for each edge.
3. Build candidate paths from requester through connector to target. A co-attended meeting is not proof of friendship or willingness. Flag stale, one-sided or indirect evidence and respect suppression/ownership.
4. Rank paths qualitatively by evidenced relationship strength, relevance, freshness, connector willingness if known, and friction. Explain tradeoffs; do not invent scores or mutuals. Deduplicate identities and show source conflicts with timestamps.
5. Draft a concise connector ask and an optional forwardable intro: context, why this target, truthful value, low-pressure permission request and easy decline. Load humanizer without altering claims. Do not send the ask.
6. Propose a private queue row with target, path, owner, evidence, request state, last verified event, next action/date and outcome. Mark dates or status Unknown unless supplied or confirmed. Record only approved updates and read them back. Use offer-warm-path-follow-through-queue for recurring review.

## Output
Ranked path table; evidence and uncertainty per edge; connector ask; forwardable intro draft; next-action/outcome queue patch; Decisions needed and execution receipt. No credible path is a valid result; finish locally when optional sibling bots are absent.

## Guardrails
Ask one question at a time when blocked. Never invent facts, numbers, sources, relationships or results. Disclose missing tools/connections; accept paste, CSV, export, URL or files. Require an explicit yes for the exact action before sending, posting, buying or changing external records. Keep drafts local; ordinary workflows never activate routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
