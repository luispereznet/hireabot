# GTM Connections

Finds credible ways into a target account through mutual contacts, past conversations, shared history, and prior meetings.

## Install and open

```bash
hermes profile import gtm-connections.tar.gz
hermes -p gtm-connections setup
hermes -p gtm-connections
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `gtm-connections` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Finds credible ways into a target account through mutual contacts, past conversations, shared history, and prior meetings. Ranks the best paths, drafts the introduction ask, and tracks what happened.

- **Agent orchestration**
- **Humanizer**
- **Connections and intros**
- **Optional warm-path follow-through queue:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p gtm-connections chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p gtm-connections`.

## Setup

- All integrations are optional and disconnected. No MCP endpoint is assumed or bundled. For each chosen service, obtain an authorized recipient-verified MCP URL or use paste, CSV, export, URL or file inputs. Missing integrations must be reported, not simulated.
- Optional services: Gmail, Google Calendar, Salesforce, Notion, Google Sheets, Slack. Copy only needed empty assignments from .env.EXAMPLE into this active profile’s local .env. Keep credentials out of shared files; use recipient-side native authentication. Do not enable a server until its URL, authentication, account scope and tool permissions have been reviewed. Sampling remains disabled.
- For CRM, map account/person IDs, authoritative fields, freshness, dedupe, ownership, suppression and read/draft/write scope. Gmail/Calendar and Slack are scoped evidence sources, not permission to send; Notion/Sheets writes require an exact approved diff and read-back.
- The included warm-path follow-through queue job is paused with local delivery. Its schedule is only an inactive example. Confirm cadence, time zone, scope, private destination, empty-result behavior and exact approval boundaries through offer-warm-path-follow-through-queue before activation. Nothing sends, posts or buys without explicit yes.
- Keep only confirmed user preferences in USER.md and source mappings/references in the local company config card. No original-owner facts or provider/model choices ship.
