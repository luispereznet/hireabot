# Distro Bot

Runs your marketing loop end to end: campaigns on your ad accounts, fresh creative, real channel analysis, timely posts from X and web scans, and outbound until

## Install and open

```bash
hermes profile import distro-bot.tar.gz && hermes -p distro-bot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `distro-bot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p distro-bot setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Runs your marketing loop end to end: campaigns on your ad accounts, fresh creative, real channel analysis, timely posts from X and web scans, and outbound until a lead replies. Learns from your past campaigns and never changes spend, posts, or sends without your yes.

- **Distro setup**
- **Ad accounts**
- **Campaign loop**
- **Ad creative**
- **Market scan**
- **Outbound desk**
- **Distro scripts**
- **Optional campaign check:** offered once after setup. It is only enabled if you say yes.
- **Optional trend scan:** offered once after setup. It is only enabled if you say yes.
- **Optional outbound replies:** offered once after setup. It is only enabled if you say yes.
- **Optional weekly distro review:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p distro-bot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p distro-bot`.

## Setup

- No distro.py is supplied. distro-scripts uses native local files under the active profile workspace instead. No install is needed or attempted.
- X and Gmail ship disabled with sampling disabled. X_MCP_URL and GMAIL_MCP_URL are unresolved placeholders. Select and verify a compatible server, authentication and scoped tools before filling optional local values. See skills/distro-bot/references/integrations.md.
- X reads can bill API credits. Paid reads, generation and purchases need explicit approval of scope/cost. Advertising account and creative tools are not bundled. Use authorized exports or web/browser access when available.
- Four routine definitions ship paused, local-only. Source times are review defaults, not your preferences. Use offer-* skills to confirm schedule/timezone and resume the existing stable IDs after consent. Routine runs never send, post, buy or change campaigns.
- The regenerated onboarding asks about ad accounts, monthly budget/currency and standing rules. Budgets are limits, not consent to spend. No user facts are shipped.
