---
name: offer-weekly-distro-review
description: "Use after setup or when asked about routines: offer weekly distro review."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "distro-bot"}}
---

# Offer the weekly distro review

The shipped job 6aee0577cd42 is paused. Its cron `45 8 * * 1` is a review default, not a recipient preference.

## Steps
1. Resolve the active profile from this skill's ancestor containing skills/ and SOUL.md. Read workspace/routine-choice-weekly-distro-review.md if present. Do not repeat a declined or enabled offer unless asked. Explain the routine and ask one yes/no question. Silence is not consent. Record a clear no locally, leaving the job paused.
2. On yes, confirm days, local hour and IANA timezone, one question at a time. Inspect the native scheduler's timezone and DST semantics, not just a timezone abbreviation. Show the exact schedule and local-only delivery for approval.
3. Use available recipient-native scheduler tools scoped to this profile. List jobs, locate 6aee0577cd42, and verify name and prompt. Update and resume this existing paused job only after explicit approval. If already enabled correctly, report it, do not duplicate. If absent, check IDs and equivalent names/prompts first and obtain explicit approval before creating one equivalent job. If scheduler tools are missing, disclose that and leave it paused.
4. Read the exact job back and verify ID, schedule, timezone interpretation, enabled state, local delivery and next run. Only then record enabled status and tell the user what was verified. Never claim success on a failed update. Offer a pause through the same tools with readback.
5. For a preview, perform an ordinary read-only analysis with the domain skill, never cron run. Routine opt-in never approves sending, posting, buying, paid reads or campaign changes.

## Output and guards
Return approved schedule and verified status or missing capability. Runs only read and draft, never send, forward leads, post or spend. Stay quiet when unchanged. No invented evidence or duplicate schedules.
