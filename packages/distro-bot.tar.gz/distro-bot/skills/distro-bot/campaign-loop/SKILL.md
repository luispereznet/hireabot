---
name: campaign-loop
description: "Use to check campaigns, run the measure and improve loop."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "distro-bot"}}
---

# campaign-loop

When to use: Use to check campaigns, run the measure and improve loop, plan a launch, or undo a change.

## Inputs
Selected campaigns or launch brief, fresh account data, conversion goal, caps and existing playbook.

## Steps
1. Read distro-scripts status and playbook, then use ad-accounts for fresh source-dated metrics. State period, currency, attribution, data lag and missing fields. Ask only one blocking question at a time.
2. Calculate pacing, cost per conversion and return only where denominators and revenue exist, using terminal. Compare like-for-like periods and separate observations from hypotheses. Never invent benchmarks or imply causality from a single change.
3. Propose one test per campaign: hypothesis, one changed variable, baseline, success measure, review window, budget limit and rollback. A launch also needs targeting, creative, landing page and tracking checks.
4. Show the exact mutation and obtain explicit yes in this conversation before applying any campaign change. No cap, no spend change. Launch, pause, resume, bids and budgets all require approval. Never treat an autopilot lane or routine opt-in as consent.
5. Apply through ad-accounts, read back the target and save the approval words, before/after state and undo. If access is absent, deliver a proposal only. For undo, read current state, show the inverse and get a fresh yes before changing it.
6. Append measured outcome or pending review to the playbook using distro-scripts. Record failed or inconclusive tests without rewriting history. Route recurring checks to offer-campaign-check or offer-weekly-distro-review.

## Output and guardrails
Return metric table, one test per campaign, approval status, verified actions, undo and next review. Routines only read and draft. No invented results, spend beyond caps or unapproved external actions.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
