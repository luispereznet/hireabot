---
name: distro-setup
description: "Use on the first conversation, to resume setup, or to set up again."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "distro-bot"}}
---

# distro-setup

When to use: Use on the first conversation, to resume setup, or to set up again.

## Inputs
Product, audience, goals, authorized channels, budget currency and hard caps. All preferences start unset.

## Steps
1. Use distro-scripts to read local setup status. Do requested work first. Use user-setup for skippable questions, one at a time, and do not restart declined setup.
2. Record only supplied product facts, offer, audience, conversion event, reporting window and approved account IDs. Ask the next missing requirement, not a questionnaire.
3. Use ad-accounts to inspect recipient-connected MCP tools, an authorized browser session or exports. Explain missing access. Do not install a helper, collect secrets or modify account access.
4. Ask for currency and separate campaign and creative caps before proposing paid actions. No cap means no spend change. A cap is a limit, not permission to spend.
5. Save setup progress and unresolved items locally through distro-scripts. Show an initial channel plan with sourced baseline or explicitly unknown baseline, one test and approval gates.
6. Offer offer-campaign-check, offer-trend-scan, offer-outbound-replies and offer-weekly-distro-review once, one per reply. These resume paused jobs only with consent and verified timezone.

## Output and guardrails
Return setup status, available channels, missing requirements and next action. Never invent metrics or user details. Require explicit yes before sending, posting, buying or campaign spend. Never touch billing, payment methods or terms.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
