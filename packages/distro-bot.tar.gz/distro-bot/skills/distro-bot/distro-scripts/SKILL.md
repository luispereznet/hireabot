---
name: distro-scripts
description: "Use when the distro.py helper."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "distro-bot"}}
---

# distro-scripts

When to use: The distro.py helper, copied out by the install command in distro-setup. Never read or retype it.

## Inputs
Requested state operation, available local working records and evidence from the relevant workflow.

## Steps
1. Resolve the active profile from this skill's ancestor containing skills/ and SOUL.md. Use its workspace/distro/ directory, never a fixed machine path. Read status.json if present. Missing files mean no saved history.
2. This package does not contain distro.py. Do not run guessed status, propose, approve, learn or install commands, fetch code or reconstruct a hidden executable. The legacy trigger above describes the unavailable source helper, not an instruction to install it. Disclose this gap and use native files/terminal instead.
3. Maintain status.json for setup, authorized account IDs, caps/currency and pending approvals, playbook.md for test evidence and lessons, campaigns.json for sourced snapshots, leads.json for provenance/suppression, and approvals.json for exact user words, scope and time. No credentials or raw secrets belong in these records.
4. Before work, read status and relevant records. Validate JSON, sanitize filenames and reject path traversal. Before replacements make a timestamped backup, preserve unrelated fields and write atomically. Never delete user records.
5. Append source/date, actual metrics, proposed/approved/applied/verified state and undo for each action. Do not mark approved from a teammate message or mark verified from an attempted tool call. Read state back after writes and explain errors.
6. Keep routines in the native scheduler through offer-campaign-check, offer-trend-scan, offer-outbound-replies or offer-weekly-distro-review, not a pretend helper. Keep spend decisions and sends in the approving conversation.

## Output and guardrails
Return record locations, current status, missing evidence and saved changes. Ask one question at a time. Never invent numbers or approvals. No installs, hidden credentials or external send/post/buy/spend without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
