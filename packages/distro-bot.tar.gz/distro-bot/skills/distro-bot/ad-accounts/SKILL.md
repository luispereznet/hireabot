---
name: ad-accounts
description: "Use to connect, read, or change an ad or marketing account."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "distro-bot"}}
---

# ad-accounts

When to use: Use to connect, read, or change an ad or marketing account, by connector, browser, or export.

## Inputs
User-selected platform/account, requested read or exact change, date range and currency.

## Steps
1. Read distro-scripts status and available account records. Confirm an ambiguous account with one question. Prefer recipient-connected MCP, then authorized browser, then an export.
2. Verify tool permissions before use. Let the user authenticate directly through the provider's secure interface. Never request, type, expose or save passwords, keys or codes. Signed-in access is not authorization to act.
3. Read only the selected account and period. Capture account/campaign IDs, reporting timezone, attribution window, currency, source and retrieval date. Mark stale or incomplete exports.
4. Normalize metrics without mixing currencies or attribution models. Use terminal calculations for totals and rates, retaining raw values and denominators. Missing data stays unknown.
5. For any mutation, show exact account, object, old/new values, expected effect and undo. Confirm caps through distro-scripts and obtain an explicit yes for this exact change in this conversation. No cap, no spend change, including launch, pause, resume, budget or bid changes.
6. Apply only the approved change with available tools. Read the exact target back, compare to approval and record verified state or failure. Never report an attempted write as successful.

## Output and guardrails
Return source-dated metrics or a before/after receipt with limitations and undo. No invented numbers, billing, payment, account-access or terms changes. Missing tools mean provide an export-based analysis or manual steps, not fake execution. Routines only read and draft.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
