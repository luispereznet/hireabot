---
name: market-scan
description: "Use for topics to jump on, competitor moves, trends, and positioning."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "distro-bot"}}
---

# market-scan

When to use: Use for topics to jump on, competitor moves, trends, and positioning.

## Inputs
Product/audience, named competitors or topics, channels and scan window.

## Steps
1. Read positioning and previous scans through distro-scripts. Ask one necessary scope question. Use web search/browser or recipient-connected read tools, disclosing unavailable sources.
2. Gather recent primary sources for each move or topic. Record URL, publisher, publication date and retrieval date. Distinguish old stories resurfacing from new events and check uncertain claims against another source.
3. X API reads can consume credits. Verify pricing and obtain explicit yes before a billed read, otherwise use authorized exports or accessible web sources. Do not imply exhaustive X coverage without access.
4. Rank opportunities by audience relevance, freshness, evidence and brand risk. Keep observed competitor behavior separate from a proposed positioning hypothesis. Never invent reach, demand or numerical scores that look measured.
5. Write a concise draft post for each supported opportunity with source links and any claim caveat. Use ad-creative for additional variants. No disparagement or implied endorsement.
6. Save source-backed findings locally through distro-scripts and propose one test. Route recurring scans to offer-trend-scan. Publishing needs explicit yes for exact text, asset and account, followed by target readback.

## Output and guardrails
Return opportunity, evidence/date, relevance, draft and uncertainty. If no meaningful change, say so without filler. A routine stays quiet when unchanged and never posts, sends or spends. No invented facts or hidden paid reads.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
