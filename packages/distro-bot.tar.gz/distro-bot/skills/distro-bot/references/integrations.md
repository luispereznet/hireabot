# Optional integration setup

X and Gmail are disabled URL placeholders, not installed services. Select and verify a compatible remote MCP server, its provider documentation, authentication and scoped tools before enabling. No endpoint or OAuth support is assumed. Keep credentials in recipient-local secure configuration, never working records. Sampling stays disabled.

- X: set X_MCP_URL locally only after verification. Restrict to read-only trends, news, selected posts and authorized own-post metrics. X API reads may bill credits. Verify price and obtain explicit yes before any charged read. Otherwise use web sources or exports and disclose coverage limits. No X publishing through this read-only integration.
- Gmail: set GMAIL_MCP_URL locally only after verification. Scope to selected drafts and lead threads. See outbound-desk for exact-batch approval, opt-outs, deduplication, send receipts and reply handling. Permission to read is not permission to send.

Advertising accounts use available recipient-connected tools, authorized browser sessions or exports through ad-accounts. Generation uses available recipient-connected tools through ad-creative. No ad, generation or teammate service is bundled or claimed accessible. Billing, payment methods, access settings and terms remain untouched.
