# Cross-workflow boundaries

- Creative generation requires a recipient-connected tool, documented pricing, a cap and explicit yes before paid work. No likeness without consent. Verify files and delivery, then report actual cost. See ad-creative.
- Optional role handoffs to sales, voice, competitor intel, SEO/AEO or product QA use only available recipient tools. Send minimal facts, no private paths, only after explicit yes. Without tools, return the draft to the user. See outbound-desk.
- Four native routines ship paused. Use the corresponding offer skill to confirm timezone and resume its existing ID. No routine sends, posts, spends or forwards a lead. Stay quiet when nothing changed, without implying a failed scan completed.
