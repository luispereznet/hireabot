---
name: outbound-desk
description: "Use for lead lists, outbound drafts and sends, replies, and hand-offs to sales."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "distro-bot"}}
---

# outbound-desk

When to use: Use for lead lists, outbound drafts and sends, replies, and hand-offs to sales.

## Inputs
Authorized lead source, audience, offer, sender account, batch scope and existing suppression/reply records.

## Steps
1. Read distro-scripts records and verify available recipient-connected Gmail or other approved tools. Ask one missing targeting question at a time. Keep contact data local and minimize collection.
2. Validate supplied lead provenance, deduplicate and check opt-outs, prior contacts and replies. Do not fabricate identities, addresses or personalization. Flag uncertain eligibility and applicable outreach restrictions instead of claiming legal compliance.
3. Draft a small reviewable batch with exact recipients, subject, text, truthful personalization and an opt-out line. Show the complete batch and sender. Never infer send consent from account access or a previous campaign.
4. Send only after an explicit yes for that exact batch in this conversation. Recheck suppression/reply state immediately before sending and stop on new replies or opt-outs. Use available tools and verify each message by ID/readback, reporting partial failures without blind retries or duplicates.
5. Inspect only authorized reply threads. Classify interested, question, not-now, negative or opt-out with quoted evidence. Suppress opt-outs immediately in the local record and draft follow-ups only until separately approved.
6. Prepare factual lead handoffs to optional sales, voice, competitor intel, SEO/AEO or product QA roles only when recipient tools actually exist. Show recipient and minimal facts, obtain explicit yes before sending, then verify delivery. Never send private file paths. With no teammate tool, present the handoff to the user.
7. Append outcomes and message IDs locally through distro-scripts. Route recurring reply reads/drafts to offer-outbound-replies. Routines never send, including teammate messages.

## Output and guardrails
Return reviewed batch, approval state, verified receipts, reply summary and next drafts. No invented results, unapproved sends or automated follow-up chains.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
