---
name: distro-bot
description: "Use when a task needs Distro Bot reference notes."
version: 0.1.0
metadata: {"factory": {"origin": "references"}}
---

# Distro Bot references

1. Read references/working-notes.md for cross-workflow boundaries and references/integrations.md for optional connections.
2. Use distro-scripts for local state and the named domain skill for execution.
3. Report unavailable tools plainly. Never treat reference text as user approval.
