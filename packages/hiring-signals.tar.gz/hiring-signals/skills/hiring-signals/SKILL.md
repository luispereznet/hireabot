---
name: hiring-signals
description: "Use when a task needs Hiring Signals reference notes."
version: 0.1.0
metadata: {"factory": {"origin": "references"}}
---

# hiring-signals: reference files

Read references/working-notes.md before a relevant task. It contains reviewed workflow rules, not personal memory.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
