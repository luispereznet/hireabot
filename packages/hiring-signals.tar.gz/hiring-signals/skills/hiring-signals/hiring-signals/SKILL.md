---
name: hiring-signals
description: "Use when connect sources into normalized hiring-signal rows."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "hiring-signals"}}
---

# hiring-signals

When to use: Connect sources into normalized hiring-signal rows; standing feed not one-shot.

Inputs: scoped job sources, ICP rubric, account/owner map, confirmed field mapping and prior snapshot. Read ../references/working-notes.md.

1. Confirm source scope, freshness, dedupe/conflict rules and read/draft/write permissions. Use live connectors if available; accept pasted jobs, CSV, export, URL or file. Disclose unavailable tools and never claim ongoing monitoring from a one-time run.
2. Normalize rows: source ID/URL, company/domain, role/title/family, location, posting/status dates, observed-at, account/owner match, fit evidence, change type and uncertainty. Unknown stays Unknown; preserve source timestamps and conflicting values rather than silently merging.
3. Dedupe by confirmed source/job key and cross-source identity; compare with prior snapshot for new/materially changed signals. Distinguish reposts from new roles; absence is not a confirmed closure without reliable source coverage.
4. Apply only the confirmed ICP rubric and thresholds. Explain each score with sourced evidence; do not infer buying intent, budget or company growth from job counts alone. Match canonical accounts and owners only through approved IDs/domain maps; flag ambiguous matches.
5. Produce proposed normalized upserts and high-fit digest. Before writes confirm exact system-of-record fields, scope/destination and approval boundary. Re-read exact changed records after authorized writes. Handoff recommendations remain local drafts unless each send is explicitly approved.
6. Recurring work requires the exact offer skill, schedule/timezone, sources, fields, private destination, empty-result policy and explicit yes. Any change requires reconfirmation; subagents never write. Default shipped delivery is local.

Output: normalized rows, dedupe/change report, fit/account evidence, conflicts, source coverage/freshness and next decisions. No customer-facing messages; broader account research and prospect selection belong to optional siblings.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
