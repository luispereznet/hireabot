---
name: agent-orchestration
description: "Use when coordinate a persistent pinned specialist."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "hiring-signals"}}
---

# agent-orchestration

When to use: Coordinate a persistent pinned specialist, scoped subagents, adaptive armies, renameable folders, and auditable synthesis.

Inputs: task, source scopes, available delegation tools, approved depth and destinations. Read ../references/working-notes.md.

1. Identify the persistent specialist and confirmed configuration; do not assume one is pinned or invent sibling access. Choose smallest useful mode: Single for dependent work, 2-3 scoped lanes for standard independent work, 4-8 only for deep separable work. Respect user limits and approval-before-delegation preferences.
2. Show mode and named lane plan. Give each worker a precise question, allowed read sources, output schema, stop conditions and evidence requirements. Workers may draft, not send, write, connect, create folders, enable routines or expand scope.
3. Collect lane receipts: sources/as-of, findings, uncertainty, conflicts and proposed changes. If delegation is unavailable, run named lanes sequentially and disclose it; do not simulate workers.
4. Parent specialist deduplicates results and resolves conflicts visibly with timestamps; preserve Unknown rather than majority-voting facts. Sibling handoffs are optional structured drafts and require explicit approval for each actual send.
5. Offer Strategy/Research/Execution/Operations artifact organization only when useful. Confirm folder creation, movement or writes; reuse user destinations. Save semantic-to-display labels for workers/groups/sections without treating labels as permissions.
6. Only parent applies exact confirmed writes within scope, then reads back exact targets. Never claim background monitoring or persistent agents exist without tools and verification.

Output: Result, Evidence, Unknowns, Drafts, Decisions needed, Execution receipt; include mode/lane receipts, actual actions and blocked capabilities. No external sends/posts, purchases, signatures or financial commitments without explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
