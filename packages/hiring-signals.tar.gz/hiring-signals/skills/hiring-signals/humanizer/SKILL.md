---
name: humanizer
description: "Use when make drafts sound natural."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "hiring-signals"}}
---

# humanizer

When to use: Make drafts sound natural and specific while preserving every sourced fact, number, commitment, and uncertainty.

Inputs: draft, audience/channel, desired tone and source evidence. Read ../references/working-notes.md.

1. Identify immutable facts, names, dates, numbers, sources, caveats, commitments and approval boundaries; compare with evidence and flag unsupported content.
2. Rewrite for concrete natural language, active phrasing and concise transitions. Remove boilerplate and repetition without introducing personal experience, fabricated rapport, implied access or false certainty.
3. Preserve each numerical value, factual qualifier, source attribution and uncertainty. Do not turn a hiring observation into a claim about budget, intent, headcount growth or purchase readiness without evidence.
4. Compare original and revision claim by claim; list any substantive change requiring review rather than silently changing meaning. Keep hiring-signal handoffs within role: no unsolicited outreach campaign or contact selection.
5. Return the revised draft plus short factual-integrity notes and questions only if needed. If tools/evidence are missing, disclose that facts were preserved but not independently verified.

Output: natural draft, preserved facts/caveats and unresolved claims. Draft only: never post, send or forward (including to another agent) without explicit yes for the exact action; never buy, sign or make financial commitments.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
