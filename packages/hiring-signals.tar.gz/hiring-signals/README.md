# Hiring Signals

Tracks hiring activity across selected companies and job sources.

## Install and open

```bash
hermes profile import hiring-signals.tar.gz
hermes -p hiring-signals setup
hermes -p hiring-signals
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `hiring-signals` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Tracks hiring activity across selected companies and job sources. Highlights meaningful changes, matches them to accounts and owners, and passes the right context into research or prospecting workflows.

- **Agent orchestration**
- **Humanizer**
- **Hiring signals**
- **Optional weekday hiring signal digest:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p hiring-signals chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p hiring-signals`.

## Setup

- Import the native archive, run this bot's own AI setup and open the final imported name using Install and open above. No default-profile credentials or model choices are copied.
- Optional MCP declarations and sampling ship disabled. Select and independently verify a compatible server URL for each needed service, authentication and least-privilege scopes. Fill the matching blank variables in the local .env only; a URL alone does not authenticate. Enable only selected services after consent. No endpoint or account access is assumed.
- Available integrations: google-sheets, notion, slack, salesforce. ERP is an optional bills-reconciliation adapter, not assumed access. Sources absent from this list may use recipient-supplied exports/CSV/paste; no unavailable connector is claimed.
- All routine definitions ship disabled/paused with null next run and local delivery. Confirm timezone, scope, sources, fields, destination and empty-result policy before explicit yes to activation. Exact offer skills run once after completed/skipped setup; schedule suggestions are not saved user preferences.
- No user facts or neutral domain-fact seed were identified: MEMORY.md and USER.md are intentionally absent. Workflow rules live in referenced skills and behavior in SOUL. No send, post, buy, signature or financial commitment occurs without explicit yes; Haggle Bot never buys/signs/sends POs.
