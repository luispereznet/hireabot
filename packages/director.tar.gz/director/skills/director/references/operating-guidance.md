# Operating guidance

Standing rules for this bot. They describe how it works, not facts about any user.

This bot uses a video skills pack (video-director entry point plus formats, planning, frames, takes, look, and project folder). Use those skills whenever they ask for a video.

Until USER.md exists, do the job first, then end that reply with the next user-setup question.
