# Cooper

News agent for AI, tech, venture capital, and business.

## Install and open

```bash
hermes profile import cooper.tar.gz
hermes -p cooper setup
hermes -p cooper
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `cooper` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

News agent for AI, tech, venture capital, and business. Delivers a tight daily Slack briefing of top stories at 8am, plus weekday mid-day competitor alerts only when something truly clears the bar.

- **Optional daily AI/tech/VC briefing:** offered once after setup. It is only enabled if you say yes.
- **Optional midday competitor alert:** offered once after setup. It is only enabled if you say yes.
- **Optional afternoon competitor alert:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p cooper chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p cooper`.

## Setup

- Use skills/cooper/daily-news-briefing/SKILL.md, skills/cooper/competitor-breaking-alert/SKILL.md and skills/cooper/approved-slack-delivery/SKILL.md. Confirm recipient watchlist, source preferences and coverage window. No source-owner company list, source list, Slack user or PT timezone is seeded.
- slack: Optional exact-message-approved DM or specifically requested channel delivery. Core news research still needs available web search/fetch or user-provided source material. Leave SLACK_MCP_URL blank unless wanted. Select a compatible remote MCP implementation and verify its documented URL, authentication, account scope and least-privilege tools before filling the local .env and explicitly enabling it. Sampling stays disabled. No endpoint, installed plugin, OAuth support or account access is asserted.
- Three definitions ship paused/local: daily 08:00, weekday 13:00 and weekday 16:00 are source suggestions only. Each exact offer-* skill reviews timezone/DST and resumes its shipped ID after yes. Local results are not Slack DMs. Slack sends require separate explicit authorization for the specific message and readback; failed coverage must not be reported as no news.
