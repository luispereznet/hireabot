---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load` via the helper's `finish` step.


# First-start setup for Cooper

This profile ships no USER.md or recipient facts. Questions are skippable; do requested work first. Helper: `python3 <this skill folder>/scripts/user_setup.py`.

1. If the message is exactly "Reply only: READY", reply READY and do nothing else. Otherwise run helper `status`. DONE means do not restart questions; finish any pending one-time routine offers below.
2. Read questions.json or helper `questions`. Ask one question per reply. Pause for real work. Never assume source-owner preferences or account access.
3. Only if useful, ask once whether to read other profiles' USER.md. Run `scan-others --consent` only after explicit yes, show results and retain only confirmed lines. Never write another profile.
4. For completed setup, show answers JSON and optional confirmed other-facts JSON in this profile's workspace. Use helper `write --answers <file> [--others <file>] --dry-run`; after permission to save, repeat without --dry-run. Shorten over-cap answers with the user. Save only confirmed facts.
5. A global setup skip ends all questions and scans immediately. Keep answers already given and add rules: "Setup skipped by the user; ask for a preference only when a job needs it." Run the step 4 dry-run/write without replacement questions. Require `status` DONE. `write` calls `finish`; retry finish on failure and disclose failure rather than claiming completion. Never execute finish outside an installed named profile.
6. Once completed or skipped, do not repeat onboarding. Handle optional offers below one per reply, separately from setup questions. Honor a request to skip routine offers too.

## One-time routine routes

- Load `offer-daily-ai-tech-vc-briefing` at `skills/cooper/offer-daily-ai-tech-vc-briefing/SKILL.md`.
- Load `offer-midday-competitor-alert` at `skills/cooper/offer-midday-competitor-alert/SKILL.md`.
- Load `offer-afternoon-competitor-alert` at `skills/cooper/offer-afternoon-competitor-alert/SKILL.md`.
Offer each once after completed or skipped setup. Check the consented workspace/routine-choices.json offered/declined/enabled state first; mark offered before asking and preserve unanswered as offered, not declined. If storage is refused, use current conversation state and do not repeat without request. Resume the same shipped ID only after explicit yes and verification, never create duplicates.
