---
name: offer-midday-competitor-alert
description: "Use after setup or when asked about routines: offer midday competitor alert."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "cooper"}}
---

# Offer the midday competitor alert

When to use: Once after completed or skipped setup, or when the user asks about this routine.

Suggestion: Weekdays at 1:00 PM — Slack DM only if a top competitor/hire/priority-company story clears the bar; otherwise stay silent.
Native job `24827c2c45ce` ships paused/local; no next run. Suggested expression `0 13 * * 1-5` needs recipient timezone approval. Local output is not a Slack DM.

1. Check this active profile's consented workspace/routine-choices.json. Offered/declined/enabled suppresses repeat offers unless requested. With permission to save choices, mark offered before asking once: "Enable midday competitor alert for local results after schedule review?" No means declined and paused; silence means offered, not declined. If storage is refused, use conversation state without repeating offers. Routine-offer opt-out suppresses this too.
2. After explicit yes, confirm time, days, IANA timezone and first-run coverage boundary one question at a time. Inspect actual scheduler timezone/DST behavior; convert the suggested schedule only after checking interpretation. Confirm watchlist and optional checkpoint storage. Never assume PT or the source owner's recipient.
3. With available native scheduler tools scoped to this active profile, list jobs first and find `24827c2c45ce`; verify its name/prompt and equivalents. Preserve the same ID after profile rename. Update this paused definition as approved, then resume only after explicit schedule approval. Never create duplicates or use a manual run as preview. If ID is missing or tools unavailable, stop and disclose; do not create a replacement without separate approval and duplicate checks.
4. Read back the exact job after edits/resume: ID, approved expression/timezone interpretation, enabled/state, local delivery and next run. Only then record enabled and verified details in the consented choice file. Explain how to request pause/change. No means leave paused, not remove.
5. Execution loads `skills/cooper/competitor-breaking-alert/SKILL.md`. Slack requires connected tools and `skills/cooper/approved-slack-delivery/SKILL.md`; each specific message needs explicit send approval, separate from routine opt-in. Never invent sources, news or numbers.
