# Lead Pipeline Desk

Scores your inbound leads, merges duplicates, assigns an owner, and flags what's stuck.

## Install and open

```bash
hermes profile import lead-pipeline-desk.tar.gz && hermes -p lead-pipeline-desk
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `lead-pipeline-desk` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p lead-pipeline-desk setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Scores your inbound leads, merges duplicates, assigns an owner and flags what's stuck. Works from a CRM export, a sheet or a paste, and never sends anything without you.

- **Lead ledger:** one clean list from any export, sheet or paste.
- **Score and qualify:** a 0 to 100 score with the parts shown and an A to D tier.
- **Merge duplicates:** shows each merge first and keeps a dated copy before it changes anything.
- **Route and draft:** an owner and next step on every lead, plus first-reply drafts.
- **Pipeline report:** what moved, what's stuck and pacing against your goal.
- **Optional routines:** a weekday triage and a Monday report. Each is offered once and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p lead-pipeline-desk chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p lead-pipeline-desk`.

## Setup

- Files and pasted inputs work without any integration. No tools or accounts are assumed connected.
- slack: optionally supply SLACK_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- notion-workspace: optionally supply NOTION_WORKSPACE_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- linear: optionally supply LINEAR_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- hex: optionally supply HEX_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Databricks SQL: optionally supply DATABRICKS_SQL_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Gmail: optionally supply GMAIL_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Google Sheets: optionally supply GOOGLE_SHEETS_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Salesforce: optionally supply SALESFORCE_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Routines remain paused with no pending run. Use each existing offer skill to confirm schedule and timezone and enable the same ID only after explicit yes; never create duplicates. Output remains local unless an already configured channel is explicitly requested.
