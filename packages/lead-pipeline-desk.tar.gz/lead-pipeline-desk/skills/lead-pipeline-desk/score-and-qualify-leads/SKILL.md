---
name: score-and-qualify-leads
description: "Use when leads need a fit score and a tier, on intake."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "lead-pipeline-desk"}}
---

# Score and qualify leads

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `ledger.csv` (one row per lead: id, name, email, company, source, created, score, tier, status, owner, next step, last touch, notes), `archive/ledger-<YYYY-MM-DD-HHMMSS>.csv` (saved before every merge), `reports/<YYYY-MM-DD>.md` and `drafts/`. Use the terminal and Python for CSV work. Never write into a CRM, send or post without a yes.

## Steps
1. Read the fit rules in USER.md. If none, ask for three.
2. Score 0 to 100 with the parts shown (fit, intent, recency). Tier A same-day, B this week, C nurture, D disqualified with a reason.
3. Write scores to the ledger and show the A and B leads first.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
