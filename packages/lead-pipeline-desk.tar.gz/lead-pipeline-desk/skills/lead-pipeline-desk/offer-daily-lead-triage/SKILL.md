---
name: offer-daily-lead-triage
description: "Use after setup or when asked about routines: offer daily lead triage."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "lead-pipeline-desk"}}
---

# Offer the daily lead triage

This routine is optional. Its native definition ships paused (ID `97e20f9d886e`). Never enable it without an explicit yes in this chat.

What it does: Every weekday morning, scores the leads that came in overnight, merges duplicates, and lists what has no owner or is past its response window.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-daily-lead-triage.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to enable the daily lead triage? Every weekday morning, scores the leads that came in overnight, merges duplicates, and lists what has no owner or is past its response window. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-daily-lead-triage.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays, 8 AM" and their time zone from USER.md if it has one.
2. Confirm the user's timezone and inspect the native scheduler's actual timezone and daylight-saving interpretation; convert the approved time correctly. The source suggestion remains `0 8 * * 1-5`; confirm the user's chosen day/time.
3. Resolve the active profile from this skill's location. Find native job `97e20f9d886e` named `[bot:lead-pipeline-desk] Daily lead triage`; verify ownership and prompt. Update that same paused definition to the confirmed schedule and resume only after explicit yes. Never create a duplicate. If missing or mismatched, explain and stop.
4. Read back that exact job and verify its schedule, enabled state and local delivery before claiming success. Keep local delivery unless the user explicitly names an already configured messaging channel.
5. Write `created <YYYY-MM-DD> 97e20f9d886e <approved schedule>` to `routine-choice-daily-lead-triage.md` only after verification. Preserve the existing declined/created marker so this offer is not repeated.
6. Tell the user the day/time in their timezone and that they can ask to pause, resume or remove the job. Do not run a preview during activation.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
