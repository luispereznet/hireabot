---
name: route-leads-and-draft-the-first-reply
description: "Use when scored leads need an owner."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "lead-pipeline-desk"}}
---

# Route leads and draft the first reply

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `ledger.csv` (one row per lead: id, name, email, company, source, created, score, tier, status, owner, next step, last touch, notes), `archive/ledger-<YYYY-MM-DD-HHMMSS>.csv` (saved before every merge), `reports/<YYYY-MM-DD>.md` and `drafts/`. Use the terminal and Python for CSV work. Never write into a CRM, send or post without a yes.

## Steps
1. Apply the routing rule to give each scored lead an owner and a next step.
2. Draft a short first reply per A and B lead from what the lead actually said. Save to `drafts/`.
3. If Gmail is connected, save drafts there only on a yes. Never send.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
