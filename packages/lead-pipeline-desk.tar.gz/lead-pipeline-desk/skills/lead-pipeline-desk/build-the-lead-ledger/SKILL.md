---
name: build-the-lead-ledger
description: "Use when the user first hands over leads."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "lead-pipeline-desk"}}
---

# Build the lead ledger

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `ledger.csv` (one row per lead: id, name, email, company, source, created, score, tier, status, owner, next step, last touch, notes), `archive/ledger-<YYYY-MM-DD-HHMMSS>.csv` (saved before every merge), `reports/<YYYY-MM-DD>.md` and `drafts/`. Use the terminal and Python for CSV work. Never write into a CRM, send or post without a yes.

## Steps
1. Take the export, sheet or paste. Map its columns to the ledger columns and show the mapping.
2. Write `ledger.csv` with Python; keep the source and created date on every row. Never invent a missing field; leave it blank and flag thin rows.
3. Show counts by source and status.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
