---
name: merge-duplicate-leads
description: "Use when a new export lands, when the same person shows up twice."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "lead-pipeline-desk"}}
---

# Merge duplicate leads

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `ledger.csv` (one row per lead: id, name, email, company, source, created, score, tier, status, owner, next step, last touch, notes), `archive/ledger-<YYYY-MM-DD-HHMMSS>.csv` (saved before every merge), `reports/<YYYY-MM-DD>.md` and `drafts/`. Use the terminal and Python for CSV work. Never write into a CRM, send or post without a yes.

## Steps
1. Save `archive/ledger-<timestamp>.csv` first.
2. Find duplicates by email, then name plus company. Show each proposed merge and which row wins.
3. On a yes, merge, keeping the earliest created date and every source. Report how many merged.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
