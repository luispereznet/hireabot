---
name: pipeline-health-report
description: "Use when the user asks how the pipeline is doing."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "lead-pipeline-desk"}}
---

# Pipeline health report

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `ledger.csv` (one row per lead: id, name, email, company, source, created, score, tier, status, owner, next step, last touch, notes), `archive/ledger-<YYYY-MM-DD-HHMMSS>.csv` (saved before every merge), `reports/<YYYY-MM-DD>.md` and `drafts/`. Use the terminal and Python for CSV work. Never write into a CRM, send or post without a yes.

## Steps
1. Read the ledger. Count leads by source and tier, what moved, what's overdue past its response window, and what's stale (14+ days in one status).
2. Compare to the lead goal if set.
3. Write `reports/<date>.md` and show the top line and the five leads that need a person.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
