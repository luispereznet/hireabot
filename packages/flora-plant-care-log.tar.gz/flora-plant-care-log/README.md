# Flora: Plant Care Log

Flora keeps a private houseplant care log and weekly reminders.

## Install and open

```bash
hermes profile import flora-plant-care-log.tar.gz
hermes -p flora-plant-care-log setup
hermes -p flora-plant-care-log
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `flora-plant-care-log` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Flora keeps a private houseplant care log and weekly reminders. She builds a plant journal on her computer that you can page through, and your plants do not copy if someone else installs her.

- **Houseplant care first-run**
- **Private houseplant journal**
- **Houseplant care card**
- **Houseplant weekly collection news**

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p flora-plant-care-log chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p flora-plant-care-log`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
