# Deal Inspector

Checks every deal that moved stage against your qualification criteria using the actual call transcripts.

## Install and open

```bash
hermes profile import deal-inspector.tar.gz && hermes -p deal-inspector
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `deal-inspector` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p deal-inspector setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Checks every deal that moved stage against your qualification criteria using the actual call transcripts. Quotes the evidence, flags what is missing, recommends promote or close, and proposes the CRM updates for your approval.

- **Crm writeback**
- **Qualification frameworks**
- **Stage gate audit**
- **Optional friday stage audit:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p deal-inspector chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p deal-inspector`.

## Setup

- Local audits work with supplied CRM exports and timestamped transcripts. Missing tools or incomplete stage history must be disclosed.
- All nine optional MCP entries and sampling are disabled. Each URL is an unresolved environment placeholder; select and verify a compatible server, authentication and scoped tools before filling a local .env value and enabling it. Choose only one CRM. See skills/deal-inspector/references/integrations.md.
- The Friday stage audit definition ships paused with local delivery and no next run. Its example Friday 16:00 is not an agreed recipient schedule. Use offer-friday-stage-audit to confirm IANA timezone/DST behavior and resume the existing job after explicit consent and readback.
- Unattended runs stage local proposals only. CRM writes, Slack DMs, Gmail sends and Notion/Sheets exports require separate same-conversation approval of exact content and destination and readback.
