---
name: qualification-frameworks
description: "Use when defines what \"met\" means for each criterion of MEDDPICC."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "deal-inspector"}}
---

# qualification-frameworks

When to use: Defines what "met" means for each criterion of MEDDPICC, MEDDIC, BANT, SPICED, or the team's own framework, so every audit scores the same way.

## Inputs
The team's selected framework, criterion definitions, stage transitions and any approved existing rubric.

## Steps
1. Ask for the framework if unknown: MEDDPICC, MEDDIC, BANT, SPICED or custom. Ask one question at a time; use the team's approved definitions before generic expansions.
2. Draft a criterion table. MEDDIC covers metrics, economic buyer, decision criteria, decision process, identified pain and champion; MEDDPICC additionally covers paper process and competition. BANT covers budget, authority, need and timeline. SPICED covers situation, pain, impact, critical event and decision. Label these as starter definitions for approval, not team policy.
3. For each criterion define a concrete observable acceptance test, required buyer role, acceptable timestamped transcript evidence, disqualifying evidence and missing-data treatment. Distinguish an identified person from verified authority and an advocate from a validated champion; seller assertions alone do not establish buyer commitment.
4. Define per-transition mandatory criteria, plus champion, economic buyer, buyer-worded pain and sourced estimated size as promotion prerequisites. Agree whether and what explicit evidence warrants Close; lack of data alone never means disqualification.
5. Show the proposed rubric for confirmation. Save the approved version, date, stage gates and definitions to workspace/qualification-framework.md with a backup before replacement. Preserve earlier versions so audits remain comparable; unapproved drafts stay labeled draft.

## Output and guardrails
Return a versioned criterion/gate matrix for stage-gate-audit, with met, not met or missing rules. Never invent thresholds, budgets, sales policy or owner preferences. Use tools for arithmetic. No external publication without an explicit yes and readback; missing tools mean local draft only.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
