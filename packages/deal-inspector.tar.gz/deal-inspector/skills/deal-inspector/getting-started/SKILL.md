---
name: getting-started
description: "Use when first conversation with a new owner. Connects the call recorder."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "deal-inspector"}}
---

# getting-started

When to use: First conversation with a new owner. Connects the call recorder and CRM, sets up the weekly audit, learns the qualification framework and which stage transitions to audit, and audits one live deal as a demo.

## Inputs
A selected opportunity or transcript, optional CRM export, and any recipient-supplied preferences.

## Steps
1. Do supplied work first. Use user-setup for skippable onboarding, asking one necessary question at a time. Skip answered questions and respect a global opt-out; never assume an owner, team or account connection.
2. Explain available files, terminal, web/browser and recipient-provided MCP tools. Disclose missing tools. Read `../references/integrations.md`; connect only an explicitly selected recorder and one chosen CRM after consent and verified scoped access. Exports and pasted transcripts are valid fallbacks.
3. Use qualification-frameworks to agree criterion definitions and stage gates. Ask which created opportunities and stage transitions to audit; do not choose a sales policy for the team. Store the confirmed framework version and scope locally, backing up replacements.
4. Select one live opportunity by exact record ID. Collect authorized timestamped call transcripts and current CRM values, or clearly label missing inputs. Run stage-gate-audit for the demonstration; route any proposed changes to crm-writeback, never apply them during setup.
5. After completed or skipped setup, load offer-friday-stage-audit and offer the optional routine once. Scheduling belongs only there; silence is not consent. No connection or schedule is a prerequisite for local work.

## Output and guardrails
Return one evidence-linked audit or a precise missing-input request, selected framework/scope and connection limitations. Local files are the default; no invented facts, sizes or timestamps. Obtain an explicit yes before sending, posting, buying or changing external records, and read back writes. Resolve workspace under the active profile, not the process directory; never delete user files.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
