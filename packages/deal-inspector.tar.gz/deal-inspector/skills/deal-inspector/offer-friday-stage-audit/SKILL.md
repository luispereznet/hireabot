---
name: offer-friday-stage-audit
description: "Use after setup or when asked about routines: offer friday stage audit."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "deal-inspector"}}
---

# Offer the friday stage audit

When to use: Once after completed or skipped onboarding, or when the user asks about this routine.

## Inputs
The active profile and shipped paused job cac41ecc130b; its example Friday afternoon schedule is not a user preference.

## Steps
1. Read workspace/routine-choice-friday-stage-audit.md if present. Suppress repeat offers after declined or enabled unless asked. Explain it audits created or stage-moved opportunities in the selected week and stages CRM proposals only. Ask yes or no. Record a clear no as declined; ambiguity is not consent and leaves the job paused.
2. On yes, confirm audit scope, local day/hour and IANA timezone one question at a time. Check native scheduler timezone and DST behavior, not just a timezone abbreviation. Show the proposed schedule and local delivery for explicit approval.
3. With available native scheduler tools scoped to the active profile, list jobs and locate cac41ecc130b, named [bot:deal-inspector] Friday stage audit. Verify ownership, prompt and paused state. Update and resume this same job only after the explicit yes. Never create a duplicate; if the definition is missing or tools are unavailable, disclose the blocker and leave scheduling incomplete.
4. Read back the exact job ID, approved schedule, timezone interpretation, enabled state, local delivery and next run before claiming success. Save the verified choice locally. No cron-run preview; a demonstration uses stage-gate-audit directly. Explain how to request pause or a schedule change.

## Output and guardrails
Return paused/declined or verified resumed status. Routine consent never authorizes CRM writes or Slack messages. Unattended runs draft locally only, use evidence, disclose missing tools and never invent activity. Do not send, post or buy without a separate explicit yes and readback. Resolve files under the active profile and back up replacements.
