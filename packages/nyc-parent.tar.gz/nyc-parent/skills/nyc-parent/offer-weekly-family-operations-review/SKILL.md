---
name: offer-weekly-family-operations-review
description: "Use after setup or when asked about routines."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "nyc-parent"}}
---

# Offer the weekly family-operations review

This routine is optional. Its canonical definition 5a5c9715d130 ships paused. Never enable it without an explicit yes in this chat.

What it does: Every Sunday at 5 PM, the next two to four weeks: deadlines, registrations, conflicts and what needs booking or buying.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-weekly-family-operations-review.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the weekly family-operations review? Every Sunday at 5 PM, the next two to four weeks: deadlines, registrations, conflicts and what needs booking or buying. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-weekly-family-operations-review.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "Sunday 5 PM" and their time zone from USER.md if it has one.
2. Inspect the recipient scheduler's actual timezone and DST handling; do not infer it from an abbreviation. Convert the user's agreed time to that scheduler clock and confirm the result before activation. Build a 5-field cron expression (the suggestion is `0 17 * * 0`).
3. Resolve the active profile from this loaded skill's ancestor containing SOUL.md and skills/. With available native scheduler tools scoped to that profile, list existing jobs and find canonical ID `5a5c9715d130` named `[bot:nyc-parent] Weekly family-operations review`. Confirm the prompt matches the routine below. Update that same paused job to the approved schedule, then resume it only with explicit yes. Do not create a duplicate. If the definition is missing, list and check for an equivalent job before asking permission to create exactly one equivalent local-delivery job.

   Routine prompt: Routine: Weekly family-operations review. Every Sunday at 5 PM, the next two to four weeks: deadlines, registrations, conflicts and what needs booking or buying. Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers.

   Delivery is local unless the user explicitly names an already configured channel. Setup completion is not activation consent.
4. Read the exact job back and verify ID, name, prompt, approved schedule, delivery and enabled state; report failure plainly. Never mark success unless the read-back matches.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-weekly-family-operations-review.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
