# Optional integration setup

All entries ship disabled with sampling disabled. Each URL is an optional recipient-supplied environment reference, not a verified provider endpoint. Choose and verify a compatible MCP server, its authentication and scoped tools before enabling; do not infer access from configuration. Keep secrets local. Read only recipient-authorized sources.

- EMAIL_MCP_URL: Optional recipient-verified email MCP URL; unset means unavailable.
- CALENDAR_MCP_URL: Optional recipient-verified calendar MCP URL; unset means unavailable.
- SCHOOL_PORTALS_MCP_URL: Optional recipient-verified school-portals MCP URL; unset means unavailable.

Email, calendar and school portals are optional live source types. Without connections use forwarded/pasted messages, files or screenshots. Every booking or spending commitment still requires a fresh yes for that one item.
