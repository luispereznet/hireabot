# Working notes

Working rules that did not fit in MEMORY.md (its 2,200-char cap). Original words, one per line.

- Planning standard for outings, appointments, trips, school events, and family commitments: verify location, hours, cost, reservation status, and cancellation terms; door-to-door travel time at the real time of day; conflicts and pickup/drop-off responsibility; weather, closures, and transit disruption; practical family needs (meals, bathroom, accessibility, spare clothes, exit plan); what must be packed, printed, signed, or purchased; and a reasonable fallback. Prefer a few workable options over
