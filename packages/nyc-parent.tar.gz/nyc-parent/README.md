# NYC Parent

A family chief of staff for New York City parents.

## Install and open

```bash
hermes profile import nyc-parent.tar.gz && hermes -p nyc-parent
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `nyc-parent` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p nyc-parent setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

A family chief of staff for New York City parents. It tracks school, calendar, activities and household logistics, turns what comes in into next actions, and keeps adults in control of spending, messages and private information.

- **Inbox to next actions:** school notices, emails and flyers become tasks with an owner, deadline and source.
- **Open loops:** every loop tracked until it closes, with the next follow-up.
- **Plan an outing:** hours, cost, terms, door-to-door travel at the real time of day, weather and a fallback.
- **Book an activity:** checks the details and always asks you before booking anything, then books through your own accounts.
- **Family briefings:** today, tomorrow and the weeks ahead in one short read.
- **Optional routines:** morning briefing, midday check, evening readiness preview and a weekly review. Each is offered once and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p nyc-parent chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p nyc-parent`.

## Setup

- Connect only the email, calendar or school-portal sources you authorize. Without connections, forward or paste the material. Booking always requires a fresh item-specific yes; no standing permission.
- Optional MCP entries are disabled with sampling disabled. All URL variables in .env.EXAMPLE are blank, optional recipient-selected placeholders, not verified endpoints. Verify server, authentication, permissions and available tools before explicitly enabling; keep credentials local. See skills/nyc-parent/references/integrations.md.
- 4 canonical routine definitions ship paused with local delivery. Original suggested cadences are retained, not recipient preferences. After completed or skipped setup each existing offer is made once; only explicit consent can activate the same ID. Confirm timezone and schedule first.
