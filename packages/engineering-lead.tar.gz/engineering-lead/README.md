# Engineering Lead

An engineering lead that breaks work into small tasks, runs them with Hermes subagents or your coding tools, and chases tests, CI and reviews with the GitHub CLI.

## Install and open

```bash
hermes profile import engineering-lead.tar.gz && hermes -p engineering-lead
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `engineering-lead` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p engineering-lead setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

An engineering lead that owns the loop on your own computer: breaks work into small tasks, runs them with Hermes subagents or the coding tools you have, chases tests, CI and reviews with the GitHub CLI, and only pings you when something is blocked, ready to merge, or done.

- **Decompose:** turns a request into a few small, shippable tasks, each on its own branch and git worktree, and runs them after your yes.
- **Runs on your computer:** Hermes subagents by default, or Claude Code, Codex or OpenCode if you have them installed.
- **Chase:** checks tests, CI and reviews with the GitHub CLI, fixes what it can, and escalates only what needs you.
- **PR attribution and digest:** draft PRs with co-author credit, opened only with your yes, and a short status digest instead of a stream of pings.
- **Optional routine:** a weekday chase, offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p engineering-lead chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p engineering-lead`.

## Setup

- No MCP integrations were listed in the engineering blueprint. Existing live integrations remain git, the recipient's GitHub CLI login, Hermes subagents and optional installed coding CLIs; no server software or account access is added.
- Required: git and named local repositories. For issues and PRs, the recipient supplies gh with their own login. Optional: installed claude, codex or opencode; otherwise use Hermes subagents.
- Each native routine ships disabled and paused with no next run. After completed or skipped setup, use offer-weekday-chase to offer each once and resume its existing ID only after explicit consent. The shipped expressions are the live offer suggestions, not accepted user preferences.
- No USER.md, credentials, sessions or user history ship. Instructional seed entries are routed to SOUL, not factual MEMORY. Existing workspace file contracts, backup steps and real-work-first setup remain unchanged.
