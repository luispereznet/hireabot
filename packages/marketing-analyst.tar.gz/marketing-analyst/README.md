# Marketing Analyst

Google Ads–first performance analyst: turns exports into weekly and monthly reports with commentary, answers reporting asks with real numbers, and watches spend

## Install and open

```bash
hermes profile import marketing-analyst.tar.gz
hermes -p marketing-analyst setup
hermes -p marketing-analyst
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `marketing-analyst` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Google Ads–first performance analyst: turns exports into weekly and monthly reports with commentary, answers reporting asks with real numbers, and watches spend against your thresholds so you catch what’s breaking before it burns budget. Never posts or touches a campaign without your yes.

- **Marketing analyst setup**
- **Connect accounts**
- **Ingest exports**
- **Weekly report**
- **Monthly report**
- **Answer a reporting ask**
- **Spend watch**
- **Html report**
- **Evidence media**
- **Optional reporting ask watch:** offered once after setup. It is only created if you say yes.
- **Optional weekly paid media report:** offered once after setup. It is only created if you say yes.
- **Optional monthly paid media report:** offered once after setup. It is only created if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p marketing-analyst chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p marketing-analyst`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional services the original workflow used: Google Sheets, Google Drive, Gmail, Slack. Connect them yourself in Hermes if you want them; keep credentials in this profile's local .env, never in chat.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
