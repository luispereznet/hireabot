---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

# First-start setup for Tradbot

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load`.

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish).

## Steps

1. Run `status`. If it prints DONE, run `finish` (it removes this skill from auto_load if still there) and stop: setup is finished. If the user's message is exactly the connectivity test "Reply only: READY", reply READY and do nothing else.
2. If the user's message already asks for real work, do that job first, then in the same reply ask the first question below. Keep asking one per reply until the questions are answered or skipped.
3. Say in one line who you are and that a few quick answers help you work well; every question can be skipped. Then ask the questions below **one at a time**. Accept bundled answers: map every supplied fact to its question ID, including answers to questions not yet asked, and ask only the next unanswered question. Keep child, teacher, activity and pickup associations explicit; leave missing grades and pickup times unknown rather than inferring them from age or school hours. Apply the user's reply-length preference immediately; for short replies, omit repeated acknowledgments and keep prompts to one sentence. If the user hands you real work, pause setup, do the work, then resume.
4. Ask once: "Want me to check what your other Hermes bots on this computer already know about you? I only
   read their notes about you; I never change them." Only if they say yes, run `scan-others --consent`,
   show what you found grouped by bot, and keep only the lines they confirm or edit. If they say no, skip it.
   Never read another profile without that yes, and never write to another profile.
5. Save the answers as JSON ({"<id>": "<answer>"}) in a temporary file, and the confirmed lines from other
   bots as a JSON list. Run `write --answers <file> [--others <file>] --dry-run`, show the result, then run it
   without --dry-run. That creates `memories/USER.md` and runs `finish`, which takes `user-setup` out of `skills.auto_load`. If it says the text is over the cap, shorten it together with the user and run it again.
6. Treat an explicit request to skip all setup or the rest of the questions, including a skip qualified with 'for now', as a global opt-out, not a skip of only the current question. Do not schedule a later restart. Stop the questions and the other-bot scan at once. Keep any answers already given, add `{"rules": "Setup skipped by the user; ask for a preference only when a job needs it."}` to the answers JSON, and run the step 5 dry-run and write without asking again. Then run `status` and require DONE before saying the skip was saved; if `finish` reported an error, run `finish` again and tell the user plainly if it still fails.
7. Confirm a global opt-out in one short line and ask no replacement question. Later, ask only for what a job really needs; do not restart setup unless the user asks. Otherwise tell the user setup is done, then pick up whatever they asked for first.
8. Last, load `offer-weekday-family-digest`, then `offer-afternoon-pickup-check`, then `offer-kitchen-table-newspaper`, then `offer-weekend-preview`, then `offer-monthly-parent-note` and make each one-time offer (after a global opt-out too). Never create a routine without the user's explicit yes.

## Questions

- `name`: What should I call you?
- `timezone`: Which time zone are you in?
- `replies`: How do you like replies: short and to the point, or more detail?
- `household`: Who else is in the household: a spouse or partner, and anyone else who helps (grandparents, a sitter)?
- `kids`: Your kids' first names, ages and grades?
- `schools`: Which schools do they go to, and any teachers' names I should watch for?
- `activities`: Which activities do they have, and on which days?
- `pickup`: Who does pickup on each day, and at what time?
- `city`: Which city are you in? I use it for weather and local events.
- `bills`: Any recurring bills or renewals I should never let slip?
- `providers`: Doctors, dentists or other providers whose emails I should watch for?
- `digest_hour`: What time should the morning digest come? The default is 6:30 am.
- `newspaper_format`: For the kitchen table newspaper: Letter or A4, and color or black and white?
- `rules`: Any standing rules I must always follow (for example never delete files, ask before sending anything)?

## Where the questions came from

- User prefs, fill during getting started: timezone = unset, digest hour = 6:30am default, your name = unset, spouse or partner = unset, other caretakers = unset, kids (first name, age, grade) = unset, schools and teachers = unset, activities with days = unset, pickup owner and time by day = unset, city = unset, recurring bills to never miss = unset, providers = unset, what counts as matters = default, weekends = quiet, newspaper format = unset.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
