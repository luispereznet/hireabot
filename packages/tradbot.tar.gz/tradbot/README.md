# Tradbot

Watches your personal email and family schedule so school forms, bills, and RSVPs don't slip.

## Install and open

```bash
hermes profile import tradbot.tar.gz && hermes -p tradbot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `tradbot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p tradbot setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Watches your personal email and family schedule so school forms, bills and RSVPs don't slip. It drafts the reply, catches the pickup clash, and never sends anything without you.

- **Family calendar briefs:** the week or two ahead, collisions, who drives, and what to prepare.
- **Kitchen table newspaper:** a printable one-page paper kids can read at breakfast: schedule on top, weather, family news and a little real news.
- **Monthly parent note:** real local events for the month plus age-matched notes for each child.
- **Works without connections:** forward, paste or screenshot your week. Gmail makes it faster, and the optional Google Calendar add-on lets it read your calendar directly.
- **Optional routines:** a weekday digest, an afternoon pickup check, the daily newspaper, a Friday weekend preview and the monthly note. Each is offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p tradbot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p tradbot`.

## Setup

- No integration is required: use the original pasted, forwarded, screenshot or public-web input paths; disclose unavailable tools.
- Google Calendar is the separately installed optional tradbot-google-calendar.zip add-on. No add-on files, skills or Google Calendar MCP requirement are bundled. Install it separately only if wanted, then follow its own Google sign-in setup.
- gmail: leave GMAIL_MCP_URL blank unless wanted. Select and verify a compatible remote MCP server, authentication, account scope and least-privilege tools first; then fill the local variable from .env.EXAMPLE and enable only with consent. No working endpoint or OAuth support is asserted.
- slack: leave SLACK_MCP_URL blank unless wanted. Select and verify a compatible remote MCP server, authentication, account scope and least-privilege tools first; then fill the local variable from .env.EXAMPLE and enable only with consent. No working endpoint or OAuth support is asserted.
- notion-workspace: leave NOTION_WORKSPACE_MCP_URL blank unless wanted. Select and verify a compatible remote MCP server, authentication, account scope and least-privilege tools first; then fill the local variable from .env.EXAMPLE and enable only with consent. No working endpoint or OAuth support is asserted.
- All routine definitions ship paused with no next run. Review the original suggested schedule and recipient timezone in its offer skill; enable the same ID only after yes. Local delivery saves results here and sends no message.
- The original PDF workflow requires an available renderer and its locked fonts; missing tools or fonts must be explained, not claimed installed.
