# Customer Call Coach & Assistant

Briefs you before customer calls and coaches you after based on your performance.

## Install and open

```bash
hermes profile import customer-call-coach-assistant.tar.gz
hermes -p customer-call-coach-assistant setup
hermes -p customer-call-coach-assistant
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `customer-call-coach-assistant` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Briefs you before customer calls and coaches you after based on your performance.

- **Optional friday Coach Refresh:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p customer-call-coach-assistant chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p customer-call-coach-assistant`.

## Setup

- Import, run native AI setup and open as shown above. Domain questions are skippable; no original-owner role, time zone or preferences included.
- Optional integrations: fill desired blank *_MCP_URL variables locally using a recipient-verified compatible endpoint, complete supported OAuth/local authentication, test read access, then explicitly enable that server. Sampling remains disabled. See skills/customer-call-coach-assistant/references/integrations.md.
- All routines ship paused/local. Suggested clock times are inactive placeholders: confirm time zone, scheduler clock/DST, source scope and cadence before explicit enable. External sends/posts/purchases/bookings require separate exact approval.
