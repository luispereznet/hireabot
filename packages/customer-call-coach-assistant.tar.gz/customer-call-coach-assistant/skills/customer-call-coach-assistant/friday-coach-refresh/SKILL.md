---
name: friday-coach-refresh
description: "Use when refresh friday coaching signals."
version: 1.0.0
---

# Refresh Friday coaching signals

Inputs: Approved source scope, prior local checkpoint, new meetings and Slack.

1. Confirm user-enabled routine or explicit one-off request. Read only approved sources since the checkpoint and retain stable source IDs. On connector failure report locally, never claim success.
2. Extract evidence-backed recurring presence, storytelling, enablement and deployment-ownership signals using `post-call-coaching`. No sales scorecards or peer comparisons unless requested.
3. Merge dated summaries and source IDs into workspace/coaching-signals.md under the active profile, backing up replacements. Keep recipient history local, not in shipped MEMORY.md. Advance the checkpoint only for successfully processed sources and deduplicate retries.
4. On routine success remain quiet: no Slack/email or unsolicited report. Return a trend summary only on request. A connector failure produces a local notice.

Output: Quiet local signal update/checkpoint, or local connector-failure notice.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
