---
name: offer-friday-coach-refresh
description: "Use after setup or when asked about routines: offer friday Coach Refresh."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "customer-call-coach-assistant"}}
---

# Offer Friday Coach Refresh

Inputs: Completed/skipped setup, local choice record, scheduler and allowed sources.

1. Offer once after completed or skipped setup. Resolve active profile from ancestor containing skills/ and SOUL.md. Read workspace/routine-choice-offer-friday-coach-refresh.md. A declined/enabled/offered record suppresses repeat offers unless requested. Record offered before asking; unclear answers leave inactive, not declined.
2. Explain: Friday afternoon; data-only quiet sync, local alert only if connector fails. Shipped job c3cf3bb88634 is paused. Ask yes/no to enable; setup completion is not consent. Explicit no records declined; no clear yes means no scheduler change.
3. After yes confirm zone, desired time and source scope, one question at a time. Suggested clock expression 0 16 * * 5 is an inactive placeholder until reviewed against scheduler clock/DST. Verify dependencies before enabling.
4. With available native scheduler inspect ID c3cf3bb88634 and matching name. Resume matching paused job after updating approved schedule; create only if absent using `friday-coach-refresh` and local delivery. Refuse duplicates. Missing scheduler means disclose limitation, never pretend success.
5. Read back exact ID, schedule, state and next run. Save enabled only after verification. Explain how to request pause/change. Enabling never authorizes external messages or shared-record edits.

Output: Recorded one-time offer choice, or verified enabled local job and schedule.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. No cross-profile reads; unresolved zone/access blocks enabling.


## Consent and schedule (required)

Ask for an explicit yes before enabling this routine. Confirm the user's time zone
(IANA) and local hour. The shipped job stays paused until that yes. On yes, update
the paused definition to the agreed schedule and resume it; if the shipped record
is missing, use `cron create` with `--deliver local` only after listing existing
jobs. A decline, or no clear yes, leaves it paused. Never treat silence as consent.
