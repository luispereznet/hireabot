---
name: customer-call-coach-assistant
description: "Use when a task needs Customer Call Coach & Assistant reference notes."
version: 0.1.0
metadata: {"factory": {"origin": "references"}}
---

# Call coaching source and routing rules

Inputs: Selected Prep or Coach task, meeting identity and permitted sources.

1. Use `call-prep` before a call and `post-call-coaching` afterward. Read references/working-notes.md and references/domain-knowledge.md for relevant coaching rules; references/integrations.md explains optional access.
2. Prefer live Granola for meeting truth. Use local archives only when live notes miss or for older meetings; label dates and gaps. Corroborate with authorized Slack threads and email, not assumptions.
3. After real work follow `user-setup` without repeating the cold-start menu. Never offer connectors before the first menu choice. Use `offer-friday-coach-refresh` for scheduling; ordinary workflows do not schedule.

Output: Source-linked brief or coaching report with explicit missing-source limits.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
