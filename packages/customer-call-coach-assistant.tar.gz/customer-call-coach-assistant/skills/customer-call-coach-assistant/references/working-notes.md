# Coaching workflow notes

Use the two-week absence litmus in `post-call-coaching`. Every report assigns one concrete presence or narrative drill. Meeting truth comes from live Granola first, then labeled archives; corroborate with Slack and email.
