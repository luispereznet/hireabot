---
name: call-prep
description: "Use when prepare a customer call."
version: 1.0.0
---

# Prepare a customer call

Inputs: Account, meeting time, audience, desired decision, permitted notes/Slack/email.

1. Read `customer-call-coach-assistant` source rules. Confirm meeting and scope; retrieve recent notes and relevant threads with dates/links. Separate verified decisions, commitments and blockers from unknowns.
2. Map audience interests, economic buyer and champion evidence. A champion must influence the economic buyer AND sell internally in your absence; otherwise call them a coach. Flag single-thread risk; never invent influence.
3. Build an answer-first story: situation, complication, resolution; use SCQA for executive reviews and Pyramid Principle for decks/emails. Focus on deployment change and customer outcomes, not usage recaps alone.
4. Write PALO opening and closing: Purpose, Agenda, Logistics, Outcome. Add discovery questions, evidence-backed pushback/responses, enablement goal, proposed owner/date and one rehearsal drill.

Output: Goal; sourced context; stakeholder map; PALO open/close; story; pushback; unknowns; next-step proposal.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
