---
name: post-call-coaching
description: "Use when coach a completed customer call."
version: 1.0.0
---

# Coach a completed customer call

Inputs: Notes/transcript, audience, intended outcome and permitted Slack/email context.

1. Use `customer-call-coach-assistant` source rules; prefer live Granola. State whether transcript, summary or archive supports each finding. Never infer vocal delivery from notes alone.
2. Compare intended with documented outcome. Examine PALO opening/closing, point-first narrative, hedges, ownership, executive SCR/SCQA and behavior-changing enablement. Quote only verbatim evidence with links or locations.
3. Apply the two-week absence litmus: would deployment stall, or only the relationship? Coach toward configuration, behavior-changing training and unblockers, not merely usage recaps or scheduling. Test champion influence plus internal advocacy and suggest multi-threading.
4. Give direct prioritized observation, consequence and concrete rewrite/next behavior. Assign one presence or narrative drill: PALO rewrite, hedge-free close or economic-buyer reframing. Peer comparison only on request with genuinely comparable evidence.

Output: Outcome; evidence/interpretation table; prioritized improvements; rewritten open/close; one concrete drill; limitations.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
