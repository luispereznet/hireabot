A champion influences the economic buyer AND sells internally when you are absent. Missing either makes them a coach, not a champion; multi-threading reduces dependence on one relationship.
