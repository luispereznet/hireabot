# AI Search Visibility

Checks whether AI assistants and Google recommend you, and who they name instead.

## Install and open

```bash
hermes profile import ai-search-visibility.tar.gz && hermes -p ai-search-visibility
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `ai-search-visibility` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p ai-search-visibility setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Checks whether AI assistants and Google recommend you, and who they name instead. Starts from a handful of questions your buyers actually ask.

- **Build the prompt list**
- **Run a visibility check**
- **Capture a pasted answer**
- **Weekly visibility brief**
- **Citation source audit**
- **Share of answer comparison**
- **Draft the fix**
- **Optional weekly visibility brief:** offered once after setup. It is only enabled if you say yes.
- **Optional top prompt spot check:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p ai-search-visibility chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p ai-search-visibility`.

## Setup

- Configure your own model/provider locally if needed. No credentials, account, user preferences or working history are bundled.
- All six optional MCP connections ship disabled and sampling disabled. Notion uses official OAuth at https://mcp.notion.com/mcp; authorize notion-workspace with your own account using the installed Hermes MCP login workflow, then enable only after verifying workspace scope.
- Slack, Linear, Hex, Profound and Google Sheets have no verified transport supplied. Fill their optional *_MCP_URL environment placeholders locally only with an endpoint you trust, verify authentication and exposed tools, and enable deliberately. A placeholder is not a functioning service; no package or unofficial URL is invented. Keep secrets out of chat and the distribution.
- Use the ai-search-visibility integration workflow for channel/page/issue/chart/spreadsheet target validation, preview, explicit write approval and exact readback. Profound remains read-only; use user-supplied exports when tools are unavailable. Local work needs none of these integrations.
- Two shipped jobs are PAUSED: weekly full-list brief (Monday 09:00 host-clock example), top-five spot check (Tuesday/Thursday 09:00 host-clock example). Confirm your own days, time, IANA timezone/DST, scope, available surfaces and future model cost before either matching offer skill resumes the existing job. Do not create duplicates or use cron run as a preview. Output is local; external delivery is separately approved.
- User setup remains skippable. Existing offer/site/audience/locale/rival/surface and schedule preference questions are retained. Getting started performs requested work first. Seed memory contains neutral taxonomy only; working artifacts belong in this active profile workspace.
