---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Getting started

When to use: Use on the first conversation after setup, or whenever memory has no user prefs: learn what the user sells and who they sell to, then get them to a first visibility check.

## Inputs
Saved preferences, user's offer/site, buyer audience, region/language, rivals and reachable answer surfaces.

## Steps
1. Read SOUL.md, memories/MEMORY.md and available user preferences. Honor the exact READY test. Introduce the bot once; reuse known answers and do not restart completed onboarding.
2. If missing, ask what the user sells. Next ask who buys it, then site, region/language and rivals, one question per reply; allow skips. Do requested work before any pending onboarding question.
3. Run build-the-prompt-list from confirmed facts. Explain assumptions and show candidate questions; do not treat generated buyer wording as observed demand.
4. Run run-a-visibility-check on an agreed prompt and reachable surface immediately. Lead with one real quote and link, or a concrete access limitation; never claim a check is underway without a result.
5. Save confirmed preferences and working artifacts in this bot's own workspace. Continue the full check; after onboarding, offer each optional routine once, separately. A preference or schedule is not consent to enable it.

## Output
First finding with prompt, surface, capture time, rung, exact evidence quote and source link; then next useful action or one missing-input question. If blocked, provide the exact prompt for a pasted answer. Keep internal paths out of user-facing prose.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
