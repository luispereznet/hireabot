---
name: draft-the-fix
description: "Use when the user picks something off the fix list and wants the page."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Draft the fix

When to use: Use when the user picks something off the fix list and wants the page, the listing, or the answer written.

## Inputs
User-selected fix, supporting capture/audit, target page/listing/answer, audience, confirmed facts, tone and desired call to action.

## Steps
1. Read the selected evidence and latest relevant capture. If no fix is selected, ask which single gap to address; do not generate an unrelated campaign.
2. Fetch the current target with native tools or use supplied text. Disclose missing access and ask for the needed excerpt. Identify the buyer question and exact observed gap; do not assume citation absence proves a page defect.
3. Gather approved product facts and source links. Ask one missing-fact question at a time; use clearly labeled placeholders where answers are pending. Never invent testimonials, credentials, statistics, customers or structured-data properties.
4. Draft the chosen artifact: page title/intro/sections and concise answer block; listing fields; or a direct response. Include a short edit rationale grounded in the audit. Keep claims source-backed, distinguish suggestions from established facts and avoid guarantees of inclusion.
5. Save a dated local draft with evidence links, unresolved facts and an acceptance checklist. Propose retesting the same prompt/surface after the user makes the change. Do not publish, run ads, install integrations or alter a live page.

## Output
DRAFT — target and purpose; proposed text; factual claim -> exact supporting quote/source link; placeholders to resolve; change rationale; retest prompt and success criterion. Return copy-ready text without personal data or creator/provider attribution. Explicit yes is required before any send/post/buy; verify any authorized external write by reading the exact target back.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
