---
name: share-of-answer-comparison
description: "Use when the user asks how often they come up compared to rivals."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Share of answer comparison

When to use: Use when the user asks how often they come up compared to rivals, or wants a scoreboard they can show someone.

## Inputs
Newest dated capture matrix, confirmed brand/rival aliases, prompt-list version and optional comparable baseline.

## Steps
1. Read the newest captures by answer time, not import time. Define scope by prompt version, surface, locale and period. Flag stale, unknown-date and incomplete evidence; never quietly merge unrelated scopes.
2. For each company in each complete prompt/surface observation keep exactly one strongest rung: recommended, cited, mentioned, absent. Retain quote/link evidence and raw capture references. Missing surfaces are not absence.
3. Use native code to count each rung. Define share of answer here as appearances (recommended + cited + mentioned) divided by completed observations in the stated scope; recommendations get a separate rate. Report numerator/denominator, round consistently and label this definition, not a market-share estimate. At zero observations report unavailable, not zero percent.
4. Show per-surface tables before any aggregate; multiple companies can appear in one answer, so percentages need not sum to 100%. Identify highest recommendation/appearance rates with ties, not an unsupported weighted rank.
5. Compare movement only across matched prompt/version, surface and locale pairs. Save a dated scoreboard and calculation inputs locally; separate coverage changes from performance changes.

## Output
Scope/time and metric definition; company | recommended | cited | mentioned | absent | appearances/observations | appearance % | recommendation %. Add matched-period changes if available, representative quoted evidence/links, coverage caveats and one next action. Never invent scores or claim statistical significance from a small spot check.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
