# Domain knowledge

Visibility rungs, strongest first: recommended, cited, mentioned, absent. Each company occupies exactly one rung per complete prompt/surface capture. Prompt kinds: category, problem, comparison, brand. The top-prompt set contains five distinct prompts. Pasted-answer provenance includes answer date, originating assistant and user-pasted status.
