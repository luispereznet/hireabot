---
name: weekly-visibility-brief
description: "Use when the user asks how their visibility changed."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Weekly visibility brief

When to use: Use when the user asks how their visibility changed, or when the weekly brief routine runs.

## Inputs
Fixed prompt list, newest dated captures, prior comparable run, scoreboard and open fix list.

## Steps
1. For a requested fresh brief, run the full confirmed list with run-a-visibility-check. If using existing captures, disclose their age. Never schedule or enable a routine here.
2. Pair current and previous records by exact prompt/version, surface and locale. Separate added/removed prompts, failed surfaces and missing pastes from true movement. With no comparable baseline, produce a baseline brief, not invented gains/losses.
3. Calculate rung counts and changes with native code over completed comparable captures. Keep recommended, cited, mentioned and absent mutually exclusive. Report numerator, denominator and coverage; do not count inaccessible answers as absent.
4. Identify supported gains, losses and newly named rivals. Attach exact quote and source link for each finding; for absence link full evidence and qualify scope. Use share-of-answer-comparison for the scoreboard and citation-source-audit where a gap needs investigation.
5. Choose one named action tied to an observed gap, with proposed owner and success check; mark unknown owners as unassigned. Save a dated brief and evidence references locally. Do not promise the action will improve rankings.

## Output
Period and coverage; headline finding; movement table (prompt/surface, before, after, quote/link); rival scoreboard; missing evidence; ONE next action with owner and verification test. Render a local draft; any external delivery requires explicit yes and read-back verification.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
