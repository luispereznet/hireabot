---
name: ai-search-visibility
description: "Use when routing visibility work, storage or optional integrations."
version: 1.0.0
---

# AI search visibility operations

When to use: Route visibility work, manage local artifacts or use an explicitly authorized optional integration.

## Inputs
Confirmed offer, site, audience, locale, rivals, approved prompt-list version, accessible surfaces and any authorized external target.

## Workflow and storage
1. Resolve <active-profile> from this loaded skill's ancestor containing skills/ and SOUL.md. Read only this profile's memories/USER.md and relevant workspace records. Missing files mean no saved history. Read references/domain-knowledge.md for neutral vocabulary if MEMORY.md is unavailable.
2. Working state lives in files, not in memory. Use workspace/visibility/prompt-list.json as the versioned source of truth: stable prompt ID, exact text, kind, locale, top/active flags and version. Use dated append-only captures under captures/ with run ID, answer timestamp, import timestamp, prompt/version, surface, locale, raw answer, citations, completeness and provenance. Keep scored company/rung/quote/link rows tied to the raw capture. Never overwrite prior runs.
3. Keep spot-check logs, dated briefs and audits, scoreboards and calculation inputs, fix lists and dated drafts in separate files under workspace/visibility/. Back up records before replacement. Comparisons use the newest actual answer timestamp with a matching prompt/version/surface/locale baseline; unknown dates cannot establish movement. No preference or working record belongs in public seed memory.
4. Use getting-started then build-the-prompt-list and run-a-visibility-check. Use capture-a-pasted-answer for unavailable logins, weekly-visibility-brief for movement, citation-source-audit for source gaps, share-of-answer-comparison for counted metrics, and draft-the-fix for user-selected actions. Never invent evidence or count unavailable surfaces as absent.

## Optional integrations
1. All six MCP declarations ship disabled with sampling disabled. A declaration is not a working service. The recipient must verify their endpoint, auth method, available tools and target scope before enabling any connection. Do not install packages or request secrets in chat. The Notion declaration uses its official OAuth endpoint; the other transports are recipient-supplied environment URL placeholders, not claimed official services.
2. Slack: draft the weekly brief locally, identify the exact approved channel and preview the complete message. Only on explicit send approval use the connected posting tool. Read back the exact channel/message and keep its confirmed link; an API success without readback is not verified delivery.
3. Notion: on explicit authorization inspect the chosen workspace/database schema. Keep prompt lists, briefs and fix lists with stable local IDs and evidence links; preview creates or updates and get approval. Read the exact page/record back and retain its ID. Never copy another team's data.
4. Linear: preview selected fix issue title, evidence, proposed owner and acceptance/retest criteria in the authorized team/project. Check for an existing matching issue; get approval before creation or update. Read the issue back and save the verified ID/link. Do not turn every suggestion into an issue automatically.
5. Hex: use only a verified existing workspace connection. Read approved scoreboard inputs, show scope and metric definitions, draft a chart/table proposal, and obtain approval before any remote write or execution. No paid queries. Read back any authorized saved artifact and verify its values against local calculations; otherwise report an unverified draft.
6. Profound: read visibility/citation exports only through verified authorized read tools or user-supplied exports. Preserve engine, exact prompt, locale, timestamp, raw quote, citation and provider provenance; use the ordinary capture workflow. Missing metadata is incomplete, not absence. Do not purchase runs or call a paid API.
7. Google Sheets: inspect the approved spreadsheet/tab and columns. Read or export requested data only within scope. Preview explicit cell/range updates with prompt/capture IDs and metrics, obtain approval, then read back exactly those ranges and compare values. Never overwrite unknown rows or formulas.
8. Unavailable integrations do not block local work: use local prompt lists, briefs, fix lists, scoreboards and user-pasted captures/exports. Describe missing access without inventing a connector. External delivery remains separately consented even if a routine is enabled; jobs always save locally.

## Output
Supported result or BLOCKED with missing access, artifact provenance, exact external target/readback where authorized, and one next action. Scheduler changes belong only to offer-* skills; no duplicate jobs, deletion, publishing, installs or paid calls.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
