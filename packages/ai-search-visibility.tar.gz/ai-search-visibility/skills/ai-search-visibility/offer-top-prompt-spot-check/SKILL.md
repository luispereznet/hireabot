---
name: offer-top-prompt-spot-check
description: "Use after setup or when asked about routines: offer top prompt spot check."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "ai-search-visibility"}}
---

# Offer the top prompt spot check

This optional definition ships PAUSED with stable ID 029d0e42c33f. It cannot run until explicitly resumed; never create a duplicate.

What it does: Twice a week, re-runs the top five prompts and speaks up only when the user drops out of an answer or a new name shows up.

## When to offer
Offer once after first-chat setup or on request. Read workspace/routine-choice-top-prompt-spot-check.md in the active profile; a declined or resumed choice suppresses repeat offers unless the user asks. No clear yes means leave paused, record the choice and stop. Ask one question at a time.

## On explicit consent
1. Resolve the active profile from this skill's ancestor containing SOUL.md and skills/. For an installed named profile, use its actual folder name with `hermes -p <actual-profile-name>` and set HERMES_HOME to its containing Hermes root. Never assume the default home or import name. If outside a named installation, report BLOCKED rather than target a different profile.
2. Verify confirmed prompt list, brand/rivals, locale, accessible surfaces and saved preferences. For a spot check require exactly five distinct agreed top prompts. Missing access means BLOCKED; offer pasted captures rather than inventing results. Explain future model usage/cost, local-only output and the saved schedule `0 9 * * 2,4`. Weekly means once a week; spot check means twice a week, not daily.
3. Ask for intended days, time and IANA timezone; inspect the host timezone with an available tool. The shipped cron uses host clock and is an inactive example, not the user's schedule. Explain DST implications. Resume only when the approved local schedule matches the saved expression. If it does not, leave paused and request a separately approved schedule edit using the available native scheduler interface; read back exact expression/timezone before resuming. Do not invent update syntax, create a replacement or use cron run as a preview.
4. List real definitions with `hermes -p <actual-profile-name> cron list`. Match stable ID 029d0e42c33f, bot-prefixed name, scope and schedule. Check for equivalent duplicate watches; if missing, ambiguous or mismatched, stop for approved repair. Never create another job.
5. After explicit approval and completed prerequisites, run `hermes -p <actual-profile-name> cron resume 029d0e42c33f`. List again and verify this exact ID is enabled/scheduled with the agreed expression and timezone before claiming success. Any failed readback is unverified, not success.
6. On explicit pause/cancel run `hermes -p <actual-profile-name> cron pause 029d0e42c33f`, list again and require disabled/paused state. Pause rather than delete. Record consent, ID, actual schedule/timezone and verified state in workspace/routine-choice-top-prompt-spot-check.md. Do not remove user records.

## Output
Verified paused/resumed state, exact job ID, agreed days/time/timezone, local destination, scope and missing prerequisites. Remote Slack or other delivery requires separate explicit approval and target readback, never implicit routine consent. Never run actual checks as a scheduler preview, install services or make paid calls.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
