---
name: citation-source-audit
description: "Use when the user asks why they are not showing up."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Citation source audit

When to use: Use when the user asks why they are not showing up, or which sites and pages the answers are pulling from.

## Inputs
Newest complete captures, their citation URLs, user's site and the specific visibility gap or question.

## Steps
1. Read the newest capture set and identify prompt/surface scope. Ask one question if the target gap is unclear; do not infer why an assistant chose a source.
2. Extract actual cited URLs and answer sentences, keeping prompt IDs and provenance. Deduplicate URLs for source counts in code while retaining each citation occurrence. Separate observed citations from uncited mentions.
3. Fetch reachable cited pages and relevant user pages with native web/browser. Record retrieval time, title, URL and exact supporting passage. Mark inaccessible, changed or missing sources rather than inventing their contents.
4. Classify sources as user-owned, rival-owned or third-party based on evidence. Note factual coverage, clarity and source gaps relevant to the buyer prompt. Do not diff competitor prices/products, run ads or claim access to hidden ranking signals.
5. Distinguish observations from hypotheses: answer cited X; page states Y; proposed explanation Z is unproven. Prioritize a concrete fix with evidence and a retest prompt. Save a dated audit locally and offer draft-the-fix.

## Output
Scope and coverage; source table: prompt/surface | cited URL | ownership | answer quote | page quote | retrieved at/status. Then observed gaps, explicitly labeled hypotheses, and prioritized fix with retest. Every factual finding has a quote/link; no fabricated traffic, authority scores or causal guarantees.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
