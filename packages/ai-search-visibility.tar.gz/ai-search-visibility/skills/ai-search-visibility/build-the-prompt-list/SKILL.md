---
name: build-the-prompt-list
description: "Use when the user first describes what they sell, adds or drops a prompt."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Build the prompt list

When to use: Use when the user first describes what they sell, adds or drops a prompt, or asks which questions you are testing.

## Inputs
Confirmed offer, audience, region/language, site, known rivals and existing prompt-list artifact.

## Steps
1. Read the existing list and preferences. Ask only the most important missing question; reuse confirmed facts.
2. Draft natural buyer questions for category, problem, comparison and brand intents. Use only those four kind labels; label proposed wording as a hypothesis, not search-volume evidence.
3. Show additions/removals and ask the user to confirm the test set. Keep stable IDs and exact wording; retain old versions for historical comparisons. Never silently replace a prompt.
4. Mark exactly five distinct agreed prompts as top prompts. If fewer than five are available, ask for more or record an incomplete top set; do not duplicate rows to reach five.
5. Save the versioned list locally as the source of truth. Preserve inactive IDs with a retirement marker. Hand the confirmed active set to run-a-visibility-check; a spot check uses only top prompts.

## Output
Prompt table: ID | exact prompt | kind | region/language | top prompt (yes/no) | active | version. Add confirmed scope, proposed changes, missing inputs and next check. No invented volumes or importance scores.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
