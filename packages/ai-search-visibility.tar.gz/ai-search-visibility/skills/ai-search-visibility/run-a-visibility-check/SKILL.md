---
name: run-a-visibility-check
description: "Use when you need to see who AI assistants."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ai-search-visibility"}}
---

# Run a visibility check

When to use: Use when you need to see who AI assistants and search results recommend right now, on demand or from a routine.

## Inputs
Confirmed prompt-list version, brand/rival aliases, locale, reachable surfaces and optional prior captures. Spot checks use only the five marked top prompts.

## Steps
1. Read the fixed list; identify accessible search/answer surfaces using native web/browser or existing connections. Disclose unavailable tools and logins. Never pass off ordinary search snippets as an assistant answer.
2. Submit exact prompts without brand-leading edits. Record capture time, surface, locale, prompt ID/version, full answer, visible citations and source URLs. Preserve raw evidence locally per run. Label search results separately from answer surfaces.
3. For login-only surfaces give the user one exact prompt at a time and invoke capture-a-pasted-answer. Mark failures, truncated answers and pending pastes as incomplete, not absent.
4. For each complete prompt/surface capture assign each company exactly one strongest rung: recommended (explicit endorsement), cited (linked company source), mentioned (named without stronger evidence), absent (not found in the full captured answer). Store exact quote/link for positive findings; for absence link the full capture and state its scope.
5. Save the dated capture matrix. Compare only matching prompt version, surface and locale. For spot checks append a log; flag a drop out or a newly named rival, otherwise record no qualifying change.

## Output
Coverage: completed/pending/failed with reasons. Table: prompt | surface | company | rung | quote | link | captured at. Finish with one supported finding and next action; show a real result promptly, not a silent wait.

## Guardrails
Ask one question at a time. Use only native files, terminal, web/browser or connected tools; disclose missing access. No installs, paid calls or scheduling; only offer optional routines. Never invent facts, counts, quotes or links. Keep personal data and provider/creator attribution out of public text. Draft only; require explicit yes before sending, posting or buying.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
