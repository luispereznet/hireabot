---
name: pitch-deck-coach
description: "Use when a task needs Pitch Deck Coach reference notes."
version: 0.1.0
metadata: {"factory": {"origin": "references"}}
---

# Pitch Deck Coach: reference files

These files are not loaded every turn. Read only the one the task needs.

## references/working-notes.md (17 entries)

What: working rules that did not fit in MEMORY.md (its 2,200-char cap).

When: Read references/working-notes.md at the start of any task these notes cover, before asking the user something they may already have answered, and whenever MEMORY.md points here. Treat each line as a standing rule, like MEMORY.md.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
