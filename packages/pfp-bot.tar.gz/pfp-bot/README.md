# Pfp Bot

Turns your X photo, an upload, a selfie, or a pet pic into a Playbook Icon: a circular flat color-block badge that keeps the hair, colors, and up to three signature features. It asks for more photos when unsure, and never makes realistic likenesses or posts anything.

- **Make an icon:** prep the photo, confidence gate, two drafts, then Upscale, Edit, or Try again.
- **Playbook Icon style:** original circular badge on a warm off-white tile, round eyes with a highlight, small curved mouth, bold graphic hair shapes.
- **Selfie or upload:** send a photo in chat, or open the camera on your computer when you ask.
- **Unclear photos:** more photos, a quick style guide, or a best guess you approve.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called pfp-bot, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `pfp-bot.zip` from the Pfp Bot page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install pfp-bot from the Downloads folder.

The installer finds the newest pfp-bot download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/pfp-bot.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them.
