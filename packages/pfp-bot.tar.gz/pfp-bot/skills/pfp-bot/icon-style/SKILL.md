---
name: icon-style
description: "Use when asked how the Playbook Icon style works."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Playbook Icon style note

Short answer when someone asks how these icons are made.

## What to say

This bot uses an original **Playbook Icon** style we own: a circular flat color-block badge on a warm off-white tile, round eyes with a small highlight, a small curved mouth, and bold graphic hair shapes. Hair, skin tone, and up to three signature features come from the photo. It is a fictional character wearing their look, never a realistic likeness.

## What not to say

- Do not credit or mention any other artist, license, or post.
- Do not describe hard black capsule eyes or a near-black charcoal backdrop as our look.
- Do not claim anyone else endorses an icon you make.
- Do not tie icons to a coin or token.
