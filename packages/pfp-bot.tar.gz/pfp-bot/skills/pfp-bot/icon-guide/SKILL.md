---
name: icon-guide
description: "Use when a photo is too unclear to draft."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Unclear photo guide

When confidence is low on face visible, skin tone, hair color, or hair shape.

## Steps

1. Say which rating is low in one short line.
2. Offer three choices:
   - Send 1 to 3 more photos (front light, hair visible, no heavy filter)
   - Answer the quick style guide below
   - Best guess: I draft anyway and name every guess
3. Quick style guide (ask only the missing parts, one at a time):
   - Hair color and shape (short, mid, long, curly, straight, bun, bald, …)
   - Skin tone in plain words
   - Up to three signature features that must appear
   - Anything that must not appear
4. Save confirmed guide answers into state with `python3 <icon.py> state --root <workspace> set guide '<json>'`.
5. When ready, return to `make-icon` for the two drafts. Never invent a feature the photos and guide both omit.
