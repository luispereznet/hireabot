#!/usr/bin/env python3
"""icon.py — Playbook Icon helper for the pfp-bot Hermes package.

Keeps local state and files inside one profile workspace (--root). Readable
on purpose: other skills call these commands instead of retyping logic.

Commands:
  init --root DIR
  prep --root DIR (--photo PATH | --handle NAME) [--label LABEL]
  stage-draft --root DIR --src PATH --label a|b
  state --root DIR get [KEY]
  state --root DIR set KEY VALUE
  export --root DIR --src PATH [--sizes 1024,400,2048] [--out-dir DIR]
  --help

state.json keys (examples): handle, source, assets[], drafts{}, guide, tweaks,
loved, confidence{}.
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path

DEFAULT_SIZES = (1024, 400, 2048)
STATE_NAME = "state.json"


def die(msg: str, code: int = 2) -> None:
    print(msg, file=sys.stderr)
    raise SystemExit(code)


def root_dir(raw: str) -> Path:
    p = Path(raw).expanduser().resolve()
    if not p.exists():
        p.mkdir(parents=True, exist_ok=True)
    if not p.is_dir():
        die(f"--root is not a directory: {p}")
    return p


def ensure_layout(root: Path) -> None:
    for name in ("assets", "drafts", "archive", "scripts"):
        (root / name).mkdir(parents=True, exist_ok=True)


def state_path(root: Path) -> Path:
    return root / STATE_NAME


def load_state(root: Path) -> dict:
    sp = state_path(root)
    if not sp.is_file():
        return {
            "version": 1,
            "handle": None,
            "source": None,
            "assets": [],
            "drafts": {},
            "guide": None,
            "tweaks": [],
            "loved": None,
            "confidence": {},
            "updated_at": None,
        }
    try:
        data = json.loads(sp.read_text())
    except json.JSONDecodeError as e:
        die(f"state.json is not valid JSON: {e}")
    if not isinstance(data, dict):
        die("state.json must be a JSON object")
    return data


def save_state(root: Path, data: dict) -> None:
    data = dict(data)
    data["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    sp = state_path(root)
    if sp.is_file():
        stamp = time.strftime("%Y%m%d-%H%M%S")
        archive = root / "archive" / f"state-{stamp}.json"
        archive.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(sp, archive)
    sp.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def stamp_name(prefix: str, src: Path) -> str:
    ts = time.strftime("%Y%m%d-%H%M%S")
    suffix = src.suffix.lower() or ".png"
    safe = "".join(c if c.isalnum() or c in "-_" else "-" for c in prefix)[:40]
    return f"{safe}-{ts}{suffix}"


def cmd_init(root: Path) -> int:
    ensure_layout(root)
    if not state_path(root).is_file():
        save_state(root, load_state(root))
        print(f"initialized {state_path(root)}")
    else:
        print(f"already present {state_path(root)}")
    print(f"layout ready under {root}")
    return 0


def cmd_prep(root: Path, photo: str | None, handle: str | None, label: str) -> int:
    ensure_layout(root)
    st = load_state(root)
    if handle:
        st["handle"] = handle.lstrip("@")
        st["source"] = "handle"
        save_state(root, st)
        print(json.dumps({"ok": True, "source": "handle", "handle": st["handle"],
                          "note": "Fetch the public profile photo next, then re-run prep --photo <path>."},
                         indent=2))
        return 0
    if not photo:
        die("prep needs --photo PATH or --handle NAME")
    src = Path(photo).expanduser().resolve()
    if not src.is_file():
        die(f"photo not found: {src}")
    dest = root / "assets" / stamp_name(label or "photo", src)
    shutil.copy2(src, dest)
    st["source"] = "photo"
    assets = list(st.get("assets") or [])
    assets.append(str(dest))
    st["assets"] = assets[-20:]
    save_state(root, st)
    print(json.dumps({"ok": True, "asset": str(dest), "assets_kept": len(st["assets"])}, indent=2))
    return 0


def cmd_stage_draft(root: Path, src: str, label: str) -> int:
    ensure_layout(root)
    path = Path(src).expanduser().resolve()
    if not path.is_file():
        die(f"draft not found: {path}")
    label = (label or "a").lower()
    dest = root / "drafts" / stamp_name(f"draft-{label}", path)
    shutil.copy2(path, dest)
    st = load_state(root)
    drafts = dict(st.get("drafts") or {})
    drafts[label] = str(dest)
    st["drafts"] = drafts
    save_state(root, st)
    print(json.dumps({"ok": True, "label": label, "draft": str(dest)}, indent=2))
    return 0


def cmd_state(root: Path, action: str, key: str | None, value: str | None) -> int:
    ensure_layout(root)
    st = load_state(root)
    if action == "get":
        if key:
            print(json.dumps(st.get(key), indent=2))
        else:
            print(json.dumps(st, indent=2, sort_keys=True))
        return 0
    if action != "set":
        die("state action must be get or set")
    if not key:
        die("state set needs KEY")
    if value is None:
        die("state set needs VALUE")
    # Try JSON decode so callers can pass objects/lists; else keep string.
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        parsed = value
    st[key] = parsed
    save_state(root, st)
    print(json.dumps({"ok": True, "key": key, "value": parsed}, indent=2))
    return 0


def _resize(src: Path, dest: Path, size: int) -> None:
    try:
        from PIL import Image  # type: ignore
    except ImportError:
        # Fallback: copy original when Pillow is missing. Caller still gets a file.
        shutil.copy2(src, dest)
        print(f"warn: Pillow missing, copied original for {size}px -> {dest}", file=sys.stderr)
        return
    im = Image.open(src).convert("RGBA")
    im = im.resize((size, size), Image.Resampling.LANCZOS)
    dest.parent.mkdir(parents=True, exist_ok=True)
    # Preserve PNG when possible.
    if dest.suffix.lower() in {".jpg", ".jpeg"}:
        im.convert("RGB").save(dest, quality=95)
    else:
        im.save(dest)


def cmd_export(root: Path, src: str, sizes_raw: str, out_dir: str | None) -> int:
    ensure_layout(root)
    path = Path(src).expanduser().resolve()
    if not path.is_file():
        die(f"export source not found: {path}")
    try:
        sizes = [int(x.strip()) for x in sizes_raw.split(",") if x.strip()]
    except ValueError:
        die(f"bad --sizes value: {sizes_raw}")
    if not sizes:
        sizes = list(DEFAULT_SIZES)
    out = Path(out_dir).expanduser().resolve() if out_dir else (root / "drafts")
    out.mkdir(parents=True, exist_ok=True)
    stem = path.stem
    written = []
    for size in sizes:
        dest = out / f"{stem}-{size}.png"
        if dest.exists():
            stamp = time.strftime("%Y%m%d-%H%M%S")
            archived = root / "archive" / f"{dest.name}.{stamp}"
            archived.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dest, archived)
        _resize(path, dest, size)
        written.append(str(dest))
    st = load_state(root)
    st["loved"] = str(path)
    st["exports"] = written
    save_state(root, st)
    print(json.dumps({"ok": True, "exports": written}, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Playbook Icon helper for pfp-bot")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="create workspace folders and state.json")
    s.add_argument("--root", required=True)

    s = sub.add_parser("prep", help="stage a photo or record a handle")
    s.add_argument("--root", required=True)
    s.add_argument("--photo")
    s.add_argument("--handle")
    s.add_argument("--label", default="photo")

    s = sub.add_parser("stage-draft", help="copy a draft into drafts/ and record it")
    s.add_argument("--root", required=True)
    s.add_argument("--src", required=True)
    s.add_argument("--label", required=True)

    s = sub.add_parser("state", help="read or write state.json")
    s.add_argument("--root", required=True)
    s.add_argument("action", choices=["get", "set"])
    s.add_argument("key", nargs="?")
    s.add_argument("value", nargs="?")

    s = sub.add_parser("export", help="write sized PNG exports")
    s.add_argument("--root", required=True)
    s.add_argument("--src", required=True)
    s.add_argument("--sizes", default="1024,400,2048")
    s.add_argument("--out-dir")

    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    root = root_dir(args.root)
    if args.cmd == "init":
        return cmd_init(root)
    if args.cmd == "prep":
        return cmd_prep(root, args.photo, args.handle, args.label)
    if args.cmd == "stage-draft":
        return cmd_stage_draft(root, args.src, args.label)
    if args.cmd == "state":
        return cmd_state(root, args.action, args.key, args.value)
    if args.cmd == "export":
        return cmd_export(root, args.src, args.sizes, args.out_dir)
    die(f"unknown command: {args.cmd}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
