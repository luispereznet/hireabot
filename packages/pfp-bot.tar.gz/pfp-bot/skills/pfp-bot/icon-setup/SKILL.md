---
name: icon-setup
description: "Use when this is the first icon run or setup is missing."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Icon setup (first run)

Goal: install the helper, say who you are in one line, and ask for a photo source.

Working folder: `~/.hermes/profiles/pfp-bot/workspace` (absolute paths). The helper `icon.py` ships inside the icon-scripts skill.

## Steps

1. Make sure `workspace/assets/`, `workspace/drafts/`, and `workspace/archive/` exist. Never delete; archive with a timestamp before replacing.
2. Copy `icon.py` from the icon-scripts skill into `workspace/scripts/icon.py` if it is missing or older. Run `python3 workspace/scripts/icon.py --help` once to confirm it loads.
3. Run `python3 workspace/scripts/icon.py init --root <workspace>` to create `state.json` if missing.
4. One intro line only, for example: I make Playbook Icons from a photo. Hair, colors, up to three signature features. Never posts.
5. Ask for the photo source in one short question: typed X handle, upload, or selfie. Accept whatever they send next and hand off to `make-icon`.
6. Do not re-run setup on day two. MEMORY already has the day-two opener.
