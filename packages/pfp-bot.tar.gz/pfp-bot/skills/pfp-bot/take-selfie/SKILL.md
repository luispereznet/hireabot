---
name: take-selfie
description: "Use when the user wants a selfie for their icon."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Take a selfie

Gets a selfie for the next icon.

## Steps

1. Prefer a selfie sent in chat from any phone. Say: send a selfie here and I will use it.
2. If they ask to use a computer camera, open or point them to the camera app on their machine, then have them drop the saved photo into chat or a path you can read.
3. Once the photo arrives, run `make-icon` with `icon.py prep --photo <path>`.
4. Same safety rules: no children, no strangers, no public figures. Photos stay in this bot's folder.
