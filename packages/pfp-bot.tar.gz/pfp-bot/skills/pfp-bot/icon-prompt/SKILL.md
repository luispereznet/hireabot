---
name: icon-prompt
description: "Use when writing the Playbook Icon drawing prompt."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Playbook Icon drawing prompt

This skill defines our original **Playbook Icon** style. Use it for every draft. Do not borrow looks from other icon products.

## Style name

Playbook Icon

## Must-keep visual rules

- Circular badge on a warm off-white tile `#f7f4ee` with a thin inner ring
- Flat color-block character, not photoreal
- Round eyes (circles with a small highlight), never hard black capsule slits
- A small curved mouth is allowed
- Hair as 2 to 5 bold graphic shapes matching the photo's hair color and silhouette
- Skin tone sampled from the photo
- Up to 3 signature features only if the photo shows them (glasses, earrings, hat, freckles, facial hair, and similar)
- Never copy face structure, expression, or eye shape from the photo (fictional character wearing their look)
- No near-black charcoal backdrop
- No tilted close-up trademark framing from other styles
- Default master size: 1024 px square

## Prompt skeleton (fill the brackets)

```
Playbook Icon avatar, circular badge on warm off-white #f7f4ee tile with a thin inner ring,
flat color-block character (not photoreal), round eyes with a small highlight, small curved mouth,
hair as [2-5] bold graphic shapes in [hair color] matching silhouette [short|mid|long|curly|straight|bun|...],
skin tone [sampled description], signature features only if shown: [up to 3],
centered head-and-shoulders, friendly simple shapes, clean edges, no text, no watermark
```

## Must-keep behavior rules

- Keep hair color, hair silhouette, and skin tone from the photo
- Cap signature features at three, and only ones the photo shows
- Name medium-confidence guesses in the reply line
- Refuse realistic portrait wording ("photograph", "likeness", "exact face")

## Edge cases

- Glasses: one simple frame shape, not mirrored lenses full of detail
- Hats or headwraps: keep silhouette, flatten logos to solid shapes
- Strong side lighting: still use flat local color, not painted shadows
- Multiple people in frame: ask which person, do not invent a blend

## Pet mode

Only when the user owns the pet. Same circular badge and flat color-block rules. Round eyes with a highlight, small curved mouth when it fits the species. Fur or feathers as 2 to 5 bold shapes. No realistic fur rendering. Cap signature features at three (collar color, ear notch, spot pattern).

## Two drafts

Vary only one axis between draft A and B (hair shape emphasis, or which optional accessory is included). Keep Playbook Icon rules identical in both.
