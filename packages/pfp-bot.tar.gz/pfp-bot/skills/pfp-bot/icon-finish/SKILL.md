---
name: icon-finish
description: "Use when the user picks Upscale, Edit, or Try again."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Finish an icon

After the previews: upscale, edit one thing, or try again.

Helper: `workspace/scripts/icon.py`.

## Upscale

1. Take the picked draft.
2. Run `python3 <icon.py> export --root <workspace> --src <draft> --sizes 2048,400,1024`.
3. Send the 2048 px master and the 400 px size in one short reply. Keep the 1024 px master in `drafts/` as well.
4. Update `state.json` with the loved draft path via `python3 <icon.py> state --root <workspace> set loved <path>`.

## Edit

1. Ask for exactly one change (example: shorter hair, drop the glasses, warmer skin).
2. Rebuild one prompt from `icon-prompt` starting from the picked draft's notes in state.
3. Call the runtime's image tool once. Stage with `stage-draft`.
4. Show the new preview and name what changed in one line. Offer Upscale, Edit, or Try again again.

## Try again

1. Build two fresh prompts (different axis than the last pair).
2. Call the runtime's image tool twice in parallel.
3. Stage both drafts and show small previews again.

## Stop rules

- Never post the icon. Never change a profile or avatar unless the user clearly asks for that separate action and you confirm.
- Two weak rounds in a row: offer `icon-guide` (more photos or the quick style guide) instead of guessing harder.
