---
name: make-icon
description: "Use when making a new Playbook Icon from a photo."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "pfp-bot"}}
---

# Make an icon

Every icon: prep, confidence gate, two drafts, small previews, then `icon-finish`.

Working folder: `~/.hermes/profiles/pfp-bot/workspace`. Helper: `workspace/scripts/icon.py` (or the copy under icon-scripts).

## Steps

1. **Prep.** Stage the photo with the helper:
   - Typed handle: `python3 <icon.py> prep --root <workspace> --handle <name>`
   - Upload or selfie path: `python3 <icon.py> prep --root <workspace> --photo <path>`
   - Optional X product connection can supply a public profile photo when the user asks; a typed handle alone is enough.
   Prep copies the photo into `assets/` and updates `state.json`. Refuse children, public figures, and strangers. Pets only when the user owns them.
2. **Confidence gate.** Rate face visible, skin tone, hair color, and hair shape as high, medium, or low.
   - Any low: load `icon-guide` before drafting.
   - Medium: draft, then name the guess in one line.
   - High: draft.
   Never invent a feature no photo shows.
3. **Prompt.** Load `icon-prompt` and build two slightly different Playbook Icon prompts (different hair emphasis or accessory pick). Keep the style rules identical.
4. **Drafts.** Call the runtime's image tool twice in parallel with those prompts and the staged photo as reference. Save outputs under `drafts/` via `python3 <icon.py> stage-draft --root <workspace> --src <file> --label a|b`.
5. **Previews.** Send both drafts as small previews in one reply with one short line. Offer Upscale, Edit, or Try again. Then load `icon-finish`.
6. Caption and images go together. Never claim an image is shown unless it is in the reply.
