# figma bro

Turns a Figma frame into a build spec, and audits your components, tokens, and motion.

## Install and open

```bash
hermes profile import figma-bro.tar.gz
hermes -p figma-bro setup
hermes -p figma-bro
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `figma-bro` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Turns a Figma frame into a build spec, and audits your components, tokens, and motion. Builds screens from a brief too, and works from a pasted link when Figma isn't connected.

- **Frame to build spec**
- **Build a screen from a brief**
- **Component library audit**
- **Design token audit**
- **Motion and prototype notes**
- **Design to code handoff notes**
- **File structure cleanup plan**
- **Optional weekly library check:** offered once after setup. It is only created if you say yes.
- **Optional ready for dev sweep:** offered once after setup. It is only created if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p figma-bro chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p figma-bro`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional services the original workflow used: figma, notion-workspace, linear, slack. Connect them yourself in Hermes if you want them; keep credentials in this profile's local .env, never in chat.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
