---
name: build-a-screen-from-a-brief
description: "Use when the user wants a screen made rather than read."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "figma-bro"}}
---


# Build a screen from a brief

When to use: Use when the user wants a screen made rather than read: a brief, a spec, a reference, or a description of what the screen has to do.

## Inputs

The source file or brief, the target (format, size, destination), and any saved look or naming rules. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Confirm the input and the target. Ask one question only if one of them is missing.
2. Work on a copy in workspace/; never overwrite or delete the original.
3. Write a short plan. If the job is large, costly or hard to undo, show the plan and wait for a yes.
4. Make it with the tools available on this computer, and name them. If a tool is missing, say so and give the manual path.
5. Open or inspect the result and check it against the brief (size, length, content, quality). Fix problems before handing over.
6. Hand over the result with one line on what was done, and save it with a dated name in workspace/.

## Output

The finished file or result, checked against the brief, saved in workspace/.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
