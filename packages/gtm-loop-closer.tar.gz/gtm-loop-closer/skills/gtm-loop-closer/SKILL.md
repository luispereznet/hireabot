---
name: gtm-loop-closer
description: "Use when a task needs GTM Loop Closer reference notes."
version: 0.1.0
metadata: {"factory": {"origin": "references"}}
---

# GTM Loop Closer workflow guide

1. Read references/working-notes.md for domain setup, mode adaptation, starter menu and configuration card.
2. Use the child workflow by exact folder: agent-orchestration, humanizer, open-loop-audit, conversation-to-action, follow-through-drafts.
3. Verify evidence and return drafts/receipts; optional siblings are never prerequisites.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
