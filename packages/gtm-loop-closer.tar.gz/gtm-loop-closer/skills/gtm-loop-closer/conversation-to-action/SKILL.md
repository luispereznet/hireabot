---
name: conversation-to-action
description: "Use when turn a meeting, thread."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-loop-closer"}}
---

# conversation-to-action

When to use: Turn a meeting, thread, or note into assigned actions and approval-ready updates.

Inputs: transcript/thread/notes, participants, timestamps, approved account/deal and destination mappings.
1. Read ../references/working-notes.md. Separate explicit promises, decisions, questions and customer facts with quoted evidence and time/message anchors.
2. Capture actor, deliverable, owner, due date, dependency and destination for each action. Keep suggestions separate from commitments; unknown dates/owners remain Unknown.
3. Check approved task/CRM/thread destinations before proposing creation. Deduplicate by source plus action and surface conflicts rather than merging silently.
4. Draft assigned tasks, replies, CRM field patches or workspace notes. Show current/proposed values, target IDs and evidence; route closure copy to follow-through-drafts. Ask only the next blocking question.
5. Present exact approval bundles. Apply only approved actions with available tools; read each target back. If tools are missing, return copyable drafts and disclose the limitation. A draft is not a completed action.
Output: evidence-linked action table, decisions, unknowns, approval-ready updates and receipts separating proposed, approved, applied, verified and failed changes.

Guardrails: Ask one question at a time. Never invent facts, numbers, evidence, access or commitments. Disclose missing tools/connections; offer paste, CSV, exports, URLs or files. Require explicit yes to the exact action before send/post/buy or system writes. Read back changed targets. No ordinary workflow enables routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
