---
name: agent-orchestration
description: "Use when coordinate a persistent pinned specialist."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-loop-closer"}}
---

# agent-orchestration

When to use: Coordinate a persistent pinned specialist, scoped subagents, adaptive armies, renameable folders, and auditable synthesis.

Inputs: requested outcome, approved sources, permissions, saved config and destination.
1. Read ../references/working-notes.md. Confirm only job-critical gaps. Offer pinning only for durable/collaborative work; a pinned specialist owns synthesis and approvals, not extra access.
2. Show mode and named lanes: Single for dependent work; Adaptive 2-3 workers for independent lanes; 4-8 only for deep separable research within approved limits. Honor ask-before-delegation preferences. If unavailable, run lanes sequentially and disclose it.
3. Give each worker exact source scope, deliverable and stop conditions. Workers may read scoped data and draft only: no sends, writes, folders, connections, routines or permission expansion.
4. Require receipts with source IDs/URLs, timestamps, findings, conflicts and unknowns. Parent deduplicates and resolves conflicts visibly; check material claims against evidence.
5. Offer existing folders or renameable Strategy/Research/Execution/Operations for plans/evidence/drafts/receipts. Explain jobs; confirm each creation/move/write. Save semantic labels separately from permissions; worker/group names change presentation only.
Output: Result, Evidence, Unknowns, Drafts, Decisions needed, Execution receipt, including mode and lane receipts. Optional sibling handoffs carry scope and sources; finish locally if absent.

Guardrails: Ask one question at a time. Never invent facts, numbers, evidence, access or commitments. Disclose missing tools/connections; offer paste, CSV, exports, URLs or files. Require explicit yes to the exact action before send/post/buy or system writes. Read back changed targets. No ordinary workflow enables routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
