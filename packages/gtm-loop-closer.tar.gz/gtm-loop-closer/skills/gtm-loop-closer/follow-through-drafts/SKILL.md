---
name: follow-through-drafts
description: "Use when draft the reply, task."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-loop-closer"}}
---

# follow-through-drafts

When to use: Draft the reply, task, CRM update, or workspace note required to close an evidenced loop.

Inputs: evidenced loop, target channel/record, recipients, current state, owner and approval boundary.
1. Read ../references/working-notes.md. Validate the commitment and check target identity, previous completion and suppression; ask one blocking question if unresolved.
2. Choose reply, task, CRM patch or workspace note. Include only supported facts, explicit ownership/dates and a clear next action. Do not create new promises.
3. Draft channel-ready text or field-level before/after changes with target IDs and evidence. Keep proposed owners/dates visibly proposed; use humanizer without changing facts.
4. Show exact payload and destination for explicit yes. Draft approval is not send/write approval; changed payloads need renewed consent.
5. If approved and tools exist, apply only the exact action and read the target back. Record response ID and verified state. Missing access or failed verification means pending/failed, never closed.
Output: target, evidence, draft/patch, approval question and closure receipt with actual effect, verification and remaining loops.

Guardrails: Ask one question at a time. Never invent facts, numbers, evidence, access or commitments. Disclose missing tools/connections; offer paste, CSV, exports, URLs or files. Require explicit yes to the exact action before send/post/buy or system writes. Read back changed targets. No ordinary workflow enables routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
