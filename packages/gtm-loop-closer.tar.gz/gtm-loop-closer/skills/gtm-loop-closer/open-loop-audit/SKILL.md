---
name: open-loop-audit
description: "Use when find explicit commitments."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-loop-closer"}}
---

# open-loop-audit

When to use: Find explicit commitments and information that lack a completed destination or owner.

Inputs: approved source/time window, source-of-truth map, ownership/dedupe rules and meeting/thread/CRM/task evidence.
1. Read ../references/working-notes.md. Retrieve scoped records or supplied exports; record IDs/URLs, timestamps, freshness and coverage gaps.
2. Extract explicit commitments and actionable customer facts with quoted evidence, actor, requested destination, owner and due date. Unknown owner/date stays Unknown; suggestions are not promises.
3. Check approved destinations for completed tasks, sent replies, CRM fields or workspace updates. Match record/thread IDs and action, not text similarity alone. Partial search coverage cannot prove absence.
4. Deduplicate across systems; show conflicting states with timestamps. Apply the approved primary-source/conflict rule or ask before choosing. Label open, blocked, closed and unverified separately.
5. Rank by evidenced deadlines and customer impact, not fabricated scores. Use follow-through-drafts for closure artifacts; distinguish owner proposals from confirmed ownership.
Output: open-loop queue with evidence, freshness, destination checked, state, confirmed/proposed owner, due date, next action and decision needed; include closure receipts and coverage limits.

Guardrails: Ask one question at a time. Never invent facts, numbers, evidence, access or commitments. Disclose missing tools/connections; offer paste, CSV, exports, URLs or files. Require explicit yes to the exact action before send/post/buy or system writes. Read back changed targets. No ordinary workflow enables routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
