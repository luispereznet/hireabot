# GTM Loop Closer

Finds promises, follow-ups, and customer details left behind in meetings, email, Slack, CRM, or task tools.

## Install and open

```bash
hermes profile import gtm-loop-closer.tar.gz
hermes -p gtm-loop-closer setup
hermes -p gtm-loop-closer
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `gtm-loop-closer` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Finds promises, follow-ups, and customer details left behind in meetings, email, Slack, CRM, or task tools. Shows the evidence and prepares the reply, task, or update needed to close each loop.

- **Agent orchestration**
- **Humanizer**
- **Open loop audit**
- **Conversation to action**
- **Follow through drafts**
- **Optional commitment-strand audit:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p gtm-loop-closer chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p gtm-loop-closer`.

## Setup

- All listed MCP adapters are optional, disabled and sampling disabled. No endpoint or account access is assumed. Fill only a trusted recipient-selected remote MCP URL in the corresponding blank .env.EXAMPLE variable; configure authentication locally per service instructions, then explicitly approve enabling the needed adapter. Never share tokens.
- Adapters: salesforce, gmail, google-calendar, slack, granola, notion, google-sheets. Use available connected tools or paste, CSV, exports, files and URLs if unavailable. This package installs no plugins.
- Confirm least-privilege read/draft/write scope, source of truth, actual fields, freshness/dedupe/conflict rules and retention. Exact approval and read-back are required for writes.
- Included cron is paused; its expression is only a placeholder. Use offer-commitment-strand-audit to confirm timezone/cadence, scope, private destination, empty-result behavior and approval policy before explicit enablement.
