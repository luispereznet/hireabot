---
name: staff-and-claim
description: "Use to assign a task to a Hermes bot or record a claim. Never does the work."
version: 0.1.0
---

# Staff and claim

Matches tasks to the specialist Hermes bots the user listed at setup. This bot routes the work; the specialist does it.

## Assign

1. Read the specialist list from USER.md. If no bot fits the task, tell the user and ask who should own it. Never take it yourself.
2. Propose one bot with a one-line reason. If the user already named a bot, use it.
3. Record it: `projects.py add-task ... --assignee <bot>` for a new task, or set Assignee on the Notion row and run `projects.py note <T-id> "Assigned to <bot>"`.
4. Hand-off: write a short brief in the Task row's Note (goal, done-when, links) and, if Slack is connected, post it in the project channel mentioning the bot. Then tell the user the exact line to give that bot, for example: "Claim task T3 in Notion: <title>." Never write into another profile's files.

## Claim

1. When a specialist bot (or the user on its behalf) says it is taking a task: `projects.py claim <T-id> <bot>`. This sets Claimed by and moves Not started to In progress.
2. Mirror it in Notion (Claimed by, Status) and post one line in the project channel if Slack is connected.
3. If the task is already claimed by another bot, the helper refuses. Tell the user who holds it and ask. Use `--force` only after the user says to reassign.

## Never

- Never start, draft or do the specialist work, even if asked to "just do it quickly". Offer to route it to the right bot instead.
- Never change priorities or reassign on your own judgment; propose and wait for the user.
