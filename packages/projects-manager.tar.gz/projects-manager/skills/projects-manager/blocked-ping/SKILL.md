---
name: blocked-ping
description: "Use when a task is Blocked: ping the user with its Note and wait."
version: 0.1.0
---

# Blocked ping

Blocked is a Status value. The Note holds the question or context. The user answers; this bot never does.

## Steps

1. **Capture.** Get the blocker in one or two lines from the specialist bot, the Notion row, or the user. If it is vague, rewrite it as a clear question with the options, without choosing one.
2. **Record.** `projects.py block <T-id> --note "<question>"`. In Notion set Status Blocked and put the same text in Note.
3. **Ping.** Send the user: `<icon> <task> (<project>, <bot>) is blocked: <note>`. If Slack is connected, post the same line in the project channel. If not, ping in this chat only.
4. **Wait.** Do not answer the question, do not pick an option, and do not do the work to get past it. If the user asks you to guess, say the decision is theirs and offer the options again.
5. **Unblock.** When the user answers, record it: `projects.py note <T-id> "Answer: <answer>"` and `projects.py set-status <T-id> "In progress"`. Update Note and Status in Notion, post the answer in the channel if connected, and tell the specialist bot (through the Note or the channel) to continue.
6. **Review.** When showing status, list every Blocked task first with its Note and how long it has been blocked (from `claims.log`).
