#!/usr/bin/env python3
"""Local project and task list for Projects Manager. Built-in Python only.

State lives in <profile>/workspace/projects-manager/ (or --home DIR):
  state.json    active projects and tasks
  claims.log    one JSON line per claim, block, note, status change, archive
  archive/      archived records, moved out of state.json (never deleted)
  defaults.json optional icon defaults {"project_icon": "...", "task_icon": "..."}

It never calls Notion or Slack and holds no tokens. The bot syncs this list
with the user's own Notion (and Slack, if connected) through Hermes.
"""
import argparse, json, os, sys, time
from pathlib import Path

STATUSES = ["Not started", "In progress", "Blocked", "Done"]


def home_dir(arg):
    if arg:
        return Path(arg).expanduser()
    env = os.environ.get("PROJECTS_MANAGER_HOME")
    if env:
        return Path(env).expanduser()
    # .../<profile>/skills/projects-manager/project-scripts/scripts/projects.py
    return Path(__file__).resolve().parents[4] / "workspace" / "projects-manager"


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S%z")


class Store:
    def __init__(self, home):
        self.home = home
        self.home.mkdir(parents=True, exist_ok=True)
        (self.home / "archive").mkdir(exist_ok=True)
        self.path = self.home / "state.json"
        if self.path.exists():
            self.data = json.loads(self.path.read_text())
        else:
            self.data = {"projects": {}, "tasks": {}, "next": 1}

    def defaults(self):
        p = self.home / "defaults.json"
        return json.loads(p.read_text()) if p.exists() else {}

    def save(self):
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, indent=2, ensure_ascii=False))
        os.replace(tmp, self.path)

    def log(self, event, **kw):
        kw.update(event=event, at=now())
        with open(self.home / "claims.log", "a") as f:
            f.write(json.dumps(kw, ensure_ascii=False) + "\n")

    def new_id(self, prefix):
        n = self.data["next"]
        self.data["next"] = n + 1
        return f"{prefix}{n}"

    def find(self, rid):
        for kind in ("projects", "tasks"):
            if rid in self.data[kind]:
                return kind, self.data[kind][rid]
        sys.exit(f"ERROR: no active record {rid}")


def need_icon(icon, store, key):
    icon = icon or store.defaults().get(key)
    if not icon:
        sys.exit("ERROR: every project and task needs a page icon: pass --icon or set defaults.json")
    return icon


def cmd_status(s, a):
    projects, tasks = s.data["projects"], s.data["tasks"]
    if a.json:
        print(json.dumps(s.data, indent=2, ensure_ascii=False)); return
    if not projects:
        print("No active projects."); return
    for pid, p in projects.items():
        if a.project and pid != a.project:
            continue
        ch = f"  #{p['channel']}" if p.get("channel") else "  (no channel)"
        print(f"{p['icon']} {pid} {p['title']} [{p['status']}]{ch}")
        for tid, t in tasks.items():
            if t["project"] != pid:
                continue
            who = t.get("claimed_by") or t.get("assignee") or "unassigned"
            flag = "  BLOCKED: " + (t.get("note") or "(no note)") if t["status"] == "Blocked" else ""
            print(f"   {t['icon']} {tid} {t['title']} [{t['status']}] {who}{flag}")
    blocked = [t for t in tasks.values() if t["status"] == "Blocked"]
    print(f"\n{len(projects)} projects, {len(tasks)} tasks, {len(blocked)} blocked")


def cmd_add_project(s, a):
    pid = s.new_id("P")
    s.data["projects"][pid] = {"id": pid, "title": a.title, "icon": need_icon(a.icon, s, "project_icon"),
                               "status": "In progress", "owner": a.owner or "", "channel": a.channel or "",
                               "notion_id": a.notion_id or "", "note": "", "created": now()}
    s.save(); s.log("add-project", id=pid, title=a.title)
    print(f"OK project {pid}")


def cmd_add_task(s, a):
    if a.project not in s.data["projects"]:
        sys.exit(f"ERROR: no active project {a.project}")
    tid = s.new_id("T")
    s.data["tasks"][tid] = {"id": tid, "project": a.project, "title": a.title,
                            "icon": need_icon(a.icon, s, "task_icon"), "status": "Not started",
                            "assignee": a.assignee or "", "claimed_by": "", "note": "", "blocked": False,
                            "notion_id": a.notion_id or "", "created": now()}
    s.save(); s.log("add-task", id=tid, project=a.project, title=a.title, assignee=a.assignee or "")
    print(f"OK task {tid}")


def cmd_claim(s, a):
    kind, t = s.find(a.task)
    if kind != "tasks":
        sys.exit("ERROR: only tasks can be claimed")
    if t.get("claimed_by") and t["claimed_by"] != a.bot and not a.force:
        sys.exit(f"ERROR: {a.task} already claimed by {t['claimed_by']} (use --force only on the user's say-so)")
    t["claimed_by"] = a.bot
    if t["status"] == "Not started":
        t["status"] = "In progress"
    s.save(); s.log("claim", id=a.task, bot=a.bot)
    print(f"OK {a.task} claimed by {a.bot}")


def cmd_block(s, a):
    kind, t = s.find(a.task)
    t["status"], t["blocked"], t["note"] = "Blocked", True, a.note
    s.save(); s.log("block", id=a.task, note=a.note)
    print(f"OK {a.task} Blocked. Ping the user with: {a.note}")


def cmd_note(s, a):
    kind, r = s.find(a.id)
    r["note"] = a.text
    s.save(); s.log("note", id=a.id, note=a.text)
    print(f"OK note on {a.id}")


def cmd_set_status(s, a):
    kind, r = s.find(a.id)
    r["status"] = a.status
    if kind == "tasks":
        r["blocked"] = a.status == "Blocked"
    s.save(); s.log("set-status", id=a.id, status=a.status)
    print(f"OK {a.id} {a.status}")


def cmd_link(s, a):
    kind, r = s.find(a.id)
    if a.notion_id:
        r["notion_id"] = a.notion_id
    if a.channel is not None and kind == "projects":
        r["channel"] = a.channel
    s.save(); s.log("link", id=a.id, notion_id=a.notion_id or "", channel=a.channel or "")
    print(f"OK linked {a.id}")


def cmd_archive(s, a):
    kind, r = s.find(a.id)
    moved = [(kind, a.id, r)]
    if kind == "projects":
        moved += [("tasks", tid, t) for tid, t in s.data["tasks"].items() if t["project"] == a.id]
    stamp = time.strftime("%Y%m%d-%H%M%S")
    out = s.home / "archive" / f"{a.id}-{stamp}.json"
    out.write_text(json.dumps([{"kind": k, **rec, "archived": now()} for k, _, rec in moved], indent=2, ensure_ascii=False))
    for k, rid, _ in moved:
        s.data[k].pop(rid)
    s.save(); s.log("archive", id=a.id, moved=[rid for _, rid, _ in moved], file=out.name)
    print(f"OK archived {len(moved)} record(s) to archive/{out.name}")


def cmd_delete(s, a):
    sys.exit("REFUSED: project records are never deleted. Use: archive <id>")


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--home", help="state folder (default: <profile>/workspace/projects-manager)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("status"); p.add_argument("--project"); p.add_argument("--json", action="store_true")
    p = sub.add_parser("add-project"); p.add_argument("title"); p.add_argument("--icon"); p.add_argument("--owner")
    p.add_argument("--channel"); p.add_argument("--notion-id")
    p = sub.add_parser("add-task"); p.add_argument("project"); p.add_argument("title"); p.add_argument("--icon")
    p.add_argument("--assignee"); p.add_argument("--notion-id")
    p = sub.add_parser("claim"); p.add_argument("task"); p.add_argument("bot"); p.add_argument("--force", action="store_true")
    p = sub.add_parser("block"); p.add_argument("task"); p.add_argument("--note", required=True)
    p = sub.add_parser("note"); p.add_argument("id"); p.add_argument("text")
    p = sub.add_parser("set-status"); p.add_argument("id"); p.add_argument("status", choices=STATUSES)
    p = sub.add_parser("link"); p.add_argument("id"); p.add_argument("--notion-id"); p.add_argument("--channel")
    p = sub.add_parser("archive"); p.add_argument("id")
    p = sub.add_parser("delete"); p.add_argument("id")
    a = ap.parse_args()
    s = Store(home_dir(a.home))
    {"status": cmd_status, "add-project": cmd_add_project, "add-task": cmd_add_task, "claim": cmd_claim,
     "block": cmd_block, "note": cmd_note, "set-status": cmd_set_status, "link": cmd_link,
     "archive": cmd_archive, "delete": cmd_delete}[a.cmd](s, a)


if __name__ == "__main__":
    main()
