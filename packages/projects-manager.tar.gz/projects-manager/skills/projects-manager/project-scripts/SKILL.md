---
name: project-scripts
description: "Use to run the local project list helper (projects.py)."
version: 0.1.0
---

# Project scripts

`scripts/projects.py` keeps an offline copy of projects and tasks so the bot can show status without Notion and keep a claim log. Built-in Python only. It never calls Notion or Slack and holds no tokens; the bot syncs it with the user's connections (see `project-ops`).

State folder: `<profile>/workspace/projects-manager/` (override with `--home DIR` or `PROJECTS_MANAGER_HOME`).
- `state.json`: active projects and tasks (id, title, status, icon, assignee, claimed_by, note, blocked, notion_id, channel).
- `claims.log`: one JSON line per add, claim, block, note, status change, link and archive.
- `archive/`: archived records, moved out of state.json. Nothing is deleted.
- `defaults.json`: optional icon defaults.

## Commands

```bash
H="python3 <profile>/skills/projects-manager/project-scripts/scripts/projects.py"
$H status [--project P1] [--json]
$H add-project "Launch site" --icon "🚀" [--owner NAME] [--channel NAME] [--notion-id ID]
$H add-task P1 "Write copy" --icon "✍️" [--assignee writer-bot] [--notion-id ID]
$H claim T2 writer-bot [--force]
$H block T2 --note "Which tagline: A or B?"
$H note T2 "Answer: A"
$H set-status T2 "In progress"        # Not started | In progress | Blocked | Done
$H link T2 --notion-id ID             # or: link P1 --channel proj-launch
$H archive P1                          # moves P1 and its tasks to archive/
$H delete T2                           # always refused: archive instead
```

## Rules

- Every project and task needs an icon: pass `--icon` or set `defaults.json`, or the helper refuses.
- A claim by a second bot is refused unless the user said to reassign (`--force`).
- On any ERROR, tell the user what failed in one line and do not retry with different data.
