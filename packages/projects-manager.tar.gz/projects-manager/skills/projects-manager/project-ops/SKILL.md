---
name: project-ops
description: "Use to start a project, add tasks, change status, archive, or show status."
version: 0.1.0
---

# Project ops

Creates and tracks Project and Task rows. Every row has a page icon. Keep the user's Notion and the local list in step.

Helper: `python3 <profile>/skills/projects-manager/project-scripts/scripts/projects.py` (see `project-scripts`).

## New project

1. Confirm the title, the owner (the user unless they say otherwise) and the icon (default from `defaults.json`).
2. Local list: `projects.py add-project "<title>" --icon "<icon>" --owner "<owner>"`. Note the id (P1, P2, ...).
3. Notion (if connected): create one row in the Projects database with Name, page icon, Status In progress and Owner. Save the page id: `projects.py link <P-id> --notion-id <page-id>`.
4. Slack (if connected and the user wants channels): search for an existing channel with the naming rule; reuse it if found, otherwise create it. Save it: `projects.py link <P-id> --channel <name>`. Post a one-line kickoff. If Slack is not connected, say "No Slack channel: Slack isn't connected" and continue.

## New task

1. Ask for the title and, if not obvious, which specialist bot fits. Never write the task's content yourself.
2. Local list: `projects.py add-task <P-id> "<title>" --icon "<icon>" [--assignee <bot>]`.
3. Notion: create a Task row linked to the project, with page icon, Status Not started and Assignee. Link it: `projects.py link <T-id> --notion-id <page-id>`.
4. Hand staffing to `staff-and-claim`.

## Status and review

- Change status: `projects.py set-status <id> "<Not started|In progress|Blocked|Done>"`, then update the same Status in Notion. For Blocked, use `blocked-ping` instead.
- Show status: `projects.py status` (or `--project <P-id>`). If Notion is connected, read the rows first and fix any drift in the local list, saying what changed. Lead with blocked tasks.
- Fix a missing icon: if a Notion row has no page icon, add the default icon and say so.

## Archive, never delete

- When the user closes a project: `projects.py archive <P-id>` (moves the project and its tasks to `archive/`). In Notion, set Status Done and use Notion's archive, never delete. In Slack, archive the channel only if the user says yes.
- If asked to delete, say records are archived, not deleted, and offer the archive.
