---
name: project-setup
description: "Use to set up Notion, optional Slack, specialist bots and icons."
version: 0.1.0
---

# Project setup

Turns the user's answers into a working setup. Every step can be skipped; a skipped step means that part runs from the local list only.

## Steps

1. **Notion.** Check whether a Notion connection is available in this Hermes session (a Notion MCP server or Notion tools the user already added). If none is available, say: "Notion isn't connected in Hermes yet. Add your own Notion connection in Hermes, then ask me again. Until then I'll keep projects in my local list." Do not install anything.
2. **Projects database.** If the user named an existing database, read its properties. If they named a parent page and say yes, create two databases there:
   - **Projects**: Name (title), Status (select: Not started, In progress, Blocked, Done), Owner (text), Channel (text), Note (text).
   - **Tasks**: Name (title), Project (relation to Projects), Status (same four values), Assignee (text: a Hermes bot name), Claimed by (text), Note (text).
   If an existing database lacks Status with a Blocked value or a Note field, propose adding them and wait for a yes.
3. **Slack (optional).** If the user wants channels and a Slack connection is available, note their channel naming rule (default `proj-<short-name>`). If Slack is not connected, say channels are skipped and work from Notion only.
4. **Specialist bots.** Record the Hermes bot names the user listed (their profiles, usually under `~/.hermes/profiles/<name>/`) and what each one does. Only read a profile's folder name to confirm it exists, and only with the user's yes. Never write into another profile.
5. **Icons.** Write the defaults to `workspace/projects-manager/defaults.json`, for example `{"project_icon": "📁", "task_icon": "✅"}`. Use those two if the user skipped.
6. **Save.** Add one short line to `memories/USER.md` (or MEMORY.md for non-personal setup) with: Notion database names or IDs, Slack yes/no and naming rule, specialist list, icon defaults. Keep within the cap.
7. Confirm the setup in one line per item and say what is still missing.
