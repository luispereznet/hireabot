# Projects Manager

Runs your team's projects from your own Notion: one row per project, a Slack channel per project if you connect Slack, and tasks your specialist Hermes bots claim. You decide, agents execute, and it never does the specialist work itself.

- **Projects in Notion:** one Project row per project and one Task row per task, each with a page icon and a Status (Not started, In progress, Blocked, Done).
- **Optional Slack:** if you connect Slack in Hermes, it makes or reuses one channel per project and posts staffing and blocked updates there. Without Slack it works from Notion alone.
- **Staffing and claims:** assigns tasks to the specialist Hermes bots you list, or records which one claimed a task. It routes the work and never starts it itself.
- **Blocked pings:** when a task is Blocked, it sends you the question from the task's Note and waits for your answer. It never guesses.
- **Local status list:** keeps a small offline copy of projects, tasks and a claim log in its own workspace. Records are archived, never deleted.

## What you connect

- **Notion:** use whatever Notion connection you already have in Hermes (for example your own Notion MCP server). No extra plugin is needed or installed by this bot.
- **Slack (optional):** your own Slack connection in Hermes, if you want a channel per project.
- **Specialist bots:** the names of your other Hermes bots (profiles) that do the actual work.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called projects-manager, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `projects-manager.zip` from the Projects Manager page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install projects-manager from the Downloads folder.

The installer finds the newest projects-manager download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/projects-manager.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them.
