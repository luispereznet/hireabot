---
name: mine-a-batch-of-calls
description: "Use when the user hands over several transcripts."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "customer-proof-desk"}}
---


# Mine a batch of calls

When to use: Use when the user hands over several transcripts, a folder of notes, a call recorder export, or months of support threads at once, and wants the best stories found across all of them.

## Inputs

The question, scope and time window, the allowed sources, and the existing records in workspace/. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Pin the question, the scope and what a good answer looks like. Ask one question if the scope is unclear.
2. Search only allowed sources: the public web, files the user gave, and connected tools. Capture the link and date for every finding.
3. Prefer primary sources (their own words, pages and filings) over coverage, and coverage over inference. Label inference.
4. Rank or score with criteria the user can see, and dedupe against what is already in workspace/.
5. List what could not be read or verified.
6. Return a ranked table with evidence, save it in workspace/, and suggest one next step.

## Output

A ranked, sourced table with gaps listed, saved in workspace/.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
