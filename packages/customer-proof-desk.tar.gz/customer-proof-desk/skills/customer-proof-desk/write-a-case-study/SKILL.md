---
name: write-a-case-study
description: "Use when the user wants a full customer case study or success story written."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "customer-proof-desk"}}
---


# Write a case study

When to use: Use when the user wants a full customer case study or success story written from notes, a transcript, or what is already in the proof bank.

## Inputs

The person or audience, the purpose and the one ask, the source thread or record, and the user's saved voice or samples. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Name the audience, the purpose and the single ask. Ask one question only if one of them is missing and changes the draft.
2. Re-read the source thread, row or notes, and collect only facts that have a source the user can check.
3. Write in the user's saved voice (plain, specific and short if none is saved). One ask per message, no hype, no filler.
4. Check every claim, name, number and date against its source. Remove anything unsupported or mark it [need: ...].
5. Show the draft with a one-line note on what to verify, and log it as a draft in workspace/.
6. Send, post or schedule only on the user's explicit yes for that exact text and recipient, through a connected tool; then read it back and log it. Otherwise it stays a draft.

## Output

A ready-to-review draft with its sources, logged in workspace/; nothing sent without a yes.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
