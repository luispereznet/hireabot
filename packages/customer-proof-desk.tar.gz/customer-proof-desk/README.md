# Customer Proof Desk

Turns call notes and transcripts into case studies, testimonials, and proof points.

## Install and open

```bash
hermes profile import customer-proof-desk.tar.gz
hermes -p customer-proof-desk setup
hermes -p customer-proof-desk
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `customer-proof-desk` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Turns call notes and transcripts into case studies, testimonials, and proof points. Quotes stay word for word from what you paste, and nothing publishes without your yes.

- **Add sources to the proof bank**
- **Mine a batch of calls**
- **Write a case study**
- **Pull proof for a claim**
- **Testimonials and pull quotes**
- **Build a deal proof one-pager**
- **Get the customer's approval**
- **Check a draft against the bank**
- **Lay out the case study**
- **Run the case study pipeline**
- **Optional weekly proof roundup:** offered once after setup. It is only created if you say yes.
- **Optional monthly proof refresh:** offered once after setup. It is only created if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p customer-proof-desk chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p customer-proof-desk`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional services the original workflow used: notion-workspace, slack, linear, figma, hex, Gmail, Granola. Connect them yourself in Hermes if you want them; keep credentials in this profile's local .env, never in chat.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
