---
name: birthday-anniversary-load
description: "Use when load birthdays and anniversaries."
version: 1.0.0
---

# Load birthdays and anniversaries

Inputs: Allowed source list/calendar, consent scope, event type and recurrence policy.

1. Inspect names, month/day, event type, optional year and consent. Ask leap-day handling, visibility and reminders as needed. Never infer age, tenure or missing dates.
2. Normalize all-day dates in target calendar zone. Preview yearly recurrence, exclusive end date, reminders and privacy. Deduplicate by source ID plus event type/date against existing recurrence masters.
3. Show create/update/skip/error preview. Only after exact yes load approved rows and read back exact event IDs/recurrence. Keep a local source-event mapping. Report failures; never delete preexisting entries or invite attendees by default.

Output: Preview table or validated calendar-import data, duplicates/errors, and verified event-ID results after approval.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
