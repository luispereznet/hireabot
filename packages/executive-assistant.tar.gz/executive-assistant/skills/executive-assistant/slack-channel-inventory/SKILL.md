---
name: slack-channel-inventory
description: "Use when inventory slack channels."
version: 1.0.0
---

# Inventory Slack channels

Inputs: Workspace, allowed public/private channel scope and requested fields.

1. Confirm scope and list accessible channels. Paginate to exhaustion and retain cursor/count evidence; never claim whole-workspace completeness under permission or pagination limits.
2. Deduplicate by channel ID. Record name, purpose, topic, archived status and link; include membership/owners only if actually returned and authorized. Never join private channels to expand coverage.
3. Group by requested function; flag duplicate/stale descriptions as review candidates. List inaccessible/unqueried areas. Archive, invite or post only after exact approval and target readback.

Output: Scoped table or CSV, measured collected count, coverage limits and proposed actions.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
