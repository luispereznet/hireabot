---
name: leadership-outreach
description: "Use when reconcile leadership outreach."
version: 1.0.0
---

# Reconcile leadership outreach

Inputs: One executive, allowed Slack channel, range and Notion/sheet tracker.

1. Read requests in scope with message URLs, dates, targets and executive. Treat an EA ✅ reaction as sent evidence only when actor and meaning are confirmed; compare tracker and actual provided sent evidence.
2. Classify sent, outstanding or ambiguous per executive. Deduplicate by message/request ID. Never mark a draft sent; surface conflicting evidence.
3. Return newest-first outstanding requests, tracker diff and follow-up drafts. Only after exact yes update selected rows, add a selected reaction or send the reviewed message; read back each target. Recurrence uses `offer-weekly-leadership-outreach-check`.

Output: Source-linked sent/outstanding/ambiguous table, tracker diff and approval-ready follow-ups.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
