---
name: sheet-calendar-reconcile
description: "Use when reconcile sheets and calendars."
version: 1.0.0
---

# Reconcile sheets and calendars

Inputs: Sheet/tab and calendar IDs, range, zone, match fields and authoritative source.

1. Read bounded rows/events with stable IDs, timestamps and recurrence instances. Normalize zones/dates without changing originals. Ask which source wins if unstated.
2. Match stable request/event IDs first, title/time only as flagged candidates. Identify missing events/rows, time/attendee/room mismatches, duplicates and cancellation conflicts; show newest requests first.
3. Preview row/event before-after diffs with ambiguity, recurrence and DST risks. Never overwrite formulas or whole sheets. After exact approval apply selected changes and read back each target; report partial failures without blind retries.

Output: Matched/missing/conflicting table with scoped counts, source links, change diffs and verified results.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
