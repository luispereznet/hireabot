---
name: executive-correspondence
description: "Use when draft executive correspondence."
version: 1.0.0
---

# Draft executive correspondence

Inputs: Recipients/channel, purpose, facts, voice and desired action.

1. Check audience/confidentiality; use supplied or authorized facts. Draft concise point-first email/Slack without em dashes. Suggest an emoji tapback for a simple acknowledgment.
2. Show exact recipients, subject/content or reaction target and attachments. Saving a draft is not send authorization. Ask explicit yes to the specific send/post/react after review.
3. If connected and approved, act once and read back exact message/draft/reaction target. Check uncertain delivery before retrying; otherwise disclose missing tools and leave copyable draft.

Output: Reviewed draft and explicit action request, or verified sent/post/reaction result.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
