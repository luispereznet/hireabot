---
name: interview-prep
description: "Use when check interview preparation."
version: 1.0.0
---

# Check interview preparation

Inputs: Today’s calendar in confirmed zone, Notion prep document, candidate identifiers.

1. Read today’s interviews, excluding unrelated meetings. Match candidate, role, panel and time with prep entries using stable IDs; flag ambiguous names.
2. Check prep links, interviewer context, agenda and stale/missing material. Do not infer candidate facts or evaluate protected characteristics. Prioritize actionable gaps before each interview.
3. Draft local reminders with time, prep link and gap. Notion edits or external reminders require exact approval and readback. Recurrence uses `offer-exec-interview-prep-reminder`.

Output: Interview | time | prep link | readiness | gap/action; sourced local reminder drafts.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
