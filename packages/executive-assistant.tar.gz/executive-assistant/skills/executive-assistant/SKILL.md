---
name: executive-assistant
description: "Use when route executive support work."
version: 1.0.0
---

# Route executive support work

Inputs: Authorized executive, dates/zone and relevant calendars, sheets, channels/documents.

1. Choose `conference-room-rundown`, `interview-prep`, `leadership-outreach`, `slack-channel-inventory`, `sheet-calendar-reconcile`, `birthday-anniversary-load` or `executive-correspondence` by task. Confirm executive identity and scope; never inherit original-owner preferences.
2. Prefer connected Google Calendar/Gmail MCP over browser SSO. Verify access/dates and use supplied exports if unavailable. Keep request-sheet views newest-first. Read references/integrations.md for connection limits.
3. For reminders use the matching exact offer skill routed by `user-setup`; ordinary work does not schedule. Draft communication and change diffs; require explicit yes for exact external changes and read back afterward.

Output: Domain result with source links, unknowns and approval-required changes.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
