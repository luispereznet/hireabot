# Optional integrations

- Google Calendar: optional recipient-verified endpoint in GOOGLE_CALENDAR_MCP_URL. Complete service-supported OAuth or local secret handling, never credentials in chat. Verify least-privilege read access before enabling. Writes require separate exact approval.
- Gmail: optional recipient-verified endpoint in GMAIL_MCP_URL. Complete service-supported OAuth or local secret handling, never credentials in chat. Verify least-privilege read access before enabling. Writes require separate exact approval.
- Slack: optional recipient-verified endpoint in SLACK_MCP_URL. Complete service-supported OAuth or local secret handling, never credentials in chat. Verify least-privilege read access before enabling. Writes require separate exact approval.
- Notion: optional recipient-verified endpoint in NOTION_MCP_URL. Complete service-supported OAuth or local secret handling, never credentials in chat. Verify least-privilege read access before enabling. Writes require separate exact approval.
- Google Sheets: optional recipient-verified endpoint in GOOGLE_SHEETS_MCP_URL. Complete service-supported OAuth or local secret handling, never credentials in chat. Verify least-privilege read access before enabling. Writes require separate exact approval.

All servers and sampling ship disabled. Blank variables mean unavailable, not a working endpoint. Use supplied exports if no compatible server exists. No account access included.
