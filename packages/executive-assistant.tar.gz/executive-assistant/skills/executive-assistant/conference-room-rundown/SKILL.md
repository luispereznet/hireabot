---
name: conference-room-rundown
description: "Use when build conference-room rundowns."
version: 1.0.0
---

# Build conference-room rundowns

Inputs: Executive/calendar, day and zone, room IDs/floors/capacities, preferred-room-A/B.

1. For two-business-day checks advance two weekdays: Mon→Wed, Tue→Thu, Wed→Fri, Thu→Mon, Fri→Tue. Flag holidays unless a supplied business calendar defines them. Same-day checks use today in the confirmed zone and compare prior snapshots for overnight changes.
2. Check working location, all-day WFH, Home, travel, OOO or PTO first. If remote, return one local remote note and skip the chart; never post without explicit yes. Otherwise retrieve full-day events and resource availability including partial conflicts.
3. Cluster back-to-back meetings into one room. A new cluster may use another room after at least a one-hour break; never switch floors without a break. Prefer small rooms for small meetings, not large staff/forecast/leadership calls. Follow an already booked large call with a small room on the SAME floor. Ask room-versus-desk preference, never assume it.
4. Produce a chronological chart, bold meetings needing a room. Propose bookings without claiming success. After exact approval recheck conflicts, book only approved events/resources and read back. Report races/failures, never overwrite silently.

Output: Full-day markdown table: time | meeting | booked | preferred-room-A | preferred-room-B. Room cells: ✅ free / ❌ taken / ⚠️ partial; unavailable data explicitly unknown. Booking proposals and verified results.

Guardrails: Ask one question at a time. Never invent numbers, evidence or access. Disclose missing tools; use supplied material instead. Require explicit yes for the exact action before sending, posting or buying; read back approved external changes. 
