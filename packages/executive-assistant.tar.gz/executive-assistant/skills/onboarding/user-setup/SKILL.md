---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load` via the helper's `finish` step.


# Skippable first-chat setup

Helper: `python3 <this skill folder>/scripts/user_setup.py`. Inputs: questions.json and recipient answers.

1. If message is exactly "Reply only: READY", reply READY and nothing else. Do requested work first. Run helper `status`; DONE means no repeated questions.
2. If pending, ask questions from questions.json one at a time; each skippable. Never substitute inherited health/fundraising questions. Explicit skip-all ends questions and optional scan immediately.
3. Only after separate explicit yes may `scan-others --consent` read other bots’ USER.md; retain recipient-confirmed lines only, never write other profiles. No scan on skip-all.
4. Save answers JSON locally, adding rules="Setup skipped by the user; ask for a preference only when a job needs it." on skip-all. Use `write --answers <file> [--others <confirmed file>] --dry-run`, review then write; respect user_cap. Backups precede replacement. Require status DONE and successful `finish`; retry finish on failure, disclose unresolved errors.
5. After completed or skipped setup, including DONE re-entry, load these exact skills one at a time, each once using its choice record: `offer-exec-interview-prep-reminder`, `offer-exec-conference-room-rundown-2-business`, `offer-exec-same-day-conference-room-check`, `offer-weekly-leadership-outreach-check`. No clear yes leaves routines paused; setup is never activation consent. Never repeat recorded offers. After skip-all confirm briefly; ask no replacement setup question.

Output: recipient-only USER.md, verified completion and offer choices. Disclose missing tools. Never invent answers or send/post/buy without explicit yes.
