---
name: send-newsletter
description: "Use when emailing an exclusive or yesterday's digest."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Send newsletter

Owns sends. Exclusive same day after live. Digest next morning for yesterday only.

## Rules

- **Exclusive:** same-day email after research pass + live site. Never for members-only.
- **Digest:** never same-day. Morning email of YESTERDAY's digest if the local file exists, has signal, and is not already in the send log.
- Never print the key. Never fake a send. If create-post is blocked, ping `report_to` and stop.
- Do not unsend mail already sent. Do not invent a paid newsletter early-access tier.

## Steps

1. Run `SITE status`. Read `newsletter_how` for the provider steps the user already has.
2. Pick the piece:
   - Exclusive: path of the piece that just went live today.
   - Digest: yesterday's date in the user timezone → `digests/YYYY-MM-DD.md` (in `<home>` and/or the site digests folder). Confirm signal in frontmatter. If missing or no signal, stop quietly.
3. Dedup: `SITE send-log query --kind <exclusive|digest> --path <path> --require-absent`. Exit 2 means already sent; stop.
4. Create the post with the user's provider using `newsletter_how`. Never create accounts. Never paste secrets into chat.
5. On success: `SITE send-log add --kind <exclusive|digest> --path <path> --note "<provider id or URL>"`.
6. On failure: do not write the send log. Ping `report_to` if set. Say what blocked the send.
