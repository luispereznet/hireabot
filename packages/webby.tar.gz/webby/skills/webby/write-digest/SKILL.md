---
name: write-digest
description: "Use when writing today's short social-pulse digest."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Write digest

Short daily social-pulse catch-up. Digest ≠ exclusive. Never write a digest from video transcripts.

## Steps

1. Run `SITE status`. Confirm timezone. Today's date is the user's local date.
2. Gather social pulse for today:
   - If X is connected in this profile, read the user's likes, reposts, and posts for the day.
   - If X is not connected, say so and ask the user to paste likes, reposts, and posts. Never read browser cookies. Never print keys.
3. If there is no signal (empty day), write a digest with no `--signal` flag or skip writing. Do not invent posts.
4. Draft a short catch-up. Run strip-ai-isms. Research / fact-check pass on any claim (same rule as exclusives: research bot if named, else public-source check). Never skip.
5. Write with `SITE write-digest --title "Digest YYYY-MM-DD" --body "..." --signal` when there is signal. This updates today's file if it exists; it refuses rewrite of old week or old day files.
6. Copy into the user's digests content folder (create-only / update today only). Never rewrite old week pages. Never delete.
7. Do **not** email today's digest in this run. Digest email is next morning via send-newsletter for YESTERDAY.
8. Hand off to ship-site so the homepage signal updates.
