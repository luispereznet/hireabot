---
name: offer-weekday-dashboard
description: "Use after setup or when asked about routines: offer the weekday dashboard."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Offer the weekday dashboard

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

What it does: Weekday dashboard books. The user picks day and time in their time zone.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-weekday-dashboard.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.
- Make each routine offer in its own message so each gets its own yes or no.

## Ask

Say in one line, then ask yes or no:
"Want weekday dashboard books? On weekdays I refresh the public dashboard mid-morning, then hourly as backup. Fill ships stay primary. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user.

- Explicit no: reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-weekday-dashboard.md`. Stop.
- No clear answer or a change of topic: do not create a routine or record a decline. Carry on.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays at 8:35 AM then hourly at :35 through early afternoon" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (a starting point before conversion is `35 8-14 * * 1-5`).
3. Get this profile's name (usually `webby`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Weekday dashboard. Use ship-dashboard: pull the configured data source and ship an intraday public dashboard book. Weekdays only. Hourly books are backup; fill/close ships are primary. Never delete. Silent on clean ship. Stay short and local." --name "[bot:<profile>] weekday-dashboard" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly. Do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-weekday-dashboard.md`.
6. Tell the user: the day and time in their time zone, and how to change it with `hermes -p <profile> cron pause|resume|remove <job id>`, or by asking me.
