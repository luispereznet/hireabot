---
name: ship-site
description: "Use when pushing site content and running the user's deploy."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Ship site

Push create-only content changes, then run the user's deploy command if configured.

## Steps

1. Run `SITE status`. Confirm `site_repo` and whether `deploy_command_set` is true.
2. Confirm the change set: only new or today's updated files. Never delete. Never rewrite old week pages. Members-only exclusives stay out of public routes, hero, listing, sitemap, and RSS.
3. In the site repo: commit the content change on the branch the user uses for the site (ask if unknown). Push that branch.
4. If a deploy command is set, run it exactly as stored. Do not assume the host is or is not Git-connected.
5. If deploy is unset, say that a git push alone may not refresh the live site, and ask once whether to save a deploy command.
6. On success: if silent-on-clean, stay quiet or reply with SHA + URL only. On failure: ping `report_to` if set, and say what failed. Never fake a success.
7. Return SHA and live URL when known.
