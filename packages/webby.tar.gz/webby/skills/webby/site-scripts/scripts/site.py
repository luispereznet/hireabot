#!/usr/bin/env python3
"""site.py: Webby's local helper. Standard library only.

Keeps state in its own home folder (default: $WEBBY_HOME, else
~/.hermes/profiles/webby/workspace/webby). Layout:

    state.json       site repo, folders, deploy, timezone, sources
    exclusives/      YYYY-MM-DD-<slug>.md create-only writes
    digests/         YYYY-MM-DD.md create-only (update today OK)
    send-log.jsonl   one line per newsletter send (kind, path, when)
    dashboard/       last ship checklist notes
    archive/         timestamped moves. Nothing is ever deleted.

Commands (run `site.py <command> -h` for options):
    init              create the folder layout and state.json
    status            print a JSON summary
    set               set config fields (no key-like names)
    write-exclusive   create an exclusive markdown file (refuses overwrite)
    write-digest      create or update TODAY's digest only
    frontmatter-check exit 2 if YAML has unescaped double quotes
    send-log          append or query newsletter send records
    dashboard-ship    write a dashboard ship checklist entry
    archive           move a file into archive/ with a timestamp (never delete)
    refuse-delete     always exit 2; documents that delete is forbidden

Never prints a key value. Never deletes. Never invents owner paths.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import sys
from pathlib import Path

DEFAULT_HOME = Path(os.environ.get('WEBBY_HOME') or '~/.hermes/profiles/webby/workspace/webby').expanduser()
FOLDERS = ('exclusives', 'digests', 'dashboard', 'archive')
FORBIDDEN_SET = re.compile(r'(key|token|secret|password|api_key|auth)', re.I)
DEFAULT_STATE = {
    'site_repo': '', 'content_folder': '', 'exclusives_folder': '', 'digests_folder': '',
    'deploy_command': '', 'timezone': '', 'youtube_source': '', 'newsletter_how': '',
    'dashboard_source': '', 'report_to': '', 'research_bot': '', 'silent_on_clean': True,
    'created': '',
}


def now() -> dt.datetime:
    return dt.datetime.now().astimezone()


def home(a) -> Path:
    return Path(a.root).expanduser() if getattr(a, 'root', None) else DEFAULT_HOME


def load(h: Path) -> dict:
    f = h / 'state.json'
    if not f.is_file():
        sys.exit(f'No state at {f}. Run: site.py init --root {h}')
    data = json.loads(f.read_text())
    return {**DEFAULT_STATE, **data}


def save(h: Path, st: dict) -> None:
    f = h / 'state.json'
    tmp = f.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(st, indent=2) + '\n')
    tmp.replace(f)


def slugify(text: str) -> str:
    s = re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')
    return (s or 'piece')[:48]


def yaml_safe_scalar(value: str) -> str:
    """Prefer single-quoted YAML scalars when the value holds double quotes."""
    if value is None:
        return "''"
    s = str(value)
    if "'" in s and '"' in s:
        # escape single quotes the YAML way
        return "'" + s.replace("'", "''") + "'"
    if '"' in s or ':' in s or s.startswith(' ') or s.endswith(' ') or s == '':
        return "'" + s.replace("'", "''") + "'"
    if re.search(r'[#\{\}\[\],&*!|>%@`]', s):
        return "'" + s.replace("'", "''") + "'"
    return s


def build_frontmatter(fields: dict) -> str:
    lines = ['---']
    for k, v in fields.items():
        if isinstance(v, bool):
            lines.append(f'{k}: {"true" if v else "false"}')
        elif isinstance(v, (int, float)):
            lines.append(f'{k}: {v}')
        else:
            lines.append(f'{k}: {yaml_safe_scalar(str(v))}')
    lines.append('---')
    return '\n'.join(lines) + '\n'


def has_unsafe_frontmatter(text: str) -> list:
    """Return list of problem lines: unescaped " inside a YAML double-quoted scalar is OK,
    but bare `key: something "quoted" here` without outer single quotes is unsafe."""
    problems = []
    if not text.startswith('---'):
        return ['missing opening ---']
    end = text.find('\n---', 3)
    if end < 0:
        return ['missing closing ---']
    block = text[3:end]
    for i, line in enumerate(block.splitlines(), 1):
        if not line.strip() or line.strip().startswith('#'):
            continue
        if ':' not in line:
            continue
        key, _, val = line.partition(':')
        val = val.strip()
        if not val:
            continue
        # safe if single-quoted, or boolean/number, or no double quote
        if val.startswith("'") and val.endswith("'"):
            continue
        if val in ('true', 'false', 'null') or re.fullmatch(r'-?\d+(\.\d+)?', val):
            continue
        if '"' in val:
            problems.append(f'line {i}: unescaped double quote in YAML value: {line.strip()[:80]}')
    return problems


def cmd_init(a):
    h = home(a)
    h.mkdir(parents=True, exist_ok=True)
    for name in FOLDERS:
        (h / name).mkdir(exist_ok=True)
    f = h / 'state.json'
    if f.is_file():
        st = load(h)
    else:
        st = dict(DEFAULT_STATE)
        st['created'] = now().isoformat(timespec='seconds')
        save(h, st)
    log = h / 'send-log.jsonl'
    if not log.is_file():
        log.write_text('')
    print(json.dumps({'ok': True, 'home': str(h), 'created': st.get('created')}))


def cmd_status(a):
    h = home(a)
    st = load(h)
    exclusives = sorted((h / 'exclusives').glob('*.md')) if (h / 'exclusives').is_dir() else []
    digests = sorted((h / 'digests').glob('*.md')) if (h / 'digests').is_dir() else []
    sends = 0
    log = h / 'send-log.jsonl'
    if log.is_file():
        sends = sum(1 for line in log.read_text().splitlines() if line.strip())
    out = {
        'home': str(h),
        'site_repo': st.get('site_repo') or '',
        'content_folder': st.get('content_folder') or '',
        'deploy_command_set': bool(st.get('deploy_command')),
        'timezone': st.get('timezone') or '',
        'youtube_source_set': bool(st.get('youtube_source')),
        'newsletter_how_set': bool(st.get('newsletter_how')),
        'dashboard_source_set': bool(st.get('dashboard_source')),
        'report_to': st.get('report_to') or '',
        'research_bot': st.get('research_bot') or '',
        'exclusives': len(exclusives),
        'digests': len(digests),
        'send_log_entries': sends,
        'silent_on_clean': bool(st.get('silent_on_clean', True)),
    }
    print(json.dumps(out, indent=2))


def cmd_set(a):
    h = home(a)
    st = load(h)
    for item in a.pairs:
        if '=' not in item:
            sys.exit(f'Bad set item (need key=value): {item}')
        k, _, v = item.partition('=')
        k = k.strip()
        if k not in DEFAULT_STATE:
            sys.exit(f'Unknown field {k}. Allowed: {", ".join(DEFAULT_STATE)}')
        if FORBIDDEN_SET.search(k):
            sys.exit(f'Refused key-like field name: {k}')
        if k == 'silent_on_clean':
            st[k] = v.strip().lower() in ('1', 'true', 'yes', 'on')
        else:
            st[k] = v.strip()
    save(h, st)
    print(json.dumps({'ok': True, 'set': a.pairs}))


def cmd_write_exclusive(a):
    h = home(a)
    st = load(h)
    day = a.date or now().date().isoformat()
    slug = slugify(a.slug or a.title)
    path = h / 'exclusives' / f'{day}-{slug}.md'
    if path.exists() and not a.force_fail_if_exists:
        # create-only: refuse overwrite
        sys.exit(f'Refused overwrite (create-only): {path}')
    if path.exists():
        sys.exit(f'Refused overwrite (create-only): {path}')
    fields = {
        'title': a.title,
        'date': day,
        'slug': slug,
        'excerpt': a.excerpt or '',
        'members': bool(a.members),
        'source': a.source or st.get('youtube_source') or '',
    }
    body = build_frontmatter(fields) + (a.body or '\n')
    problems = has_unsafe_frontmatter(body)
    if problems:
        sys.exit('Unsafe frontmatter:\n' + '\n'.join(problems))
    path.write_text(body)
    print(json.dumps({'ok': True, 'path': str(path), 'members': bool(a.members)}))


def cmd_write_digest(a):
    h = home(a)
    day = a.date or now().date().isoformat()
    today = now().date().isoformat()
    # Only allow create; update allowed only for today's file
    path = h / 'digests' / f'{day}.md'
    if path.exists() and day != today and not a.allow_old_update:
        sys.exit(f'Refused rewrite of old digest: {path}. Update today only.')
    fields = {
        'title': a.title or f'Digest {day}',
        'date': day,
        'kind': 'digest',
        'signal': bool(a.signal),
    }
    body = build_frontmatter(fields) + (a.body or '\n')
    problems = has_unsafe_frontmatter(body)
    if problems:
        sys.exit('Unsafe frontmatter:\n' + '\n'.join(problems))
    path.write_text(body)
    print(json.dumps({'ok': True, 'path': str(path), 'updated': day == today and path.exists(), 'signal': bool(a.signal)}))


def cmd_frontmatter_check(a):
    text = Path(a.file).read_text() if a.file else sys.stdin.read()
    problems = has_unsafe_frontmatter(text)
    if problems:
        print('\n'.join(problems))
        sys.exit(2)
    print(json.dumps({'ok': True}))


def cmd_send_log(a):
    h = home(a)
    log = h / 'send-log.jsonl'
    if a.action == 'query':
        rows = []
        if log.is_file():
            for line in log.read_text().splitlines():
                if not line.strip():
                    continue
                row = json.loads(line)
                if a.kind and row.get('kind') != a.kind:
                    continue
                if a.path and row.get('path') != a.path:
                    continue
                rows.append(row)
        print(json.dumps({'entries': rows, 'count': len(rows)}, indent=2))
        if a.require_absent and rows:
            sys.exit(2)
        return
    if a.action == 'add':
        if not a.kind or not a.path:
            sys.exit('send-log add needs --kind and --path')
        # refuse duplicate
        if log.is_file():
            for line in log.read_text().splitlines():
                if not line.strip():
                    continue
                row = json.loads(line)
                if row.get('kind') == a.kind and row.get('path') == a.path:
                    sys.exit(f'Already in send-log: {a.kind} {a.path}')
        entry = {
            'kind': a.kind,
            'path': a.path,
            'when': now().isoformat(timespec='seconds'),
            'note': a.note or '',
        }
        with log.open('a') as fh:
            fh.write(json.dumps(entry) + '\n')
        print(json.dumps({'ok': True, 'entry': entry}))
        return
    sys.exit(f'Unknown send-log action: {a.action}')


def cmd_dashboard_ship(a):
    h = home(a)
    st = load(h)
    day = a.date or now().date().isoformat()
    stamp = now().strftime('%Y%m%dT%H%M%S')
    path = h / 'dashboard' / f'{day}-{a.kind}-{stamp}.md'
    checklist = [
        f'# Dashboard ship ({a.kind})',
        f'- when: {now().isoformat(timespec="seconds")}',
        f'- source: {st.get("dashboard_source") or "(unset)"}',
        f'- note: {a.note or ""}',
        '- [ ] pulled book / numbers from the configured data source',
        '- [ ] wrote public dashboard files (create or update today only)',
        '- [ ] ran deploy_command if set',
        '- [ ] silent on clean ship (or pinged report_to on failure only)',
    ]
    path.write_text('\n'.join(checklist) + '\n')
    print(json.dumps({'ok': True, 'path': str(path), 'kind': a.kind}))


def cmd_archive(a):
    h = home(a)
    src = Path(a.path).expanduser()
    if not src.exists():
        sys.exit(f'Nothing to archive: {src}')
    stamp = now().strftime('%Y%m%dT%H%M%S')
    dest = h / 'archive' / f'{stamp}-{src.name}'
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dest))
    print(json.dumps({'ok': True, 'from': str(src), 'to': str(dest)}))


def cmd_refuse_delete(a):
    print('Delete is forbidden. Use: site.py archive <path>', file=sys.stderr)
    sys.exit(2)


def main(argv=None):
    p = argparse.ArgumentParser(prog='site.py')
    p.add_argument('--root', default=None, help='override WEBBY_HOME')
    sp = p.add_subparsers(dest='cmd', required=True)

    s = sp.add_parser('init'); s.set_defaults(func=cmd_init)
    s = sp.add_parser('status'); s.set_defaults(func=cmd_status)
    s = sp.add_parser('set'); s.add_argument('pairs', nargs='+'); s.set_defaults(func=cmd_set)

    s = sp.add_parser('write-exclusive')
    s.add_argument('--title', required=True)
    s.add_argument('--slug')
    s.add_argument('--date')
    s.add_argument('--excerpt', default='')
    s.add_argument('--body', default='\n')
    s.add_argument('--source', default='')
    s.add_argument('--members', action='store_true')
    s.add_argument('--force-fail-if-exists', action='store_true')
    s.set_defaults(func=cmd_write_exclusive)

    s = sp.add_parser('write-digest')
    s.add_argument('--title', default='')
    s.add_argument('--date')
    s.add_argument('--body', default='\n')
    s.add_argument('--signal', action='store_true')
    s.add_argument('--allow-old-update', action='store_true')
    s.set_defaults(func=cmd_write_digest)

    s = sp.add_parser('frontmatter-check')
    s.add_argument('--file')
    s.set_defaults(func=cmd_frontmatter_check)

    s = sp.add_parser('send-log')
    s.add_argument('action', choices=['add', 'query'])
    s.add_argument('--kind')
    s.add_argument('--path')
    s.add_argument('--note', default='')
    s.add_argument('--require-absent', action='store_true')
    s.set_defaults(func=cmd_send_log)

    s = sp.add_parser('dashboard-ship')
    s.add_argument('--kind', required=True, choices=['intraday', 'close', 'fill', 'manual'])
    s.add_argument('--date')
    s.add_argument('--note', default='')
    s.set_defaults(func=cmd_dashboard_ship)

    s = sp.add_parser('archive')
    s.add_argument('path')
    s.set_defaults(func=cmd_archive)

    s = sp.add_parser('refuse-delete')
    s.add_argument('path', nargs='?')
    s.set_defaults(func=cmd_refuse_delete)

    args = p.parse_args(argv)
    args.func(args)


if __name__ == '__main__':
    main()
