---
name: write-exclusive
description: "Use when writing a long-form exclusive from YouTube or transcripts."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Write exclusive

Long-form site piece from the user's YouTube playlist or named transcripts. Never from social pulse.

## Steps

1. Run `SITE status`. If `site_repo` is empty, run site-setup first.
2. Find the next public long-form item from the configured `youtube_source` (playlist, channel, or transcript folder). If the video is UNPLAYABLE or members-only: write the markdown with `members: true` via `SITE write-exclusive --title "..." --members`, do not publish, list, email, or put it on public routes. Stop and say it is held until public.
3. Draft the exclusive in the urgent-explainer voice. Run strip-ai-isms on the draft.
4. Research / fact-check pass (never skip):
   - If `research_bot` is set in status, send the claims there and wait for the pass.
   - Else do a careful public-source check yourself. Note anything unverified.
5. Frontmatter: title, date (user timezone), slug, excerpt. Never unescaped double quotes in YAML. Prefer single-quoted scalars when title or excerpt holds `"`. Check with `SITE frontmatter-check --file ...`.
6. Write create-only: `SITE write-exclusive --title "..." --excerpt "..." --body "..." [--source "..."]`. If it refuses overwrite, stop and ask.
7. Copy the file into the user's exclusives content folder from status (create-only there too). Never delete old files.
8. Hand off to ship-site, then send-newsletter (exclusive, same day after live). Do not email if members-only.
