---
name: strip-ai-isms
description: "Use when drafting or editing site, script, digest, or idea copy."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Strip AI-isms

Remove LLM writing tells. Match an urgent-explainer voice: short, concrete, no throat-clearing.

## Checks (run every time)

1. **Openers to cut:** "In today's rapidly evolving…", "It's important to note…", "In conclusion…", "Delve", "landscape", "robust", "seamless", "leverage", "utilize", "empower".
2. **Empty intensifiers:** "truly", "basically", "essentially", "innovative", "cutting-edge", "game-changer" unless the user wrote them.
3. **Fake balance:** "On one hand… on the other…" when there is one clear point. Pick the point.
4. **List spam:** more than three parallel "-ing" bullets usually means the draft is padding. Collapse.
5. **Hedges stacked:** "may potentially could" → one hedge or none.
6. **Em dashes and semicolon chains:** prefer periods. Short sentences.
7. **Invented certainty:** if a number or quote was not in the source, remove it or mark it unverified.
8. **Voice:** urgent explainer. Lead with the fact or the link. One idea per sentence.

## Steps

1. Read the draft once for meaning.
2. Apply the checks above. Rewrite in place; do not add a preamble about what you changed unless the user asks.
3. Re-read aloud (silently). If a line could be a stock chatbot line, cut or rewrite it.
4. Return only the cleaned copy, unless the user asked for a diff.
