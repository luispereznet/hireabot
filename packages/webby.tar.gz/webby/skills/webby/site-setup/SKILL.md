---
name: site-setup
description: "Use when this is the first run or the user asks to set up Webby again."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Site setup (first run)

Goal: helper installed, the user's site, newsletter, and dashboard sources known. Ask one question per reply. Every question can be skipped.

## Steps

1. Find this profile's folder (`~/.hermes/profiles/<profile>`, usually `webby`). Set `<home>` = `<profile folder>/workspace/webby`.
2. Install the helper: create `<home>`, then copy `site.py` from the site-scripts skill folder (`skills/webby/site-scripts/scripts/site.py` inside this profile) to `<home>/site.py` if it is missing or older. If an older copy exists, run `SITE archive <home>/site.py` first. Then run `SITE init` and `SITE status`. If either fails, say so and stop.
3. One intro line: "I run your site, newsletter, and weekday dashboard. Create-only. Nothing deletes, and members-only videos stay private until they are public."
4. Ask for the site repo path (local clone) or content folders. Save with `SITE set site_repo=... content_folder=... exclusives_folder=... digests_folder=...`.
5. Ask how deploys work: "After a content push, what deploy command should I run? Skip if a git push alone refreshes the live site, or if you will deploy yourself." Save `SITE set deploy_command=...` or leave blank.
6. Ask timezone. Save `SITE set timezone=...`.
7. Ask YouTube source: playlist URL, channel, or a folder of transcripts. Save `SITE set youtube_source=...`.
8. Ask newsletter how-to: which provider they already use and how they create a post (do not create accounts). Save `SITE set newsletter_how=...`.
9. Ask dashboard data source: a file path, URL, or the name of another bot they use. Do not assume a desk agent. Save `SITE set dashboard_source=...`.
10. Optional: report-to contact for failures only, and an optional research-bot name for the fact-check pass. Save `SITE set report_to=... research_bot=...`.
11. Ask silent-on-clean: default yes. Save `SITE set silent_on_clean=true`.
12. Finish with: "Set. Exclusive, digest, newsletter, dashboard, or something else?"
13. Never rerun setup on day two unless they ask. MEMORY has the day-two opener.
