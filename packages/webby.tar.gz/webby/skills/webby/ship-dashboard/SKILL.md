---
name: ship-dashboard
description: "Use when shipping the public weekday dashboard from the user's data source."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "webby"}}
---

# Ship dashboard

Public weekday dashboard from the data source the user named. No hardcoded desk agent.

## Steps

1. Run `SITE status`. If `dashboard_source` is empty, ask once for a file, URL, or bot name. Save with `SITE set dashboard_source=...`.
2. Pull the book / numbers from that source (read-only). If the source is another bot, ask it for the payload; do not invent numbers.
3. Kind:
   - `fill` or immediate close report from the user/source → ship now (`SITE dashboard-ship --kind fill`).
   - Intra-day book → `--kind intraday`.
   - Official close → `--kind close`.
4. Update today's public dashboard files only. Never delete history. Keep a weekday-only chart if the site has one.
5. Run ship-site (push + deploy if configured).
6. Silent on clean ship when configured. Ping `report_to` only on failure.
7. Hourly books are backup. A fill or close report ships immediately when that offer is enabled.
