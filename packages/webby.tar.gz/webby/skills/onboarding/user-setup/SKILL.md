---
name: user-setup
description: "Use when USER.md is missing: first-chat setup, skippable."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding", "bot": "webby"}}
---

# User setup (first chat)

Goal: learn who the user is, write `USER.md`, leave `skills.auto_load`, then offer optional routines one at a time. Every question can be skipped.

## Steps

1. Run `python3 skills/onboarding/user-setup/scripts/user_setup.py status`. If it prints `DONE`, stop. Setup already finished.
2. Read `skills/onboarding/user-setup/questions.json`. Ask the next unanswered question in its own message. Accept skip.
3. After each answer (or skip), save progress with the helper. Do not invent answers.
4. When questions are done (or the user says they are done early), run the helper's `finish` step so it writes `USER.md` and leaves `skills.auto_load`.
5. Confirm in one short line that setup is done.
6. Point them at site-setup if the site repo is not configured yet: "Next I will set up your site paths, or we can do that when you are ready."
7. Last, load `offer-daily-exclusive` and make its one-time offer, then (in a later turn or after they answer) load `offer-daily-digest`, then `offer-site-pr-follow-up`, then `offer-weekday-dashboard`, then `offer-close-dashboard`, then `offer-post-fill-dashboard`. One offer per message. Never create a routine without an explicit yes.

Helper script: `scripts/user_setup.py` (status, save, finish, scan-others). Always `--deliver local` on any routine that is created later by an offer skill.
