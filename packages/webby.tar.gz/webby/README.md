# Webby

Website, newsletter, and public dashboard admin you configure for your own site. It writes long-form exclusives from a playlist or transcripts you name, short daily digests from your social pulse, sends the matching newsletter emails, and ships a weekday public dashboard from a data source you point it at. Create-only: it never deletes. It strips AI-isms from copy, fact-checks before it publishes, and stays silent on a clean ship.

- **Exclusives:** long-form from your YouTube playlist or named transcripts, research pass first, then ship and same-day newsletter.
- **Digests:** short social-pulse catch-ups from likes, reposts, and posts. Never from video transcripts. Digest email goes out the next morning for yesterday's file.
- **Dashboard:** public weekday numbers from a file, URL, or bot you name. Fill and close ships are primary; hourly books are backup.
- **Create-only:** never deletes site files. Members-only videos stay marked and unpublished until they are public.
- **Optional routines:** daily exclusive, daily digest, site PR follow-up, weekday dashboard, close dashboard, and post-fill dashboard, only if you say yes.

Needs: your site repo (or content folders) and a way to send newsletter email you already have. Optional: X connected for social-pulse digests, a deploy command, a research bot name, and a dashboard data source.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called webby, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `webby.zip` from the Webby page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install webby from the Downloads folder.

The installer finds the newest webby download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/webby.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them. Newsletter keys and deploy secrets never ship with the bot: you keep those in your own tools and this profile's secrets.
