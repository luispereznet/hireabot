---
name: reconcile-registration-and-brief
description: Use when reconciling a Luma guest list and Notion event brief.
version: 0.1.0
---

# Reconcile registration and event brief

## When to use
Registration hygiene, capacity/waitlist review or Notion-to-Luma drift checks.

## Inputs
Authorized Luma export or signed-in page, approved Notion brief or supplied export, event identifier and data timestamp. Read ../references/working-notes.md.

## Steps
1. Confirm the exact event on both sides using supplied identifiers. If Notion/browser tools are absent, disclose that and use exports; do not pretend they are connected.
2. Compare date/time zone, venue, copy, capacity, visibility, required questions and hidden hosts. Report each difference with its source; ask the owner which conflicting value is authoritative.
3. Inspect registrations for missing Company/Title, duplicate candidate records and status inconsistencies. Match conservatively using supplied stable identifiers; do not merge distinct attendees from similar names. Count only actual provided rows and label export scope/time. Keep contact and dietary data private and minimize retained fields.
4. Produce a dry-run reconciliation table: current value, proposed value, evidence, affected record IDs and reason. Never delete registrations, expose dietary answers, increase capacity or promote a waitlisted person by inference.
5. Obtain explicit yes for the exact remote edits before changing either system. Update only approved records; read back each target and compare against the proposal. Stop on permissions or conflicting edits; preserve the original export.

## Output and guardrails
Return drift report, sourced registration summary and approved-change verification. Keep a minimal local event mapping only when requested. No guest invites or sales sends; no invented attendee/CRM totals.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
