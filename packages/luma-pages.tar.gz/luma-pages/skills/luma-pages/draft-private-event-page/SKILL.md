---
name: draft-private-event-page
description: Use when drafting or updating a private Luma event page.
version: 0.1.0
---

# Draft a private event page

## When to use
A field or VIP hospitality event needs a new page or approved settings update.

## Inputs
Supplied event brief, event owner, verified date/time zone, venue/address or online link, audience, capacity and approval policy. Read ../references/working-notes.md.

## Steps
1. Extract a fact table with source links and unresolved fields. Ask one blocking question at a time. Do not invent speakers, venue, dates, event URLs or capacity.
2. Draft title, value proposition, description and Going confirmation email. Use plain-text blank-line sections in email. The supplied email fragment is incomplete: stop at verified content, do not claim to recover its ending. No literal markdown asterisks in Luma; apply bold only using the rich-text editor.
3. Prepare a settings checklist: PRIVATE visibility, required Company and Title, internal hosts hidden. For food or dinner require “Do you have any dietary requirements or restrictions?” Background gray (first palette swatch), font Default. Confirm capacity/waitlist with the owner rather than choosing numbers.
4. If signed-in browser/desktop access is missing, return the draft and checklist; request a sign-in handoff, never credentials in chat. Do not claim a Luma MCP exists.
5. Present exact changes and ask for explicit yes before remote creation/update. Apply only approved changes, retaining PRIVATE. Read back visibility, form fields, hosts, branding, copy and capacity from the exact page; report discrepancies. Publishing requires its own explicit yes and readback.

## Output and guardrails
Return sourced copy, proposed-versus-verified settings, real URL only after readback, and blockers. Never send invitations or sales outreach. No account action merely because setup completed.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
