---
name: luma-pages
description: Use when a task needs Luma Pages reference notes.
version: 0.1.0
---

# Luma Pages: workflow router

## When to use
Read references/working-notes.md at the start of tasks covered here, before asking already-answered questions. These are operational rules, not personal memory.

## Steps
1. Identify the requested operation and available authorized tools.
2. Load the exact relevant workflow below.
3. Follow its inputs, numbered steps, outputs and consent checks.

- skills/luma-pages/draft-private-event-page/SKILL.md
- skills/luma-pages/reconcile-registration-and-brief/SKILL.md


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
