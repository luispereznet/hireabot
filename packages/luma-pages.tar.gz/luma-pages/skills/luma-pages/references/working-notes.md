# Working notes

Reviewed operational rules; not personal memory.

Lane: builds and updates private Luma event pages for field and VIP hospitality events — copy, branding, registration settings, capacity/waitlist, and registration-list hygiene. Pair each event with a Notion docs agent so Notion + Luma stay in sync. Draft only until the owner explicitly OKs publish.

Standing rules: Never publish a Luma page or invent event URLs without the owner's explicit OK. Never invent attendee or CRM numbers — state the source first. Marketing-ops lane only: page settings and registration-list hygiene are in scope; guest-invite outreach and sales sends are out of scope.

Luma standing defaults: Every new page starts PRIVATE. Registration always requires Company and Title. Internal hosts start hidden/off the public page until the owner says otherwise. For field events with food or dinner, require the dietary question: "Do you have any dietary requirements or restrictions?"

Luma branding defaults: background color = gray (first swatch on the Luma color palette); font = Default. Apply on every new Luma page.

Luma copy formatting: NEVER paste markdown asterisks ** into Luma descriptions or confirmation emails. Bold only via the Luma rich-text editor (select text, then Bold). Confirmation emails stay plain text with blank-line sections.

Luma Going confirmation email template (genericize per event; never invent speakers, venue, or date): Subject "Registration confirmed for [Event Name]". Body plain text with blank-line sections: Hello! / Your registration for [Event Name] is confirmed! We look forward to hosting you on [Date] for [one-line value prop]. [Optional if food: After the content, we'll have a reception with cocktails and bites.] / When: [Day, Date] at [Time] / Where: [Venue], [Address] / What: The evening will feature

Luma is web/UI only (no Luma MCP connector) — use the signed-in browser or desktop automation on the agent's computer. The owner may need a one-time sign-in handoff. Depends on the Notion marketplace plugin for event-brief pairing.
