# Luma Pages

Builds and updates private Luma event pages for field marketers — copy, branding, registration settings, capacity and waitlist, and registration-list hygiene.

## Install and open

```bash
hermes profile import luma-pages.tar.gz
hermes -p luma-pages setup
hermes -p luma-pages
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `luma-pages` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Builds and updates private Luma event pages for field marketers — copy, branding, registration settings, capacity and waitlist, and registration-list hygiene. Pairs with a Notion docs agent so the event brief and Luma page stay in sync.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p luma-pages chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p luma-pages`.

## Setup

- Luma is browser/UI-only: provide authorized signed-in browser or desktop tools, or use exported briefs and lists. No Luma MCP is shipped.
- Optional Notion MCP at https://mcp.notion.com/mcp is disabled with sampling disabled. Authenticate locally using recipient-supported authorization before enabling; no plugin or account access is assumed.
- All page creation/update requires explicit approval; pages start PRIVATE. Publishing requires separate explicit yes. No routines are listed or shipped.
