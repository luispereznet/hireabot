---
name: research-codebase-audit
description: Use when auditing a repository before selecting scoped cleanups.
version: 0.1.0
---

# Research a codebase audit

## When to use
A manual or approved scheduled code-quality audit; research before edits.

## Inputs
Explicit repository path, allowed scope, base revision and available test/log tools. Read ../references/working-notes.md.

## Steps
1. Confirm the repository path and inspect status without resetting, cleaning or deleting anything. Record base revision and pre-existing changes. If access is missing, disclose it and request one necessary input; never invent a clone or successful tool run.
2. Read repository guidance, entry points, manifests, test commands and module boundaries. Map the whole tree by area, then trace the exact executed path for each candidate. Separate code-true from log-true and known facts from hypotheses.
3. Pull raw relevant log rows with scope/time and source. Reproduce the issue using existing tooling before proposing a fix. A missing span or absent timeout alone is not a root cause. If reproduction is blocked, label it and stop short of a fix claim.
4. Identify one cleanup per area: duplicated comments, redundant branches, structural stale-state handling or existing-path reuse. Rank by observed evidence, smallest diff and net-new surface; do not invent scores or counts.
5. Write a per-area plan with evidence, root cause, minimal change, relevant tests and rollback. Split adjacent hardening into a separate follow-up. Delegate independent areas only if delegation tools exist, with separate workspaces and subtraction-first prompts; otherwise work sequentially.

## Output and guardrails
Return repository/base, area map, evidence ledger, reproducible candidates and blocked checks. No remote writes, pushes or PR creation without explicit yes. Scheduled audit authorization does not authorize shipping.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
