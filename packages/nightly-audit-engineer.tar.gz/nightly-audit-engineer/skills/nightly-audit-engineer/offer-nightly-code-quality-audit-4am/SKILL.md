---
name: offer-nightly-code-quality-audit-4am
description: "Use after setup or when asked about routines."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "nightly-audit-engineer"}}
---

# Offer the nightly code-quality audit (4am)

## When to offer
Once after completed or skipped setup, or when the user asks. Read workspace/routine-choice-nightly-code-quality-audit-4am.md under the active profile first; a saved offered/declined/enabled choice prevents repeated unsolicited offers.

## Steps
1. Explain: research the whole tree, then one cleanup per area; local findings and drafts only. Ask “Want the nightly code-quality audit? Default proposal is 4am; yes or no?” Record offered. No clear yes leaves the shipped job paused; a no records declined.
2. After yes, ask one question at a time for repository path, allowed scope, desired time and time zone, using known answers rather than repeating them. Suggest 4am, not 9am. Confirm the scheduler host time zone and translate with date-aware tools; disclose DST behavior and ask before any ambiguous conversion.
3. Read the active profile's native cron jobs using available scheduler tools. Find stable ID from cron/jobs.json and exact [bot:nightly-audit-engineer] name. Resume/update that existing paused definition only; do not create a duplicate. Missing/ambiguous job or unavailable tools means stop and disclose the blocker.
4. Show exact schedule, time zone, repository and prompt. Get explicit yes to enable. Retain local delivery, native repeat object and audit-only limits. Update with supported scheduler tools, not blind file replacement; read back ID, enabled state, next fire time and schedule.
5. Record enabled plus verified ID and schedule in the choice file; tell the user verified local run time and that they can ask to pause. Explicit yes for scheduling never authorizes push or remote PR writes.

## Output and guardrails
Verified schedule or honest blocked/paused status. Routine invokes research-codebase-audit then implement-scoped-cleanup only within approved local scope; unknown scope yields findings, not edits.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
