---
name: implement-scoped-cleanup
description: Use when implementing and verifying one researched code cleanup.
version: 0.1.0
---

# Implement one scoped cleanup

## When to use
After research establishes a reproducible issue and an approved local edit scope.

## Inputs
Repository, evidence-backed per-area plan, base revision and test commands. Read ../references/working-notes.md; first complete sibling skill research-codebase-audit.

## Steps
1. Check working tree against the recorded base; preserve unrelated edits. Select one area and one root cause. Reuse or remove existing code first; explain any new state or deviation from the existing path.
2. Make the smallest local change. Retain only non-obvious why-comments. For comments-only trims, delegate when available and re-test; disclose unavailable delegation. Do not add guards/flags to chase repeated adjacent findings: stop and propose a structural model instead.
3. Run the reproduced failing case and relevant existing tests/checks. Report exact commands, real exit results and untested scope. Missing dependencies or tools are blockers, not passing tests. Do not install dependencies, use paid services or mutate external systems without approval.
4. Review diff and net-new surface. If the fix balloons into hardening or new subsystems, split a follow-up and retain only the actual fix. Capture rollback as a proposed reversal of this diff, never destructive resets.
5. Prepare one local PR draft per area: root cause, evidence, change, tests and remaining risks. Ask explicit yes covering push and remote PR creation/update, target repository and branch. Without yes keep it local. If approved and tools exist, perform only approved writes and read back exact remote commit/PR before claiming shipment.

## Output and guardrails
Return diff summary, real verification, local draft and blockers. Never claim a PR exists from a prepared payload; no merge, release, send or purchase by default.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
