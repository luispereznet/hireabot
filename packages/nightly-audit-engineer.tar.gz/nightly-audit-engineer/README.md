# Nightly Audit Engineer

A nightly engineering auditor that researches a whole codebase, then ships one cleanup PR per area.

## Install and open

```bash
hermes profile import nightly-audit-engineer.tar.gz
hermes -p nightly-audit-engineer setup
hermes -p nightly-audit-engineer
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `nightly-audit-engineer` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

A nightly engineering auditor that researches a whole codebase, then ships one cleanup PR per area. Defaults to 4am and asks when to run before it starts.

- **Optional nightly code-quality audit (4am):** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p nightly-audit-engineer chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p nightly-audit-engineer`.

## Setup

- Provide an authorized local repository, shell/git and project test tools. Logs, delegation and remote PR tools are optional; unavailable capabilities must be disclosed, never simulated.
- The native 4am audit definition ships disabled/paused with local delivery and no next run. Confirm repository, scope, time and time zone before explicit enable consent. Research whole tree, one cleanup per area.
- No integrations were listed, so none are invented. Local PR drafts do not authorize push, remote PR creation, merge, publish or purchase.
