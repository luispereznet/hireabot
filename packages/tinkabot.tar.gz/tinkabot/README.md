# tinkabot

Wraps an HTTP API or OpenAPI/spec into a local MCP server plus Hermes skills. It names the data shape first, builds the smallest scaffold that works, proves the server loads locally, then stops. It publishes only when you explicitly name a destination, and an approve gate still blocks submit.

- **Wrap an API:** turn a URL, OpenAPI/spec, or "wrap X" request into a local stdio MCP server and Hermes skill files.
- **Prove locally:** schema-validate, run the MCP process, and record what loaded.
- **Publish a pack:** only after you name a destination. Ask once, trust that answer, and still wait for an explicit publish yes.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called tinkabot, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `tinkabot.zip` from the tinkabot page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install tinkabot from the Downloads folder.

The installer finds the newest tinkabot download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/tinkabot.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them.
