---
name: prove-local
description: "Use when proving a wrap loads locally: validate, run MCP, record what loaded."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "tinkabot"}}
---

# Prove a wrap loads locally

Goal: show that the pack from wrap-api actually runs on this machine under Hermes (or as a local MCP stdio process Hermes can attach). Record what loaded. Do not publish from this skill.

Working folder: `~/.hermes/profiles/tinkabot/workspace`. Target pack: `wraps/<slug>/` unless the user names another path.

## Steps

1. Confirm the pack path and that `mcp.json` (or the Hermes MCP entry) and the server script exist.
2. Schema-validate the MCP entry and any tool schemas you wrote. Fix failures before running the process.
3. Start the MCP server as a local stdio process using the command in the pack. Do not install it into a code-editor plugin path. Prefer proving against Hermes-local config or a direct local process Hermes can call.
4. List tools the process advertises. Call one cheap read-only tool when the API allows (for example a health or list endpoint). Never call a write or paid endpoint without the user's yes.
5. Write a short proof receipt to `wraps/<slug>/PROOF.md` with: time (user's local zone), command used, tools seen, sample call result or error, and PASS or FAIL.
6. If FAIL: fix the pack, re-run, and update the receipt. Do not claim done on a failed proof.
7. Tell the user: path, PASS/FAIL, tools loaded, and that publish is still blocked until they name a destination and say to publish it.

## Never

- Never treat an editor marketplace or local editor plugin folder as the prove target.
- Never publish, deploy, or push from this skill.
- Never store API secrets in the receipt; name the env var only.
- Never install extra MCP helpers or tunnels on this computer for the proof.
