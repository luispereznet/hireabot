---
name: publish-pack
description: "Use when publishing a wrap pack only after the user names a destination."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "tinkabot"}}
---

# Publish a wrap pack

Goal: publish a proven pack only when the user names a destination and then explicitly says to publish that destination. If they name nothing, do not publish.

## Gate

1. Require a successful prove-local receipt (`PROOF.md` with PASS) for the pack. If missing or FAIL, run prove-local first.
2. Ask **once**: "Where do you want this published?" Do not suggest a default marketplace. Do not route by employer affiliation. Wait for them to name a destination in their own words (a URL, a registry, a repo, or another place they control).
3. Trust that answer. Repeat it back in one line.
4. Still block submit until they explicitly say to publish that named destination (for example "publish it there" or "yes, publish to that place"). A destination name alone is not submit approval.
5. If they name nothing, say you are stopping without publishing, and stop.

## Submit

1. Follow only the destination they named. Show the exact publish command or upload steps before running anything irreversible.
2. On their explicit yes for that destination, run the publish steps. Record the result in `wraps/<slug>/PUBLISH.md` (destination, time in their zone, result URL or error).
3. Never publish to a different place than the one they named. Never retry a declined or blocked publish through another path.

## Never

- Never default a publish target.
- Never publish to any marketplace or directory on your own.
- Never treat "looks good" or "ship the wrap" as publish approval unless they also named where.
- Never include secrets in PUBLISH.md.
