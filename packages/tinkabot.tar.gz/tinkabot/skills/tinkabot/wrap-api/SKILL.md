---
name: wrap-api
description: "Use when wrapping an HTTP API or OpenAPI/spec into a local MCP + Hermes skills."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "tinkabot"}}
---

# Wrap an API as a local MCP + Hermes skills

Goal: a local pack the user can load in Hermes — an MCP server over stdio plus skill files that call it. Prefer the smallest scaffold that works. Prove it next with prove-local. Do not publish from this skill.

Working folder: `~/.hermes/profiles/tinkabot/workspace` (absolute paths). Packs live in `wraps/<slug>/`. Never overwrite; move an older pack to `archive/<slug>-<timestamp>/` first.

## Intake (one at a time; skip what the first message already answers)

1. What API or service? (base URL, OpenAPI/spec URL or file, or a wrap-X request)
2. What should Hermes be able to do with it in one sentence?
3. Auth: none / API key in env / bearer / other? Never store secrets in the pack; name the env var only.
4. Pack slug (lowercase letters, digits, hyphens). Suggest one from the service name.
5. Any endpoints or tools that must ship on day one?

## Name the data shape first

Before writing files, state in plain words:

- Resources and their key fields
- The tools Hermes needs (name, inputs, outputs)
- Errors the server should surface

Show that shape to the user in a short list. Adjust once if they correct it. Then scaffold.

## Scaffold (smallest sufficient)

Create `wraps/<slug>/` with only what the job needs:

1. `README.md` — one paragraph what it wraps, how to load locally, and that publish is out of scope until they name a destination.
2. `mcp.json` (or the Hermes MCP entry shape the runtime expects) — stdio command pointing at the local server script. No remote URLs as the default transport.
3. `server/` — a small stdio MCP server.
   - Public no-auth HTTP APIs: zero extra dependencies. Use the language stdlib (Python urllib / http.client, or Node built-ins) until an SDK earns its install.
   - Auth or complex protocols: add the smallest dependency that is justified, and document the env var for the secret. Never commit the secret.
4. `skills/<tool-or-job>/SKILL.md` — real steps that call the MCP tools. Front matter: `name` matches folder, `description` starts with `Use when`.
5. Optional `schema/` or OpenAPI copy the user supplied, kept read-only for reference.

Do not add marketplace manifests, plugin marketplaces, editor plugin roots, or publish config in this step.

## Quality bar

- One job per pack. No leftover tools. No stub skills.
- Prove it works is next (prove-local), not optional.
- Prefer the smallest scaffold: fewer files, fewer deps, clear tool names.
- Shipped pack files never name other agent platforms, plugins, marketplaces, or creators.

## Handoff from this skill

Show: slug, folder path, tools list, data shape in one short block, auth env var if any. Then run prove-local (or tell the user you are about to) before calling the wrap done.
