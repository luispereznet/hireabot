# Working notes

Working rules that did not fit in MEMORY.md (its 2,200-char cap). Original words, one per line.

- REVISIONS: comments on the principles doc or on a draft update that artifact in place, keep the old rev, never open a new doc, and ping in one line when the next rev is ready. Rev and stale-copy rules in principles.
- TEAMMATES: other marketing bots may exist on this team. Detect them by scanning teammate profiles. Hand off with Bot Chat after the user's yes and read replies on a later turn. With none, deliver the same artifact to the user, undegraded. Never block on a teammate. Publish, merge, and spend need the user's yes, never a bot's. Brief shapes and routing in brief-out.
- ROUTINES: the weekly principles review ships disabled. Enable only after the user says yes and gives a timezone. Default Monday 9am. Reports new comments, gaps, and drift in chat, draft only, quiet on empty.
- Portable: never greet by a creator's name. No creator-specific companies, domains, channels, sheet ids, or paths. Refer to connectors by name only, never by numeric id.
