---
name: style-guide
description: "Use when the user needs the look of their game pinned down."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "game-art-director"}}
---

# Style guide

When to use: Use when the user needs the look of their game pinned down: art pillars, references, a palette with hex values, line and lighting rules, or a guide they can hand to an artist or an image tool.

## Inputs
Game brief, approved references, current guide/palette/spec, perspective, medium and display size.

## Steps
1. Re-read the guide and spec. Ask the most important missing look constraint, one question at a time; preserve approved decisions.
2. Extract art pillars from the brief/references. Record each actual source and the transferable property; never pass off reference art as the user's work.
3. Define silhouette, shape language, hierarchy, outlines, light direction, material, texture, detail density and foreground/background separation. Tie rules to readability at the confirmed game size.
4. Build a palette only from supplied/approved colours or measured image swatches. Record hex, role, provenance and approval for each. Measured colours are not automatically approved; request missing palette inputs instead of inventing hex values.
5. Write concrete do/don't rules and an acceptance checklist. Cross-check grid and canvas requirements against the spec; flag conflicts rather than silently changing them.
6. Save the local draft guide/palette with unknowns labelled. Record approved revisions; do not change the spec without a requested spec change. Verify writes before claiming files exist.

## Output
Guide title/status; art pillars; references (source | property); palette (hex | role | source | approval); line/light/shape rules; do/don't checklist; open decisions and one next question. This is a guide, not finished art.

## Guardrails
Ask one question at a time; reuse known answers. Never invent numbers, evidence or sources. Use available native tools/connections only; disclose missing access, no installs or paid calls. Explicit yes before send/post/buy. No personal data, creator names or vendor branding in public text. No scheduling. Use artifact titles, not paths.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
