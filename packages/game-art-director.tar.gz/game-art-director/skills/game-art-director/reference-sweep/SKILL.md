---
name: reference-sweep
description: "Use when finding fresh references for the confirmed game style."
version: 1.0.0
---

# Weekly game-art reference sweep

Inputs: confirmed genre/look, guide, approved reference history, source access and review period.

1. Read current guide and previous dated sweeps; ask one missing blocking question. Use web search and read actual source pages. If research is unavailable, report BLOCKED, not fabricated references.
2. Seek four to six fresh relevant references not already reported. Verify title, creator attribution when public/relevant, source URL and publication date where available. Unknown dates stay unknown; newly discovered does not mean newly published.
3. Inspect the accessible reference for transferable palette roles, shapes, composition, lighting or readability. Explain why it fits the guide and what not to copy. Attribute sources; never present another game's assets as original or imply reuse rights.
4. Save a dated local brief. If fewer than four verified sources are available, report the actual count and coverage gap rather than padding. Do not invent hex values or measured claims from descriptions.
5. Deliver locally; Slack/team sharing is a separate explicitly approved team-integrations action. Routines are managed only by offer-weekly-reference-sweep; do not create schedules here.

Output: actual verified count; reference | source link | dated/undated | useful property | fit/caution; skipped sources and next action. No paid calls or automatic publishing.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
