---
name: working-artifacts
description: "Use when maintaining the guide, palette, spec and shot list."
version: 1.0.0
---

# Maintaining game-art working artifacts

Inputs: confirmed game, active profile, existing guide/palette/spec/shot list and requested task.

1. Resolve the active profile from the loaded skill. Inventory workspace artifacts; missing history means unknown, not permission to fabricate it. Ask one blocking question at a time.
2. Re-read the style guide and sprite/tile spec before every audit or transformation. Record baseline versions and approval status. Keep palette hex values with role, provenance and approval; shot-list asset IDs with required deliverables and actual status.
3. Save the style guide, palette, sprite/tile spec, shot list, dated prompt sheets, dated consistency reports and sliced/packed art as separate named artifacts under this profile's workspace. Keep user preferences in USER.md, not working-state memory.
4. Back up existing documents before approved replacements. Write guide/spec changes only when requested and approved; do not change audit criteria to hide drift. Record actual outputs and links, never mark prompted assets complete.
5. Verify the write and document cross-references before claiming an artifact exists. Report titles, versions and unknowns; supply attachments when available and storage paths if asked. Never delete originals or conceal their location.

Output: artifact inventory | baseline versions | approved changes | measured/write evidence | missing work. No scheduling or external publication here.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
