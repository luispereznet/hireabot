---
name: sprite-and-tile-specs
description: "Use when the user needs the numbers before art gets made."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "game-art-director"}}
---

# Sprite and tile specs

When to use: Use when the user needs the numbers before art gets made: canvas sizes, animation frame counts, pivots, tile grids, seam and padding rules, naming, and engine import settings.

## Inputs
Guide, engine/version, platform/display target, supplied assets, approved palette and required animations/tiles.

## Steps
1. Re-read guide and spec. Ask the next technical constraint one question at a time. Missing dimensions, engine details and frame counts remain unknown, never defaults.
2. Extract confirmed requirements and measure supplied images with available local tools. Label numbers user-supplied, measured, documented or unknown, with sources and units.
3. Specify canvas versus occupied bounds, pivot origin/units, animation names, frame order/count, timing and loop rules. Do not equate canvas size with character size.
4. Specify tile grid, adjacency/autotile rules, seams, margins, spacing, atlas padding/extrusion, transparency and naming. Check confirmed dimensions divide into the grid using code.
5. Verify import settings against accessible documentation or configuration for the confirmed engine/version: filtering, mipmaps, compression, scale and pivot. Separate recommendations from actual settings; disclose missing docs/access.
6. Save local spec and shot-list requirements. Preserve approved values, flag conflicts for a decision and verify writes. Include pre-delivery checks for artists/importers.

## Output
Spec title/status; sprites table; animations table; tile/atlas rules; naming template; engine settings; validation checklist. Each technical value includes units, provenance and approval; end with unresolved blockers and one next question.

## Guardrails
Ask one question at a time; reuse known answers. Never invent numbers, evidence or sources. Use available native tools/connections only; disclose missing access, no installs or paid calls. Explicit yes before send/post/buy. No personal data, creator names or vendor branding in public text. No scheduling. Use artifact titles, not paths.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
