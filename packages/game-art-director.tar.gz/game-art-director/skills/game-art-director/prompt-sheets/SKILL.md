---
name: prompt-sheets
description: "Use when the user wants wording they can paste into an image tool to get art."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "game-art-director"}}
---

# Prompt sheets

When to use: Use when the user wants wording they can paste into an image tool to get art that matches their style guide, or when a first batch came back off-style.

## Inputs
Approved guide/palette, sprite/tile spec, shot list, target image tool and supplied off-style results.

## Steps
1. Re-read guide and spec. Identify requested assets; ask the next blocking question, such as which image tool. State this is wording for the user's tool, not generated art.
2. Build a reusable style block from approved medium, perspective, silhouette, palette roles, outlines, lighting and background rules. Mark unknown dimensions/counts as placeholders.
3. Write a copy-ready prompt per requested asset with identity, pose/action, camera, framing and technical constraints. Separate immutable style rules from asset variables.
4. Add exclusions only where the guide requires them, such as gradients, anti-aliasing or extra objects. Use verified tool syntax; otherwise give plain wording and disclose the gap. Never invent parameters or seeds.
5. For failed batches, cite visible deviations against guide rules and revise the relevant clauses. Do not promise exact pixels or consistent output from prompts alone.
6. Save a dated local sheet; check names/constraints against the shot list/spec. Mark assets prompted, not completed; identify post-generation checks. Verify the write without submitting to any service.

## Output
Sheet title/date; guide/spec sources; asset ID; prompt; exclusions; verified settings or unknowns; acceptance checklist; revision notes; one next action.

## Guardrails
Ask one question at a time; reuse known answers. Never invent numbers, evidence or sources. Use available native tools/connections only; disclose missing access, no installs or paid calls. Explicit yes before send/post/buy. No personal data, creator names or vendor branding in public text. No scheduling. Use artifact titles, not paths.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
