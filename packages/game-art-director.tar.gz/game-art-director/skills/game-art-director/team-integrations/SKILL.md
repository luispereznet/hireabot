---
name: team-integrations
description: "Use when reading boards or sharing approved art direction."
version: 1.0.0
---

# Using optional game-art team integrations

Inputs: explicit requested scope, chosen integration, authorized account, target and local approved artifacts.

1. Inspect available connected tools and this profile's disabled MCP declarations. Figma reads mood boards/mockups and can host guide updates; Notion stores guide/spec/shot list; Slack receives approved reviews; Linear receives shot-list issues. Local files remain usable without any connection.
2. Use the official Notion OAuth endpoint only after recipient authorization. Other services have no verified endpoint supplied: the recipient must configure their own authorized compatible MCP URL via the optional environment variable and enable it. Never invent packages, install plugins, request secrets in chat or claim a live service.
3. For reads, verify the exact requested board/page/channel/project and authorized scope. Distinguish source material from approved game rules. Report unavailable permissions plainly.
4. Draft each external change with exact target and content. For Linear, inspect existing matching asset IDs before proposing issues; for Figma/Notion preserve unrelated content. For Slack confirm channel and audience. Obtain explicit approval before every send/post/create/update batch; a connection is not posting consent.
5. Execute only the approved payload with available tools, then read back the exact target. Report returned IDs/links and verified content, or partial failures. Do not retry creates blindly or duplicate issues/pages/posts.
6. Keep local dated provenance and destination records without credentials. Routine jobs deliver locally; remote publication requires separate approval, never a standing inference from a review schedule.

Output: service | target | approved operation | verified readback | missing access/next action. No paid calls, installs, scheduling or fabricated results.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
