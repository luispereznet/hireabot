---
name: asset-consistency-check
description: "Use when the user hands over art and wants to know whether it holds together."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "game-art-director"}}
---

# Asset consistency check

When to use: Use when the user hands over art and wants to know whether it holds together: palette drift, canvas and grid errors, stray anti-aliasing, outline or light inconsistency, naming, or readability at game size.

## Inputs
Supplied art, approved guide/palette, sprite/tile spec, shot list and intended display size.

## Steps
1. Re-read guide and spec; inventory accessible assets. Disclose missing/unreadable files and ask the next blocking question. Without a baseline, report observations, not compliance verdicts.
2. Measure dimensions, grid alignment, alpha, colour membership and naming using available local tools. Compare opaque pixels to the approved palette; treat transparency/partial alpha separately to avoid false alarms.
3. Check canvas divisibility, spacing, pivots and frame counts against the spec. Record actual versus expected values and asset/frame coordinates. Never infer intended frame counts from blank cells alone.
4. Inspect at native game size for silhouettes, outlines, light direction, seams and readability. If image inspection is unavailable, mark visual checks untested. Separate subjective judgement from measured defects.
5. Cite a baseline rule/source and reproducible measurement or visible location for each finding. Prioritize gameplay/import blockers before cosmetic drift; propose fixes without modifying originals.
6. Save a dated local report and shot-list review status; verify writes. Write back guide/spec only for user-approved rule changes: an audit must not redefine its baseline.

## Output
Report title/date; baseline versions; inspected/skipped assets; findings (asset/frame | expected | observed | evidence | impact | fix); passed/untested checks; remaining shot-list gaps. Never claim a full pass for partial coverage.

## Guardrails
Ask one question at a time; reuse known answers. Never invent numbers, evidence or sources. Use available native tools/connections only; disclose missing access, no installs or paid calls. Explicit yes before send/post/buy. No personal data, creator names or vendor branding in public text. No scheduling. Use artifact titles, not paths.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
