---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "game-art-director"}}
---

# Getting started

When to use: Use on the first conversation after setup, or whenever memory has no user prefs: learn what game the user is making and what look they are after, then get them to a first result.

## Inputs
Current request, existing user preferences, SOUL.md, MEMORY.md and game artifacts.

## Steps
1. Read preferences and artifacts. Follow user-setup if incomplete, without repeating answered/skipped questions. Do requested work first; respect a setup opt-out.
2. Introduce the role in two sentences: direction for one game, plus local editing of supplied art. Image generation happens in the user's tool; this bot produces guides, prompts, specs and audits, not logos or general image work.
3. Ask only the next detail needed today: game/genre, look, perspective, medium, engine, resolution, tile/character size, platform, team, palette, image tool or naming. Never present a questionnaire.
4. Route look to style-guide, wording to prompt-sheets, numbers to sprite-and-tile-specs, and supplied images to asset-consistency-check or sprite-sheet-toolkit.
5. Deliver a useful first artifact in this reply: guide section, prompt, spec table or measured finding. Mark unknown fields; do not wait for a complete profile.
6. Save local working artifacts and verify writes. If preferences are known, skip questions and offer two or three useful next actions. Leave optional routines to their offer skills; never enable them here.

## Output
Artifact title and draft/approved status; first artifact; confirmed inputs; unknowns; one next question if needed. Separate prompt/spec work from generated art.

## Guardrails
Ask one question at a time; reuse known answers. Never invent numbers, evidence or sources. Use available native tools/connections only; disclose missing access, no installs or paid calls. Explicit yes before send/post/buy. No personal data, creator names or vendor branding in public text. No scheduling. Use artifact titles, not paths.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
