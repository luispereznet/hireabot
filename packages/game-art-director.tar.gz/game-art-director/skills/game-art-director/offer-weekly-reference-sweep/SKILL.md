---
name: offer-weekly-reference-sweep
description: "Use after setup or when asked about routines: offer weekly reference sweep."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "game-art-director"}}
---

# Offer the weekly reference sweep

Inputs: explicit consent, approved game scope, active profile, recipient day/time/timezone and shipped job 573853ec5d04.

1. Offer once after setup or on request; read this profile's workspace/routine-choice-weekly-reference-sweep.md first. A recorded decline stays declined unless the user asks again. No clear yes means leave paused. Never create a job.
2. Verify guide/spec and new-art access for an art review, or confirmed genre/look and real web access for a reference sweep. Missing tools/connections mean BLOCKED. Ask one blocking question at a time.
3. Resolve this profile from the loaded skill's ancestor containing SOUL.md and skills/. Use its actual imported name and containing Hermes root for HERMES_HOME; never assume the original slug. Inspect native cron list. Match stable ID 573853ec5d04 and inspect equivalent jobs. If absent or duplicated, report the problem and ask for approved repair; never create a replacement.
4. Explain the saved weekly schedule is only an unapproved Monday 09:00 host-clock example, local delivery and future model usage/cost. Confirm desired weekly day/time/timezone, inspect the host timezone and account for DST. If different, consult installed cron help for supported update syntax and change this same paused job only with approval; if unavailable, stay paused and request repair. Verify schedule readback before enabling.
5. Only after explicit approval and verified prerequisites, resume the matching job via native cron resume 573853ec5d04 in this profile. List again and verify enabled/scheduled state and correct schedule. Never use cron run as a preview; it may enable and execute a paused job.
6. For explicit pause/cancel, pause 573853ec5d04, list again and verify disabled/paused. Never delete the definition. Record actual ID, consent, scope, timezone and verified state in this profile's workspace. No duplicate creates or unsupported success claims.

Output: actual ID | scope | confirmed schedule/timezone | read-back state | remaining blocker. No paid calls during setup; no posting or external delivery without separate explicit approval.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
