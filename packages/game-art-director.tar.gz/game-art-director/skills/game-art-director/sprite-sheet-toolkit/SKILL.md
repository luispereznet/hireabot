---
name: sprite-sheet-toolkit
description: "Use when the user has sprite sheets or loose frames that need slicing."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "game-art-director"}}
---

# Sprite sheet toolkit

When to use: Use when the user has sprite sheets or loose frames that need slicing, packing, renaming, rescaling, or turning into an atlas their engine can read.

## Inputs
Source sheets/frames, approved grid/spec, frame order, pivots, requested operation and target atlas format.

## Steps
1. Inspect originals using available local tools and read the spec. Ask one blocking question at a time. Disclose missing image/atlas tools; do not present a recipe as exported assets.
2. Measure dimensions/alpha. Resolve cell size, margins, spacing, blank cells and frame order from the spec or user. Verify grid divisibility with code; stop on ambiguous cuts.
3. Build a dry-run manifest of source rectangles, output names and order. For packing record padding; for trimming record offsets, original canvas and pivot. Flag naming collisions; keep originals intact.
4. Write requested transforms to new outputs: slice/pack, rename, nearest-neighbour whole-number scaling, or requested recolouring to an approved palette. Never smooth pixel art, lose pivot metadata or silently drop blank animation frames.
5. Export metadata in the confirmed engine format with coordinate convention and pivots. If support cannot be verified, label it generic metadata, not engine-ready.
6. Reopen outputs; use code to verify count against manifest, dimensions, alpha, palette, frame order, overlaps and bounds. Check seams if image inspection is available; preview animation only with known timing. Mark untested checks and failures.

## Output
Export title; operation/settings; source-to-output manifest; atlas rectangles and pivot/trim metadata; measured validation results; skipped checks. Claim completion only for written, reopened assets; provide local attachments where supported.

## Guardrails
Ask one question at a time; reuse known answers. Never invent numbers, evidence or sources. Use available native tools/connections only; disclose missing access, no installs or paid calls. Explicit yes before send/post/buy. No personal data, creator names or vendor branding in public text. No scheduling. Use artifact titles, not paths.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
