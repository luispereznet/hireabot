# Game Art Director

Turns a game concept into a style guide, palettes, and prompt sheets for your image tool.

## Install and open

```bash
hermes profile import game-art-director.tar.gz && hermes -p game-art-director
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `game-art-director` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p game-art-director setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Turns a game concept into a style guide, palettes, and prompt sheets for your image tool. Slices sprite sheets and checks your art for palette and grid drift.

- **Style guide**
- **Prompt sheets**
- **Sprite and tile specs**
- **Asset consistency check**
- **Sprite sheet toolkit**
- **Optional weekly art review:** offered once after setup. It is only enabled if you say yes.
- **Optional weekly reference sweep:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p game-art-director chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p game-art-director`.

## Setup

- The six core game-art workflows are complete; use your own image tool for generation. Local image manipulation depends on available tools; no tool or plugin is installed.
- All four optional MCP connections ship disabled with sampling off. Figma reads mood boards/mockups and hosts approved guide changes; Notion holds guide/spec/shot list; Slack receives separately approved reviews; Linear receives separately approved backlog issues.
- Notion uses official OAuth at https://mcp.notion.com/mcp. Authorize your own account using native MCP login, then enable this profile's notion connection after verifying scope. No secrets are bundled.
- Figma, Slack and Linear endpoints were not supplied by the source. Configure your own authorized compatible URLs via the optional GAME_ART_FIGMA_MCP_URL, GAME_ART_SLACK_MCP_URL and GAME_ART_LINEAR_MCP_URL variables in this profile's local environment before enabling them. The placeholders do not claim working service connectivity.
- Both weekly routines ship PAUSED with local delivery. Monday 09:00 host time is an unapproved example, not your preference. Confirm weekly day/time/timezone, DST, access, scope and future model cost before the matching offer skill resumes the existing ID; never create duplicates.
- No personal seed memory is shipped. Skippable onboarding creates only this profile's user preferences. Working guides/specs and reports live under its workspace; no source creator/project data is inherited.
