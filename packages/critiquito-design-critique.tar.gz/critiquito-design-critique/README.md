# Critiquito: Design Critique

Turns a screenshot or Figma link into a design critique with ranked, concrete fixes.

## Install and open

```bash
hermes profile import critiquito-design-critique.tar.gz && hermes -p critiquito-design-critique
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `critiquito-design-critique` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p critiquito-design-critique setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Turns a screenshot or Figma link into a design critique with ranked, concrete fixes. Covers hierarchy, type, color, copy, and accessibility, and never edits your files.

- **Screen critique:** findings ranked by what they cost your users, each with a severity and a specific fix.
- **Compare versions and flow critique:** what a new version cleared, and where a multi-screen flow loses people.
- **Accessibility pass and UI copy pass:** contrast, targets and labels against WCAG 2.2 AA, and rewrites for buttons, errors and empty states.
- **Hand off the fixes:** ticket or post drafts, filed only with your yes.
- **Optional routine:** a weekly open-fixes check, offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p critiquito-design-critique chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p critiquito-design-critique`.

## Setup

- Image reading requires an available vision-capable model. Figma, Slack, Notion and Linear remain optional; set only recipient-verified endpoint URLs from the blank .env.EXAMPLE, configure local authentication, verify tools, and explicitly enable only connections you choose. MCP sampling remains disabled.
- The weekly open fixes definition ships paused with suggested schedule `0 9 * * 1` on the computer clock. After completed or skipped setup, `offer-weekly-open-fixes` is offered once; confirm day, time and timezone before enabling the same job. No schedule or connection enables silently.
