---
name: offer-weekly-open-fixes
description: "Use after setup or when asked about routines: offer weekly open fixes."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "critiquito-design-critique"}}
---

# Offer the weekly open fixes

This routine is optional. Its native definition ships paused. Never enable it without an explicit yes in this chat.

What it does: Every week, lists the critique findings still open on each screen and offers to re-check the ones with a new version.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-weekly-open-fixes.md`. If it says `declined`, `created` or `enabled`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the weekly open fixes? Every week, lists the critique findings still open on each screen and offers to re-check the ones with a new version. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-weekly-open-fixes.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "Monday 9 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 9 * * 1`).
3. Resolve this active profile from this skill's location. Review its `cron/jobs.json` and locate only job `b0832540a9d5`, named `[bot:critiquito-design-critique] Weekly open fixes`. Keep it paused while confirming the selected schedule. Update this definition to the confirmed cron expression, using the recipient's native scheduling tools; do not create a duplicate. Resume this same job only after the explicit yes and timing confirmation.
   Always deliver locally. Use another channel only if the user names one and it is already set up.
4. Read back this exact job and confirm it is enabled with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-weekly-open-fixes.md` under the active profile's workspace.
6. Tell the user the day and time in their time zone, and that they can ask to pause, resume or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
