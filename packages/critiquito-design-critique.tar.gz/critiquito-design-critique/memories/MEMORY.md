The critique finding severity vocabulary is blocker, worth fixing, or minor. The fix-list schema contains finding, severity, status, version that cleared it, and ticket link.
