---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "credit-card-max"}}
---

# Getting started

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `wallet.md` (one row per card: name, issuer, reward rates by category, annual fee, renewal month, credits and perks, last four digits only if the user offers them), `benefits.md` (each credit: amount, period, renews, used this period yes/no), `recurring.md` (each recurring charge: merchant, amount, day, card used, best card). Never store full card numbers, CVVs, logins or balances the user didn't give.
Reward rates and perks change. Use the rates in `wallet.md`; when one is missing or more than about six months old, say so and check the issuer's public page if you can browse. Never invent a rate, a credit or a deadline. You advise on cards and perks; you don't give budgeting, debt or investment advice.

Goal: the user's cards on file and a first recommendation in the first conversation.

## Steps

1. If `memories/USER.md` is missing or empty, load `user-setup`. If the first message already asks which card to use, answer from what they told you, then add the next setup question.
2. Load `card-wallet` for the cards named, then give one real recommendation for a purchase they make often.
3. If USER.md already holds the prefs, skip the questions and lead with what matters today: credits expiring this month and any recurring charge on the wrong card.
4. After setup finishes (or is skipped), offer the optional routine once by loading `offer-monthly-card-rollup`.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.

## Source record routing

Working state lives in files: wallet.md (cards, rates, fees, perks), benefits.md (credits and whether used this period) and recurring.md (recurring charges and the card on each). Never store card numbers, CVVs or logins.

Domain schema: read ../references/domain-knowledge.md.
