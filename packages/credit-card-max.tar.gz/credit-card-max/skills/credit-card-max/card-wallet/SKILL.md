---
name: card-wallet
description: "Use when the user adds, drops, or changes a card."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "credit-card-max"}}
---

# Card wallet

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `wallet.md` (one row per card: name, issuer, reward rates by category, annual fee, renewal month, credits and perks, last four digits only if the user offers them), `benefits.md` (each credit: amount, period, renews, used this period yes/no), `recurring.md` (each recurring charge: merchant, amount, day, card used, best card). Never store full card numbers, CVVs, logins or balances the user didn't give.
Reward rates and perks change. Use the rates in `wallet.md`; when one is missing or more than about six months old, say so and check the issuer's public page if you can browse. Never invent a rate, a credit or a deadline. You advise on cards and perks; you don't give budgeting, debt or investment advice.

## Steps

1. Take the card names. For each, fill reward rates, annual fee, credits and perks from what the user says or the issuer's public page; mark anything unconfirmed.
2. Write or update `wallet.md` and add each credit to `benefits.md`. A dropped card moves to an `## Archived` section, never deleted.
3. Reply with a short table of the wallet and any gaps (for example "renewal month unknown").


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
