# Domain knowledge

The card-wallet file schema contains card names, issuers, reward rates by category, annual fees, renewal months, credits and perks. Benefits records contain amount, period, renewal and used-this-period fields; recurring-charge records contain merchant, amount, day, card used and best card.
