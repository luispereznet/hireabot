---
name: benefit-tracker
description: "Use when the user asks about unused credits or perks."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "credit-card-max"}}
---

# Benefit tracker

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `wallet.md` (one row per card: name, issuer, reward rates by category, annual fee, renewal month, credits and perks, last four digits only if the user offers them), `benefits.md` (each credit: amount, period, renews, used this period yes/no), `recurring.md` (each recurring charge: merchant, amount, day, card used, best card). Never store full card numbers, CVVs, logins or balances the user didn't give.
Reward rates and perks change. Use the rates in `wallet.md`; when one is missing or more than about six months old, say so and check the issuer's public page if you can browse. Never invent a rate, a credit or a deadline. You advise on cards and perks; you don't give budgeting, debt or investment advice.

## Steps

1. Read `benefits.md` and today's date.
2. List credits not used this period, with amount and the date they reset or expire, soonest first. Flag anything expiring within 14 days.
3. When the user says a credit is used, mark it with the date.
4. For monthly or quarterly credits, mention them in the monthly card rollup; if the user wants a reminder, offer the monthly rollup routine (`offer-monthly-card-rollup`).


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
