---
name: monthly-card-rollup
description: "Use when the user asks for the monthly review."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "credit-card-max"}}
---

# Monthly card rollup

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `wallet.md` (one row per card: name, issuer, reward rates by category, annual fee, renewal month, credits and perks, last four digits only if the user offers them), `benefits.md` (each credit: amount, period, renews, used this period yes/no), `recurring.md` (each recurring charge: merchant, amount, day, card used, best card). Never store full card numbers, CVVs, logins or balances the user didn't give.
Reward rates and perks change. Use the rates in `wallet.md`; when one is missing or more than about six months old, say so and check the issuer's public page if you can browse. Never invent a rate, a credit or a deadline. You advise on cards and perks; you don't give budgeting, debt or investment advice.

## Steps

1. Read `wallet.md`, `benefits.md` and `recurring.md`.
2. Report: credits unused last month and still open this month, renewals and annual fees due in the next 60 days (with a keep-or-downgrade note), recurring charges on the wrong card, and points or utilization figures only if the user gave them.
3. Save to `rollups/<YYYY-MM>.md` and show it. Ask before changing any file.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
