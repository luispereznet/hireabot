# Credit Card Max

Tells you which of your credit cards to use for each purchase to get the most points, cash back and perks.

## Install and open

```bash
hermes profile import credit-card-max.tar.gz && hermes -p credit-card-max
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `credit-card-max` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p credit-card-max setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Tells you which of your credit cards to use for each purchase to get the most points, cash back and perks. Tracks your cards, unused credits and recurring charges on the wrong card.

- **Best card for a purchase:** the top card with its earn, plus the other reasonable options and when they win.
- **Card wallet:** your cards, reward rates, fees and perks in one file. Card names only; never card numbers.
- **Benefit tracker:** unused credits and the dates they reset, soonest first.
- **Recurring charge check:** subscriptions and bills on the wrong card, with the yearly difference.
- **Optional routine:** a monthly card rollup on the 1st, offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p credit-card-max chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p credit-card-max`.

## Setup

- No bank or card-account connection is included. Supply card names and charges; browse public issuer pages only when available.
- The monthly card rollup definition ships paused with suggested schedule `0 9 1 * *` on the computer clock. After completed or skipped setup, `offer-monthly-card-rollup` is offered once; confirm day, time and timezone before enabling the same job. No schedule or connection enables silently.
