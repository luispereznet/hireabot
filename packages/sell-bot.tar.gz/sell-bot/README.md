# Sell Bot

Works your whole customer journey: outreach in your voice, booked calls with prep and follow-ups, proposals and contracts, then activation, support and billing 

## Install and open

```bash
hermes profile import sell-bot.tar.gz
hermes -p sell-bot setup
hermes -p sell-bot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `sell-bot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Works your whole customer journey: outreach in your voice, booked calls with prep and follow-ups, proposals and contracts, then activation, support and billing answers, and expansion. Drafts everything for your review and sends only what you approve, one message at a time.

- **Sell setup**
- **Accounts**
- **Draft email**
- **Schedule**
- **Watch on x**
- **Prep page**
- **Call wrap**
- **Follow through**
- **Account watch**
- **Support desk**
- **Proposal desk**
- **Optional morning prep:** offered once after setup. It is only created if you say yes.
- **Optional confirm notes:** offered once after setup. It is only created if you say yes.
- **Optional evening wrap-up:** offered once after setup. It is only created if you say yes.
- **Optional daily follow-through:** offered once after setup. It is only created if you say yes.
- **Optional daily account watch:** offered once after setup. It is only created if you say yes.
- **Optional daily prospect follow-up:** offered once after setup. It is only created if you say yes.
- **Optional weekly pipeline review:** offered once after setup. It is only created if you say yes.
- **Optional monday impact read:** offered once after setup. It is only created if you say yes.
- **Optional launch heads-ups:** offered once after setup. It is only created if you say yes.
- **Optional friday writing review:** offered once after setup. It is only created if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Optional routines are offers only: no cron jobs ship. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p sell-bot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p sell-bot`.

## Setup

- No integration is bundled or required. Paste, upload, export, CSV and public-web paths always work; the bot says when a tool is missing.
- Optional services the original workflow used: Gmail, Google Calendar, Granola, Google Sheets, Slack, X. Connect them yourself in Hermes if you want them; keep credentials in this profile's local .env, never in chat.
- Optional routines are offered once after setup and are created only after your explicit yes, in your time zone, delivering locally.
