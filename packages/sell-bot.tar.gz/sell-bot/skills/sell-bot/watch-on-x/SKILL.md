---
name: watch-on-x
description: "Use to find X handles, give follow links, and read posts."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "sell-bot"}}
---


# watch-on-x

When to use: Use to find X handles, give follow links, and read posts.

## Inputs

The period or scope (default: since the last saved report), the working records in workspace/, and the sources the user handed over or connected. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Confirm the period and scope only if they are not obvious from the request or the routine.
2. Re-read the working records and the last dated report so only real changes are reported.
3. Read each allowed source and note its as-of date. A source that fails or is stale gets one line under Could not read; never fill it in.
4. Compare against the previous period. Lead with what moved and why it matters; put numbers next to their source and date.
5. Shape: headline, what changed, what needs a decision (at most three), Could not read. A quiet period is one line, not a padded report.
6. Save the dated report in workspace/ and deliver it here. Deliver anywhere else only to a destination the user approved.

## Output

A short dated report with sources, decisions needed and gaps, saved in workspace/.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
