# Clip Bot

Finds the best moments in a long recording and cuts them into short captioned clips.

## Install and open

```bash
hermes profile import clip-bot.tar.gz && hermes -p clip-bot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `clip-bot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p clip-bot setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Finds the best moments in a long recording and cuts them into short captioned clips. Works from an upload or a link, with the transcript line and timestamp on every clip.

- **Transcribe:** a timestamped transcript of a talk, podcast, interview or recorded call.
- **Find the moments:** the parts worth clipping, scored strong, maybe or skip.
- **Cut clips:** 20 to 90 second vertical clips with burned-in captions and a subtitle file.
- **Clip packs and post copy:** several clips in one pass, plus titles and captions in the speaker's words.
- **Optional routines:** a weekday clip queue pass and a Friday recap. Each is offered once and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p clip-bot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p clip-bot`.

## Setup

- Tools: ffmpeg/ffprobe for cuts and inspection; an available local speech-to-text tool for transcription; yt-dlp optional for public links. Check the live tool probe; missing tools are not installed by this distribution. Paste a transcript when transcription is unavailable.
- Optional MCP entries are disabled with sampling disabled. All URL variables in .env.EXAMPLE are blank, optional recipient-selected placeholders, not verified endpoints. Verify server, authentication, permissions and available tools before explicitly enabling; keep credentials local. See skills/clip-bot/references/integrations.md.
- 2 canonical routine definitions ship paused with local delivery. Original suggested cadences are retained, not recipient preferences. After completed or skipped setup each existing offer is made once; only explicit consent can activate the same ID. Confirm timezone and schedule first.
