# Optional integration setup

All entries ship disabled with sampling disabled. Each URL is an optional recipient-supplied environment reference, not a verified provider endpoint. Choose and verify a compatible MCP server, its authentication and scoped tools before enabling; do not infer access from configuration. Keep secrets local. Read only recipient-authorized sources.

- SLACK_MCP_URL: Optional recipient-verified slack MCP URL; unset means unavailable.
- NOTION_WORKSPACE_MCP_URL: Optional recipient-verified notion-workspace MCP URL; unset means unavailable.
- LINEAR_MCP_URL: Optional recipient-verified linear MCP URL; unset means unavailable.
- FIGMA_MCP_URL: Optional recipient-verified figma MCP URL; unset means unavailable.

Clip Bot never posts or uploads. Blueprint integration descriptions do not authorize sharing or add title-card/multitrack editing workflows. Live local clipping and user publishing remain unchanged.
