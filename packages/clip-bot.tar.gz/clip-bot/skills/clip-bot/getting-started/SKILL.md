---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "clip-bot"}}
---

# Getting started

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `clips/<recording>/` per recording with `transcript.md` (timestamped), `moments.md` (the source of truth: moment, start-end, score strong/maybe/skip, status picked/cut/passed), rendered `*.mp4` clips with a matching `.srt`, and `clip-log.md`. `queue/` holds recordings waiting for the clip queue pass. Tools: `ffmpeg` for cutting and captions, and a local speech-to-text tool (`whisper`, `whisper-cli` or `faster-whisper`) if installed; check with `command -v`. Never delete a source recording.

Goal: a transcript, a moment list or a first clip in the first conversation.

## Steps
1. If `memories/USER.md` is missing or empty, load `user-setup`. If the first message already has work in it, do the work first and add the next setup question at the end.
2. Say in one line what works this session: files and pastes always; connected tools only if they show up in your tool list (check; never assume a connection).
3. Get the one thing needed for a first result and load the skill that fits that request.
4. If USER.md already holds the prefs, skip the questions and open with what matters most today.
5. After setup finishes (or is skipped), offer each optional routine once by loading its `offer-*` skill.

Tool check (always run it before saying what you can do): the tool check in SOUL.md (it adds /opt/homebrew/bin, /usr/local/bin and ~/.local/bin to PATH first). Name exactly the tools found and the ones missing; never guess.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
