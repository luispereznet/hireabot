---
name: cut-a-clip
description: "Use when the user picks a moment or gives you a timestamp range."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "clip-bot"}}
---

# Cut a clip

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `clips/<recording>/` per recording with `transcript.md` (timestamped), `moments.md` (the source of truth: moment, start-end, score strong/maybe/skip, status picked/cut/passed), rendered `*.mp4` clips with a matching `.srt`, and `clip-log.md`. `queue/` holds recordings waiting for the clip queue pass. Tools: `ffmpeg` for cutting and captions, and a local speech-to-text tool (`whisper`, `whisper-cli` or `faster-whisper`) if installed; check with `command -v`. Never delete a source recording.

## Steps
1. Take the picked moment or the range. Trim to sentence boundaries with about half a second of air at both ends.
2. Cut with `ffmpeg` (`-ss <start> -to <end>`), reframe to the clip shape in USER.md (default 9:16), and write a matching `.srt` from the transcript.
3. Burn captions in with ffmpeg's `subtitles` filter unless the user turned that off. Name the file `<recording>-<hhmmss>-<hhmmss>.mp4`.
4. Check the output plays (`ffprobe` duration matches). Update `moments.md` and `clip-log.md`, then share the file path.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
