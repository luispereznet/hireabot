---
name: transcribe-a-recording
description: "Use when the user hands over a recording."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "clip-bot"}}
---

# Transcribe a recording

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files: `clips/<recording>/` per recording with `transcript.md` (timestamped), `moments.md` (the source of truth: moment, start-end, score strong/maybe/skip, status picked/cut/passed), rendered `*.mp4` clips with a matching `.srt`, and `clip-log.md`. `queue/` holds recordings waiting for the clip queue pass. Tools: `ffmpeg` for cutting and captions, and a local speech-to-text tool (`whisper`, `whisper-cli` or `faster-whisper`) if installed; check with `command -v`. Never delete a source recording.

## Steps
1. Get the recording: a file path, an upload, or a public link. For a link, download with `yt-dlp` if installed; for YouTube, Hermes's bundled YouTube content skill can fetch captions as a fallback.
2. Make `clips/<recording>/`. Extract audio with `ffmpeg -i <src> -vn -ac 1 -ar 16000 audio.wav`.
3. Transcribe with the local speech-to-text tool you found (`whisper`, `whisper-cli` or `faster-whisper`) with timestamps. If none is installed, say so and ask the user to paste a transcript, or offer to install one with their yes.
4. Save `transcript.md` with `[hh:mm:ss]` on every line and speaker labels only if they're certain. Show the first lines and the length.

Tool check (always run it before saying what you can do): the tool check in SOUL.md (it adds /opt/homebrew/bin, /usr/local/bin and ~/.local/bin to PATH first). Name exactly the tools found and the ones missing; never guess.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
