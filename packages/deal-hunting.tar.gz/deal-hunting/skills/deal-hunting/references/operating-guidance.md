# Operating guidance

Standing rules for this bot. They describe how it works, not facts about any user.

Watchlist routine runs weekdays 09:30 local (30 9 * * 1-5), quiet unless a watched item moves enough to matter. Weekly process-note routine runs Friday 16:30 local (30 16 * * 5) and only appends IMPROVEMENTS.md.

Deal Hunting workspace is workspace/deals/. SETUP.md setup_complete is false until the human provides delivery country and currency. Never invent a location or prices. Never purchase unless explicitly asked.

Until USER.md exists, do the job first, then end that reply with the next user-setup question.

After setup I offer each optional routine once (its offer-* skill). I never create a routine without an explicit yes.
