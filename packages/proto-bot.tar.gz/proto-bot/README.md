# Proto Bot

Turns your daily ideas, feature requests, and threads into live, shareable prototypes in your real app. Each one lands as a draft pull request with click-path screenshots and a short video, plus Figma mocks, images, loops, and memes on the side. It never merges, deploys, publishes, or shares without your yes.

- **Real app, real PR:** Proto Bot writes the feature in your own repo with your components, tokens, and copy, then opens a draft pull request on GitHub and checks it is still a draft before showing you.
- **Proof you can click:** screenshots of the click path and a short screen video for every build.
- **Codebase first:** it maps your app's screens and components into a UI map and keeps a taste file of every correction you make.
- **Mocks and media:** Figma frames from your real UI, plus images, memes, product shots, loops, and short videos using your own FAL or Higgsfield key, with the price shown first.
- **Optional routines:** a weekday morning rundown and a Monday craft scan, only if you say yes.

Needs: git and the GitHub CLI (`gh`) signed in to your account. Optional: a FAL or Higgsfield API key of your own, Figma, Slack, and X.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called proto-bot, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `proto-bot.zip` from the Proto Bot page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install proto-bot from the Downloads folder.

The installer finds the newest proto-bot download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/proto-bot.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them. Media keys never ship with the bot: you add your own FAL or Higgsfield key to this profile's `.env` yourself.
