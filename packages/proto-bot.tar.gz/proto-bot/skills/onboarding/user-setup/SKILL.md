---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

# First-start setup for Proto Bot

This bot ships with no facts about its user and no USER.md. The installer adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load`.

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish).

## Steps

1. Run `status`. If it prints DONE, run `finish` (it removes this skill from auto_load if still there) and stop: setup is finished. If the user's message is exactly the installer test "Reply only: READY", reply READY and do nothing else.
2. If the user's message already holds an idea, feature request, or media ask, do that job first, then in the same reply ask the first question below. Keep asking one per reply until the questions are answered or skipped.
3. Say in one line who you are and that a few quick answers help you prototype their way; every question can be skipped. Then ask the questions below **one at a time**.
4. Ask once: "Want me to check what your other Hermes bots on this computer already know about you? I only read their notes about you; I never change them." Only if they say yes, run `scan-others --consent`, show what you found grouped by bot, and keep only the lines they confirm or edit. If they say no, skip it. Never read another profile without that yes, and never write to another profile.
5. Save the answers as JSON ({"<id>": "<answer>"}) in a temporary file, and the confirmed lines from other bots as a JSON list. Run `write --answers <file> [--others <file>] --dry-run`, show the result, then run it without --dry-run. That creates `memories/USER.md` and runs `finish`, which takes `user-setup` out of `skills.auto_load`. If it says the text is over the cap, shorten it together with the user and run it again. Never put a repo token or media key in the answers.
6. Treat an explicit request to skip all setup as a global opt-out, not a skip of only the current question. Stop the questionnaire immediately, including the other-bot scan. Preserve any answers already supplied and add `{"rules": "Setup skipped by the user; ask for a preference only when a job needs it."}` to the answers JSON. Run the same dry-run and write flow from step 5 without asking for confirmation of the opt-out. Then run `status` and require DONE before claiming the skip was saved; if `finish` reported an error, run `finish` again and tell the user plainly if it still fails.
7. Confirm a global opt-out in one short line and ask no replacement setup question. On later jobs, ask only for information genuinely needed to complete that job; do not restart onboarding unless the user requests it. Otherwise, tell the user setup is done, then run the proto-setup skill for the repo, GitHub, and spend check (skip any part they already answered).
8. Last, load `offer-prototype-rundown` and make its one-time offer, then (in a later turn or after they answer) load `offer-craft-scan` and make that offer. Never create a routine without the user's explicit yes.

## Questions

- `name`: What should I call you?
- `timezone`: Which time zone are you in?
- `replies`: How do you like replies: short and to the point, or more detail?
- `role`: What do you do on your team (for example founder, designer, engineer, PM)?
- `main_app`: Which app or product do you want to prototype in most? (I'll ask for the repo during setup)
- `media_default`: For images and video, do you use FAL, Higgsfield, both, or neither for now?
- `spend_cap`: Monthly cap for paid media before I ask you first? I suggest $5.
- `crafts`: Which crafts should I keep up with (for example product video, onboarding flows, memes)?
- `teammates`: Any teammates or other bots I can hand prototypes to by role, like QA or copy? (skip if none)
- `rules`: Any standing rules I must always follow (for example never comment on PRs, always use the staging app)?
