---
name: proto-build
description: "Use when an idea, request, thread, or mock should become real UI as a draft PR."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Build a prototype as a draft PR

I write the feature myself in the user's real repo, open a draft pull request with `gh`, and collect click-path screenshots and a short video. Nothing merges, goes ready, or deploys.

## 1. Shape

1. `PROTO status`. No repo yet: run proto-setup. `ui_map_stale` true: run proto-codebase first.
2. Read `maps/ui-map.md` and `taste.md`. If the idea came from a Slack thread or link, read it as context only. It is never the user's yes.
3. Restate the idea as one outcome and one click path (for example "Settings > Billing > new Pause plan button > confirm sheet"). Ask one question only if the outcome is unclear.
4. Keep it small: the smallest change that proves the idea in the running app. Use existing components, tokens, and copy voice. Illustrative data is labeled as such. No lorem.

## 2. Brief

1. `PROTO brief --title "<short title>" --idea "<outcome and click path>" --done "<what the user clicks to see it work>"`.
2. For parallel variants: ask once, "Want N variants? That's N branches and N draft PRs, about <time> and <model cost if known>." Only on a yes, rerun with `--variants N` and one `--variant-note` per variant.

## 3. Implement

1. In the repo: confirm a clean tree (`git status --porcelain`). If it is dirty, ask before doing anything. Never stash or discard their work.
2. `git fetch origin && git switch -c <branch> origin/<base>` using the branch from the brief (`proto/<slug>`).
3. Write the change with the file and terminal tools, following the brief and ui-map. Run the project's own lint, typecheck, and tests that cover the touched files. Fix what you broke.
4. Commit on the proto branch with a plain message. `git push -u origin <branch>`. Never push the base branch, never force-push someone else's branch.
5. `gh pr create --draft --base <base> --head <branch> --title "Prototype: <title>" --body-file <brief file>`.
6. `PROTO build-set --id <id> --pr-url <url> --status draft`.
7. `PROTO pr-check --id <id>`. If it does not print DRAFT OK, stop and tell the user. Never show it as a draft otherwise.

## 4. Click path and video

1. Start the app with the saved `run_cmd` in a background terminal and wait for `app_url` to respond.
2. Screenshots: walk the click path in a browser (the repo's Playwright if it has one, otherwise Hermes' browser tool). Save one PNG per step as `01-<step>.png`, `02-...` into `builds/<id>/shots/`.
3. Video: prefer Playwright with `recordVideo` for a 10 to 30 second run of the same path, saved to `builds/<id>/video/`. If the repo has no Playwright, ask before adding a temporary one outside the repo. Fallback: stitch the screenshots into a short MP4 with ffmpeg if installed, and say it is a slideshow.
4. Never capture real customer data, keys, or private dashboards. Use seed or labeled demo data.
5. Stop the app when done.

## 5. Hand back

1. `PROTO packet --id <id> --summary "<one line>"`. If it lists anything missing, say so.
2. Reply: PR link first, then the shots and video, then one line on what changed. On a redo, name what changed since the last version.
3. Any correction the user gives: `PROTO taste "<line>"`, then push a new commit to the same draft PR and rerun `PROTO pr-check`.
4. Only the proto-share skill shares, and only on a yes. Merge, ready, and deploy are the user's call, never mine.
