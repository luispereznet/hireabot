---
name: proto-media
description: "Use when the user wants images, memes, loops, voiceovers, or short videos."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Media with the user's own FAL or Higgsfield key

Only the user's own FAL or Higgsfield key, from this profile's `.env`. Never another provider's key, never a key pasted in chat, never a built-in image service.

## Before any job

1. `PROTO keys`. Neither set: run proto-connect for FAL or Higgsfield and stop until a key is set.
2. Pick the provider: the user's `media_provider` from status, else whichever key is set.
3. Pick the model from the current list (models change often, check the provider's model page or the latest research playbook):
   - FAL: a Nano Banana or Flux family model for stills and style, a GPT Image family model when exact text matters, Kling or Seedance for motion.
   - Higgsfield: Soul for stills, Seedance for motion.
4. Price first: read the model's listed price, estimate this job (count, length, resolution), and run `PROTO spend-check --cost <usd>`. Exit 2 or above the cap: ask with the number before running. Under the cap: say the price in the same line as the result.

## Safety before upload

- Media upload links are often public. Never upload private screenshots, unreleased customer data, keys, or anything from a private dashboard. Use labeled demo data or a cropped, scrubbed shot, and ask if unsure.
- No realistic likeness, voice clone, or lip-sync of a real person without their consent. Parody remakes of public footage must stay obviously parody.

## Run

1. Product shots and mocks start from the real UI (a fresh screenshot of the app or a Figma frame), never invented UI.
2. Call the provider's HTTP API or its official client with the key from the environment. For FAL: submit to the model's queue endpoint with `Authorization: Key $FAL_KEY`, poll status, then download the result URL. For Higgsfield: use its official API or client with the user's key names.
3. Save every output to `<home>/media/<YYYY-MM-DD>-<slug>.<ext>`. Never overwrite: archive first.
4. `PROTO media-log --provider fal|higgsfield --model <id> --cost <usd> --file <path> --kind image|edit|meme|loop|voice|video`.
5. Check the file exists and opens, then show it first, then one line on what changed and the cost.

## Kinds

- Memes: the app's real screen plus one sharp line. Keep it kind.
- Loops and avatars: 2 to 6 seconds, seamless, small file.
- Voiceovers: the user's own voice only with their consent, otherwise a stock voice they pick.
- Short videos: storyboard 3 to 6 shots first and get a yes before paying for motion.
