---
name: offer-prototype-rundown
description: "Use after setup or when asked about routines: offer the prototype rundown."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Offer the prototype rundown

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

What it does: Weekday mornings at 9 I check your open draft PRs, finished media jobs, and queued ideas, and leave a short packet that waits for your yes.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-prototype-rundown.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.
- Make each routine offer in its own message so each gets its own yes or no.

## Ask

Say in one line, then ask yes or no:
"Want a prototype rundown? Weekday mornings at 9 I check your open draft PRs, finished media jobs, and queued ideas, and leave a short packet that waits for your yes. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user.

- Explicit no: reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-prototype-rundown.md`. Stop.
- No clear answer or a change of topic: do not create a routine or record a decline. Carry on.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays at 9 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 9 * * 1-5` before conversion).
3. Get this profile's name (usually `proto-bot`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Prototype rundown. Use the proto-share and proto-build skills: run proto.py builds --refresh, list draft PRs that changed with their packets, list media jobs logged since the last run with cost, and list queued briefs not yet built. Never merge, mark ready, push, deploy, post, or share. Stay short and local." --name "[bot:<profile>] prototype-rundown" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly. Do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-prototype-rundown.md`.
6. Tell the user: the day and time in their time zone, and how to change it with `hermes -p <profile> cron pause|resume|remove <job id>`, or by asking me.
