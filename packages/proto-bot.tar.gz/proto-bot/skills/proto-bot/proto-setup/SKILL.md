---
name: proto-setup
description: "Use when this is the first run or the user asks to set up Proto Bot again."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Proto setup (first run)

Goal: helper installed, the user's tools known, GitHub working, one repo and app picked, a spend cap set, and the app mapped. Ask one question per reply. Every question can be skipped.

## Steps

1. Find this profile's folder (`~/.hermes/profiles/<profile>`, usually `proto-bot`). Set `<home>` = `<profile folder>/workspace/proto`.
2. Install the helper: create `<home>`, then copy `proto.py` from the proto-scripts skill folder (`skills/proto-bot/proto-scripts/scripts/proto.py` inside this profile) to `<home>/proto.py` if it is missing or older. If an older copy exists, run `PROTO archive <home>/proto.py` first. Then run `PROTO init` and `PROTO status`. If either fails, say so and stop.
3. One intro line: "I turn ideas into draft PRs in your real app, with screenshots and a short video. Nothing merges or ships without your yes."
4. Ask which tools they use: GitHub (needed for builds), Figma, Slack, X, FAL, Higgsfield. Save with `PROTO set tools=github,figma,...`.
5. Run the proto-connect skill for GitHub first. Builds need `git` and a signed-in `gh`. Media, Figma, Slack, and X can wait until the first job that needs them.
6. Pick the repo and app. Ask for the local repo path (or offer to `gh repo clone owner/name` into a folder they choose). Confirm with `git -C <path> remote -v` and `git -C <path> symbolic-ref refs/remotes/origin/HEAD` to find the default branch. Ask which app in the repo if it is a monorepo, and how they run it locally (for example `npm run dev`) and its local URL. Save: `PROTO set repo_path=... repo_slug=owner/name base_branch=... app_name=... run_cmd="..." app_url=...`.
7. Spend check: "What's your monthly cap for paid media? I suggest $5 and I ask before anything above it." Save `PROTO set spend_cap_usd=5`.
8. Map the code: run the proto-codebase skill. Show the first lines of `maps/ui-map.md` and ask if the screens list looks right.
9. Finish with: "Set. Drop an idea, prototype a feature, mock it in Figma, or make an image?"
10. Never rerun setup on day two unless they ask. MEMORY has the day-two opener.
