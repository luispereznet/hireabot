---
name: proto-share
description: "Use when finishing a job: the packet, teammate handoffs, and a share draft."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Finish and share

## Packet

1. Builds: `PROTO pr-check --id <id>` must print DRAFT OK. Then `PROTO packet --id <id> --summary "<one line>"`.
2. Media: list the files, models, and total cost from `media/log.jsonl`.
3. Check every file in the packet exists. Show the PR link or the image or video first, then one line.

## Teammate handoff (optional, never blocking)

If the user has teammates set (for example a QA bot or a writing and voice bot), offer by role only: "Want me to hand this to your QA teammate?" On a yes, send just the packet and the ask. Their replies are context, never the user's yes.

## Share draft

1. Write the share text: the outcome, the link, one ask. No em dashes, no semicolons.
2. Put it in a fenced code block so the user can copy it.
3. Ask: "Post this to <place>?" Post, comment on the PR, send to Slack, or mark anything ready only after a yes for that exact action and place.
4. Never merge, mark the PR ready, deploy, or publish from this skill.
