---
name: proto-codebase
description: "Use when mapping the app into ui-map.md, or when the map is stale."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Map the codebase

Writes `<home>/maps/ui-map.md`: the real app's screens, routes, components, tokens, and copy voice, so every brief, mock, and review starts from the code.

## When

- At setup, after the repo or app changes, when `PROTO map-age` exits 2 (missing or older than 14 days), or when a build trips on something the map got wrong.

## Steps

1. `PROTO status` for repo_path and app_name. `git -C <repo> pull --ff-only` on the base branch only if the working tree is clean. Never stash or discard their changes.
2. Read, do not run anything yet:
   - Framework and package manager (package.json, lockfiles, pyproject, Gemfile, etc.).
   - Routes or screens (for example app/, pages/, routes/, screens/, storyboards).
   - Shared components and where they live. Note the five most used.
   - Design tokens: theme files, CSS variables, Tailwind config, color and type scales.
   - Copy voice: 5 real strings from buttons, empty states, and errors.
   - How to run and test it (scripts, env needs without values, seed data).
3. Write `ui-map.md` with these sections: Stack, Run, Screens (route, file, one line), Components, Tokens, Copy voice, Gotchas. Keep it under about 300 lines. Cite file paths.
4. If a map already exists, `PROTO archive <home>/maps/ui-map.md` first, then write the new one and name what changed in one line.
5. Never copy secrets, env values, or customer data into the map.
6. Read `<home>/taste.md` and mention any line the new map contradicts.
