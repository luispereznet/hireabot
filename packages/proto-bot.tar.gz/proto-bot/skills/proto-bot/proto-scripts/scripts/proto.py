#!/usr/bin/env python3
"""proto.py: Proto Bot's local helper. Standard library only.

Keeps the bot's state in its own home folder (default: $PROTO_HOME, else
~/.hermes/profiles/proto-bot/workspace/proto). Layout:

    state.json      repo, app, spend cap, tools, open builds
    taste.md        one dated line per correction or preference
    maps/ui-map.md  the app map written by proto-codebase
    briefs/         one brief per idea (YYYY-MM-DD-<slug>.md)
    builds/<id>/    shots/, video/, packet.md for each build
    media/          generated files plus log.jsonl (provider, model, cost)
    research/       craft playbooks
    archive/        timestamped copies. Nothing is ever deleted.

Commands (run `proto.py <command> -h` for options):
    init          create the folder layout and state.json
    status        print a JSON summary (repo, map age, open builds, spend)
    set           set config fields, e.g. set repo_path=~/code/app base_branch=main
    taste         append one dated line to taste.md
    map-age       print days since maps/ui-map.md changed (exit 2 if older than 14)
    brief         write a brief with the draft PR rules and register a build
    builds        list builds, optionally refreshing PR state with gh
    build-set     update a build (pr_url, status, note)
    pr-check      confirm a PR is still a draft (exit 2 if not, or if gh fails)
    packet        write builds/<id>/packet.md from the files in shots/ and video/
    spend-check   exit 2 if a planned cost would pass the monthly cap
    media-log     record one media job (provider, model, cost, file)
    keys          report which media keys are set (names only, never values)
    archive       copy a file into archive/ with a timestamp

Never prints a key value. Never deletes. Never pushes, merges, or marks a PR ready.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_HOME = Path(os.environ.get('PROTO_HOME') or '~/.hermes/profiles/proto-bot/workspace/proto').expanduser()
FOLDERS = ('maps', 'briefs', 'builds', 'media', 'research', 'archive')
KEY_NAMES = {'fal': ['FAL_KEY'], 'higgsfield': ['HF_API_KEY', 'HF_API_SECRET', 'HF_KEY']}
MAP_MAX_DAYS = 14
DEFAULT_STATE = {
    'repo_path': '', 'repo_slug': '', 'base_branch': 'main', 'app_name': '', 'run_cmd': '', 'app_url': '',
    'spend_cap_usd': 5.0, 'media_provider': '', 'tools': [], 'builds': [], 'created': '',
}

DRAFT_RULES = """## Draft PR rules (always)

- Work on branch `{branch}`. Never commit to or push `{base}`.
- Open the pull request as a draft: `gh pr create --draft --base {base} --head {branch}`.
- Never run `gh pr ready`, `gh pr merge`, or a deploy. Those need the user's yes for that action.
- Run `proto.py pr-check --id {bid}` before showing the PR. If it is not a draft, stop and tell the user.
- Use the app's real components, tokens, screens, and copy (see maps/ui-map.md and taste.md). No lorem.
- Capture the click path: screenshots into builds/{bid}/shots/, a short screen video into builds/{bid}/video/.
"""


def now() -> dt.datetime:
    return dt.datetime.now().astimezone()


def slugify(text: str) -> str:
    s = re.sub(r'[^a-z0-9]+', '-', text.lower()).strip('-')
    return (s or 'idea')[:48]


def home(a) -> Path:
    return Path(a.root).expanduser() if a.root else DEFAULT_HOME


def load(h: Path) -> dict:
    f = h / 'state.json'
    if not f.is_file():
        sys.exit(f'No state at {f}. Run: proto.py init --root {h}')
    data = json.loads(f.read_text())
    return {**DEFAULT_STATE, **data}


def save(h: Path, st: dict) -> None:
    f = h / 'state.json'
    tmp = f.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(st, indent=2) + '\n')
    tmp.replace(f)


def find_build(st: dict, bid: str) -> dict:
    for b in st['builds']:
        if b['id'] == bid:
            return b
    sys.exit(f'No build with id {bid}. Run proto.py builds.')


def gh_pr(pr: str, repo_path: str) -> dict | None:
    cwd = Path(repo_path).expanduser() if repo_path else None
    try:
        r = subprocess.run(['gh', 'pr', 'view', pr, '--json', 'isDraft,state,url,baseRefName,headRefName'],
                           capture_output=True, text=True, timeout=60, cwd=cwd)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        print(f'gh failed: {e}', file=sys.stderr)
        return None
    if r.returncode != 0:
        print(f'gh failed: {r.stderr.strip()[:200]}', file=sys.stderr)
        return None
    return json.loads(r.stdout)


def map_age_days(h: Path) -> float | None:
    m = h / 'maps' / 'ui-map.md'
    if not m.is_file():
        return None
    return round((now().timestamp() - m.stat().st_mtime) / 86400, 1)


def month_spend(h: Path) -> float:
    log = h / 'media' / 'log.jsonl'
    if not log.is_file():
        return 0.0
    month = now().strftime('%Y-%m')
    total = 0.0
    for line in log.read_text().splitlines():
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if str(row.get('at', '')).startswith(month):
            total += float(row.get('cost_usd') or 0)
    return round(total, 2)


def env_file_names(path: Path) -> set[str]:
    names = set()
    if path.is_file():
        for line in path.read_text(errors='ignore').splitlines():
            m = re.match(r'\s*(?:export\s+)?([A-Z0-9_]+)\s*=\s*\S', line)
            if m:
                names.add(m.group(1))
    return names


# commands -----------------------------------------------------------------

def cmd_init(a) -> None:
    h = home(a)
    for d in FOLDERS:
        (h / d).mkdir(parents=True, exist_ok=True)
    if not (h / 'state.json').is_file():
        save(h, {**DEFAULT_STATE, 'created': now().isoformat(timespec='seconds')})
    if not (h / 'taste.md').is_file():
        (h / 'taste.md').write_text('# Taste\n\nOne dated line per correction or preference.\n\n')
    print(f'OK {h}')


def cmd_status(a) -> None:
    h = home(a)
    st = load(h)
    age = map_age_days(h)
    out = {
        'home': str(h), 'repo_path': st['repo_path'], 'repo_slug': st['repo_slug'], 'base_branch': st['base_branch'],
        'app_name': st['app_name'], 'app_url': st['app_url'], 'run_cmd': st['run_cmd'], 'tools': st['tools'],
        'media_provider': st['media_provider'], 'ui_map_age_days': age,
        'ui_map_stale': age is None or age > MAP_MAX_DAYS,
        'open_builds': [b['id'] for b in st['builds'] if b.get('status') not in ('closed', 'merged', 'dropped')],
        'spend_this_month_usd': month_spend(h), 'spend_cap_usd': st['spend_cap_usd'],
        'setup_done': bool(st['repo_path']),
    }
    print(json.dumps(out, indent=2))


def cmd_set(a) -> None:
    h = home(a)
    st = load(h)
    for pair in a.pairs:
        if '=' not in pair:
            sys.exit(f'Use key=value, got {pair!r}')
        k, v = pair.split('=', 1)
        if k not in DEFAULT_STATE or k in ('builds', 'created'):
            sys.exit(f'Unknown or protected field {k!r}. Allowed: ' + ', '.join(x for x in DEFAULT_STATE if x not in ('builds', 'created')))
        if re.search(r'key|token|secret|password', k, re.I):
            sys.exit('Keys never go in state.json.')
        if k == 'spend_cap_usd':
            v = float(v)
        elif k == 'tools':
            v = [t.strip() for t in v.split(',') if t.strip()]
        st[k] = v
    save(h, st)
    print('OK ' + ', '.join(p.split('=', 1)[0] for p in a.pairs))


def cmd_taste(a) -> None:
    h = home(a)
    f = h / 'taste.md'
    line = ' '.join(a.line).strip().replace('\n', ' ')
    if not line:
        sys.exit('Give the correction as one line.')
    with f.open('a') as fh:
        fh.write(f'- {now().date().isoformat()} {line}\n')
    print(f'OK {f}')


def cmd_map_age(a) -> None:
    age = map_age_days(home(a))
    if age is None:
        print('missing')
        sys.exit(2)
    print(age)
    sys.exit(2 if age > MAP_MAX_DAYS else 0)


def cmd_brief(a) -> None:
    h = home(a)
    st = load(h)
    base = st['base_branch'] or 'main'
    slug = slugify(a.title)
    day = now().date().isoformat()
    made = []
    for i in range(1, a.variants + 1):
        suffix = f'-v{i}' if a.variants > 1 else ''
        bid = f'{day}-{slug}{suffix}'
        branch = f'proto/{slug}{suffix}'
        brief = h / 'briefs' / f'{bid}.md'
        if brief.exists():
            sys.exit(f'{brief} exists. Archive it first or pick a new title.')
        for sub in ('shots', 'video'):
            (h / 'builds' / bid / sub).mkdir(parents=True, exist_ok=True)
        body = [f'# {a.title}{" (variant " + str(i) + ")" if suffix else ""}', '',
                f'Date: {day}', f'Repo: {st["repo_slug"] or st["repo_path"]}', f'App: {st["app_name"]}', '',
                '## Idea', '', a.idea.strip(), '']
        if a.variant_note and suffix:
            body += ['## This variant', '', a.variant_note[i - 1] if i <= len(a.variant_note) else 'Pick a different approach from the other variants.', '']
        body += ['## Done when', '', a.done.strip() if a.done else 'The click path in the idea works in the running app.', '',
                 DRAFT_RULES.format(branch=branch, base=base, bid=bid)]
        brief.write_text('\n'.join(body))
        st['builds'].append({'id': bid, 'title': a.title, 'branch': branch, 'brief': str(brief.relative_to(h)),
                             'pr_url': '', 'status': 'briefed', 'created': now().isoformat(timespec='seconds'), 'notes': []})
        made.append({'id': bid, 'branch': branch, 'brief': str(brief)})
    save(h, st)
    print(json.dumps(made, indent=2))


def cmd_builds(a) -> None:
    h = home(a)
    st = load(h)
    rows = []
    for b in st['builds']:
        if not a.all and b.get('status') in ('closed', 'merged', 'dropped'):
            continue
        if a.refresh and b.get('pr_url'):
            info = gh_pr(b['pr_url'], st['repo_path'])
            if info:
                new = 'merged' if info['state'] == 'MERGED' else 'closed' if info['state'] == 'CLOSED' else \
                      'draft' if info['isDraft'] else 'ready'
                b['changed'] = new != b.get('status')
                b['status'] = new
        rows.append({k: b.get(k) for k in ('id', 'status', 'branch', 'pr_url', 'changed')})
    if a.refresh:
        save(h, st)
    print(json.dumps(rows, indent=2))


def cmd_build_set(a) -> None:
    h = home(a)
    st = load(h)
    b = find_build(st, a.id)
    if a.pr_url:
        b['pr_url'] = a.pr_url
    if a.status:
        b['status'] = a.status
    if a.note:
        b.setdefault('notes', []).append(f'{now().isoformat(timespec="minutes")} {a.note}')
    save(h, st)
    print(f'OK {a.id}')


def cmd_pr_check(a) -> None:
    h = home(a)
    st = load(h)
    pr = a.pr
    if a.id:
        b = find_build(st, a.id)
        pr = pr or b.get('pr_url')
    if not pr:
        sys.exit('No PR given and the build has no pr_url. Use --pr or build-set --pr-url first.')
    info = gh_pr(pr, st['repo_path'])
    if info is None:
        print('UNKNOWN: could not read the PR. Do not show it as a draft.')
        sys.exit(2)
    base = st['base_branch'] or 'main'
    if info['state'] != 'OPEN' or not info['isDraft']:
        print(f"NOT DRAFT: state={info['state']} isDraft={info['isDraft']} {info['url']}")
        sys.exit(2)
    if info['headRefName'] == base:
        print(f"UNSAFE: head branch is the base branch {base}")
        sys.exit(2)
    print(f"DRAFT OK {info['url']} ({info['headRefName']} -> {info['baseRefName']})")


def cmd_packet(a) -> None:
    h = home(a)
    st = load(h)
    b = find_build(st, a.id)
    d = h / 'builds' / a.id
    shots = sorted(p for p in (d / 'shots').glob('*') if p.suffix.lower() in ('.png', '.jpg', '.jpeg', '.webp'))
    vids = sorted(p for p in (d / 'video').glob('*') if p.suffix.lower() in ('.mp4', '.mov', '.webm', '.gif'))
    lines = [f'# {b["title"]}', '', f'PR (draft): {b.get("pr_url") or "not opened yet"}', f'Branch: {b["branch"]}',
             f'Status: {b.get("status")}', '', '## Click path', '']
    lines += [f'{i}. {p.name} ({p})' for i, p in enumerate(shots, 1)] or ['No screenshots yet.']
    lines += ['', '## Video', ''] + ([f'- {p}' for p in vids] or ['No video yet.'])
    if a.summary:
        lines += ['', '## What changed', '', a.summary]
    (d / 'packet.md').write_text('\n'.join(lines) + '\n')
    missing = [] if shots else ['screenshots']
    missing += [] if vids else ['video']
    print(json.dumps({'packet': str(d / 'packet.md'), 'shots': len(shots), 'videos': len(vids), 'missing': missing}, indent=2))


def cmd_spend_check(a) -> None:
    h = home(a)
    st = load(h)
    spent = month_spend(h)
    cap = float(st['spend_cap_usd'])
    after = round(spent + a.cost, 2)
    status = 'OVER_CAP' if after > cap else 'OK'
    print(json.dumps({'status': status, 'spent_usd': spent, 'planned_usd': a.cost, 'after_usd': after, 'cap_usd': cap}))
    sys.exit(2 if status == 'OVER_CAP' else 0)


def cmd_media_log(a) -> None:
    h = home(a)
    load(h)
    if a.provider not in KEY_NAMES:
        sys.exit('Provider must be fal or higgsfield.')
    row = {'at': now().isoformat(timespec='seconds'), 'provider': a.provider, 'model': a.model,
           'cost_usd': a.cost, 'file': a.file, 'kind': a.kind, 'note': a.note or ''}
    with (h / 'media' / 'log.jsonl').open('a') as fh:
        fh.write(json.dumps(row) + '\n')
    print(f'OK logged, month total ${month_spend(h)}')


def cmd_keys(a) -> None:
    env_file = Path(a.env_file).expanduser() if a.env_file else home(a).parent.parent / '.env'  # <profile>/.env
    in_file = env_file_names(env_file)
    out = {}
    for prov, names in KEY_NAMES.items():
        out[prov] = {n: ('set' if os.environ.get(n) or n in in_file else 'missing') for n in names}
    print(json.dumps({'env_file': str(env_file), 'keys': out}, indent=2))


def cmd_archive(a) -> None:
    h = home(a)
    src = Path(a.path).expanduser()
    if not src.exists():
        sys.exit(f'{src} not found')
    dest = h / 'archive' / f'{now().strftime("%Y%m%d-%H%M%S")}-{src.name}'
    (shutil.copytree if src.is_dir() else shutil.copy2)(src, dest)
    print(f'OK {dest}')


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--root', help='bot home folder (default $PROTO_HOME or the profile workspace/proto)')
    sub = p.add_subparsers(dest='cmd', required=True)
    sub.add_parser('init').set_defaults(fn=cmd_init)
    sub.add_parser('status').set_defaults(fn=cmd_status)
    s = sub.add_parser('set'); s.add_argument('pairs', nargs='+'); s.set_defaults(fn=cmd_set)
    s = sub.add_parser('taste'); s.add_argument('line', nargs='+'); s.set_defaults(fn=cmd_taste)
    sub.add_parser('map-age').set_defaults(fn=cmd_map_age)
    s = sub.add_parser('brief')
    s.add_argument('--title', required=True); s.add_argument('--idea', required=True); s.add_argument('--done')
    s.add_argument('--variants', type=int, default=1); s.add_argument('--variant-note', action='append')
    s.set_defaults(fn=cmd_brief)
    s = sub.add_parser('builds'); s.add_argument('--refresh', action='store_true'); s.add_argument('--all', action='store_true')
    s.set_defaults(fn=cmd_builds)
    s = sub.add_parser('build-set'); s.add_argument('--id', required=True); s.add_argument('--pr-url')
    s.add_argument('--status', choices=['briefed', 'building', 'draft', 'ready', 'closed', 'merged', 'dropped'])
    s.add_argument('--note'); s.set_defaults(fn=cmd_build_set)
    s = sub.add_parser('pr-check'); s.add_argument('--id'); s.add_argument('--pr'); s.set_defaults(fn=cmd_pr_check)
    s = sub.add_parser('packet'); s.add_argument('--id', required=True); s.add_argument('--summary'); s.set_defaults(fn=cmd_packet)
    s = sub.add_parser('spend-check'); s.add_argument('--cost', type=float, required=True); s.set_defaults(fn=cmd_spend_check)
    s = sub.add_parser('media-log')
    s.add_argument('--provider', required=True); s.add_argument('--model', required=True)
    s.add_argument('--cost', type=float, required=True); s.add_argument('--file', required=True)
    s.add_argument('--kind', default='image'); s.add_argument('--note'); s.set_defaults(fn=cmd_media_log)
    s = sub.add_parser('keys'); s.add_argument('--env-file'); s.set_defaults(fn=cmd_keys)
    s = sub.add_parser('archive'); s.add_argument('path'); s.set_defaults(fn=cmd_archive)
    a = p.parse_args()
    a.fn(a)


if __name__ == '__main__':
    main()
