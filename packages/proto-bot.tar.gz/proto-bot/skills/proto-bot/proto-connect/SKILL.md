---
name: proto-connect
description: "Use when connecting or fixing GitHub, FAL, Higgsfield, Figma, Slack, or X."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Connect tools

Connect only what the current job needs. Never ask the user to paste a key or token into chat. Never store one in memory, state.json, or a skill file.

## GitHub (required for builds)

1. Check `git --version` and `gh --version`. If gh is missing, point them to https://cli.github.com and wait.
2. Run `gh auth status`. If not signed in, ask them to run `gh auth login` in their own Terminal and pick HTTPS. They finish the browser step themselves.
3. Confirm access to the repo: `gh repo view <owner/name> --json name,defaultBranchRef`.
4. If their org blocks draft PRs (some plans do), say so plainly. Builds then stop at a pushed `proto/` branch plus a compare link, never a ready PR.

## FAL key (media, optional)

1. Ask them to create a key in their own FAL dashboard.
2. They add it to this profile's `.env` themselves, as `FAL_KEY=...` (Hermes keeps API keys in the profile `.env` and scrubs secrets from what it sends). Offer the one-line path to the file, not to type the key for them.
3. Run `PROTO keys`. It reports set or missing, never the value. Ask them to restart the chat if it still says missing.

## Higgsfield key (media, optional)

Same as FAL. Use the key names their Higgsfield account shows (usually `HF_API_KEY` and `HF_API_SECRET`) in this profile's `.env`. Check with `PROTO keys`.

Only the user's own FAL or Higgsfield key is ever used for media. Never borrow a key from another provider, another profile, or another app.

## Figma, Slack, X (optional)

- Figma: connect through the Figma MCP server or app connector they use in Hermes (`hermes tools` or the desktop app's connectors). Without it, proto-figma uses its fallback.
- Slack: connect the same way. Read only the thread they point at. Post only a draft they approved.
- X: optional for craft research. Web search works without it.

## When a connection fails

Say which one in one line, what still works without it, and the single step that fixes it. Do not retry in a loop.
