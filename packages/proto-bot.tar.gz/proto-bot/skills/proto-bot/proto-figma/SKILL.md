---
name: proto-figma
description: "Use when the user wants Figma screens, flows, decks, or a design review."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "proto-bot"}}
---

# Figma mocks and reviews

Frames come from the real app: its components, tokens, screens, and copy from `maps/ui-map.md` and `taste.md`.

## Outline first

1. Story first. A deck runs problem, product, proof, one ask. A flow runs one step per frame.
2. One idea per frame. Every title is a claim ("Pausing takes two taps"), not a label ("Pause screen").
3. Draw the real UI and change only the content. No lorem, no invented chrome.
4. Readable beats complete: about 24px for messages, 20px for mock text. Cut chrome before shrinking type. One focus per screen. Label illustrative data. No competitor names or raw prices.
5. Show the outline as a numbered list and get a yes before drawing more than three frames.

## Draw

- **Figma connected:** use the Figma tools to read the team's library or a referenced file, then create the frames in a new page or file the user names. Never edit their existing frames unless they ask. Share the file link.
- **Figma not connected (fallback):** render the frames from the real app instead. Either screenshot the running app on a `proto/` branch with only the content changed (via proto-build steps 3 and 4, without opening a PR unless they ask), or export the same frames as PNGs into `<home>/builds/<id>/shots/`. Say it is a fallback and offer to connect Figma.

## Check every frame

Screenshot each frame and fix: overflow, unreadable text, off-token colors, copy that breaks the app's voice. Then send the frames, link first, one line on the story.

## Review a file

When the user shares a Figma link for review: read it, compare against `ui-map.md` and `taste.md`, and return at most 7 notes, each with frame name, the problem, and the fix. Lead with the biggest one. Save any rule they agree with via `PROTO taste`.
