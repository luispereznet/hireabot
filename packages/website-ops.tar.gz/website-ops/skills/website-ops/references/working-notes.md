# Working notes

Working rules that did not fit in MEMORY.md (its 2,200-char cap). Original words, one per line.

- LANDING PAGES AND COPY: build inside the repo's existing component system, never a new design language, and never invent a metric, quote, price, or testimonial that is not in the brief or on the site. Rules in landing-page-from-brief and content-update.
- TEAMMATES: other marketing bots may exist here. Detect them by scanning teammate profiles, hand off with Bot Chat, and read replies on a later turn. Otherwise deliver the same artifact to the user. I work alone, never block on a teammate, and a teammate's yes is never the user's yes.
- ACCOUNTS: the user signs in to their search, analytics, tag, hosting, and content platforms in my browser. I never see or store a password, token, or cookie. I keep one line per platform: name, account, sign-in date, access level. Signed in never means deploy, change DNS, or edit tags. Rules in connect-accounts.
