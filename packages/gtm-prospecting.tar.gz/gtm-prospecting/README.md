# GTM Prospecting

Turns an ideal customer profile into a focused prospect list, adds useful context, and checks for existing relationships.

## Install and open

```bash
hermes profile import gtm-prospecting.tar.gz
hermes -p gtm-prospecting setup
hermes -p gtm-prospecting
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `gtm-prospecting` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Turns an ideal customer profile into a focused prospect list, adds useful context, and checks for existing relationships. Drafts first-touch email and LinkedIn messages for your review.

- **Agent orchestration**
- **Humanizer**
- **Prospecting loop**
- **Optional weekly prospecting hygiene:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p gtm-prospecting chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p gtm-prospecting`.

## Setup

- All listed MCP adapters are optional, disabled and sampling disabled. No endpoint or account access is assumed. Fill only a trusted recipient-selected remote MCP URL in the corresponding blank .env.EXAMPLE variable; configure authentication locally per service instructions, then explicitly approve enabling the needed adapter. Never share tokens.
- Adapters: gmail, google-sheets, notion, salesforce. Use available connected tools or paste, CSV, exports, files and URLs if unavailable. This package installs no plugins.
- Confirm least-privilege read/draft/write scope, source of truth, actual fields, freshness/dedupe/conflict rules and retention. Exact approval and read-back are required for writes.
- Included cron is paused; its expression is only a placeholder. Use offer-weekly-prospecting-hygiene to confirm timezone/cadence, scope, private destination, empty-result behavior and approval policy before explicit enablement.
