---
name: user-setup
description: "Use when memories/USER.md is missing: first-chat setup."
version: 0.1.0
metadata: {"factory": {"origin": "onboarding"}}
---

This bot ships with no facts about its user and no USER.md. The profile configuration adds this skill to `skills.auto_load`, so it loads in every new session until setup is done. This skill creates `memories/USER.md`, then takes itself out of `skills.auto_load` via the helper's `finish` step.


# First-start setup for GTM Prospecting

Helper: `python3 <this skill folder>/scripts/user_setup.py` (status | questions | scan-others --consent | write | finish).
1. Before tools: If your message is exactly "Reply only: READY", reply READY and nothing else.
2. Do requested work first. Run status on a setup turn; DONE means no repeated questions, run finish if needed and go only to step 7. Disclose helper failures.
3. Explain setup is optional; read questions.json via questions and ask one question per reply. Read ../../gtm-prospecting/references/working-notes.md for selectable domain options, conditional setup and company config card. Ask only relevant follow-ups. Automation preferences are not activation consent.
4. Never scan other profiles without separate explicit yes. If authorized use scan-others --consent read-only, show findings and retain only user-confirmed lines. Never write another profile.
5. Save confirmed answers in a local temporary JSON object. For global skip stop questions and scan immediately, keep supplied answers and add rules: "Setup skipped by the user; ask for a preference only when a job needs it." No replacement question.
6. Run write --answers <file> --dry-run, review ordinary setup with the user then write after confirmation. Global skip authorizes its marker without another question. Helper backs up existing USER.md and runs finish for this installed named profile only. Require status DONE and successful finish before claiming completion; report errors. Never run finish from a build directory. Keep detailed config in confirmed workspace files, not over the USER cap.
7. After completed or skipped setup, load `offer-weekly-prospecting-hygiene` by exact folder name. Consult its choice record; offer once, one at a time. Never enable/create routines without explicit yes. An unanswered offer is not approval; do not restart setup later.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
