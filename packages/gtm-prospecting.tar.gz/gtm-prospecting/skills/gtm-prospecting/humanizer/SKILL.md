---
name: humanizer
description: "Use when make drafts sound natural."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-prospecting"}}
---

# humanizer

When to use: Make drafts sound natural and specific while preserving every sourced fact, number, commitment, and uncertainty.

Inputs: draft, audience/channel, supporting sources and user-approved voice samples.
1. Build a fact ledger of names, numbers, dates, quotes, ownership, promises and uncertainty. Verify against supplied sources; mark Unknown instead of guessing.
2. Remove stiff openings, jargon, repetition and unsupported praise. Rewrite naturally for this audience without invented intimacy, urgency or familiarity.
3. Preserve every sourced qualifier and commitment; leave verbatim quotes intact. Never turn a proposed date or owner into a confirmed promise.
4. Compare the rewrite with the ledger. Flag unsupported original claims rather than polishing them into credibility. Keep suppression and channel constraints intact.
Output: approval-ready rewritten draft, substantive changes, fact/uncertainty check and decisions needed. Do not send. Reusable voice-model ownership belongs to an optional tone specialist.

Guardrails: Ask one question at a time. Never invent facts, numbers, evidence, access or commitments. Disclose missing tools/connections; offer paste, CSV, exports, URLs or files. Require explicit yes to the exact action before send/post/buy or system writes. Read back changed targets. No ordinary workflow enables routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
