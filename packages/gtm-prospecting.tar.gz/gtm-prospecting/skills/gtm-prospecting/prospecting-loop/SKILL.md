---
name: prospecting-loop
description: "Use when prospecting guide."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "gtm-prospecting"}}
---

# prospecting-loop

When to use: Prospecting guide: setup prefs, voice from mail, CRM schema discovery, enrich, skip touched, prefer live sheet with CSV fallback, drafts-only email+LinkedIn.

Inputs: ICP, exclusions, personas, requested list scope, CRM/suppression sources and outreach objective.
1. Read ../references/working-notes.md. Confirm missing ICP criteria and permissions one question at a time. Prefer approved live Sheets; use CSV/pasted rows when unavailable and disclose stale coverage.
2. Discover actual CRM objects, fields, canonical IDs, owner relationships and touch history read-only. Map dedupe and do-not-touch rules; never invent schema or overwrite canonical data.
3. Select matching accounts/people using approved web/connector evidence. Enrich with URL, observed date and confidence/Unknown. Deduplicate by domain/account ID and contact identity; never guess emails or merge namesakes.
4. Check recent touches, active opportunities, ownership, suppression and opt-outs before drafting. Separate eligible, excluded and needs-review rows with reasons. Missing relationship coverage means unchecked: hold outreach, never claim clearance.
5. Prioritize by approved fit/intent criteria, not invented scores. Derive voice only from approved sent-mail samples or supplied examples; reusable style ownership remains optional GTM Tone. Draft email plus LinkedIn variants with sourced relevance and a modest CTA, not invented familiarity.
6. Present row-level evidence and drafts for review. Sheet/CRM writes require exact approval and read-back. This workflow never sends outreach. Optional depth siblings are not prerequisites.
Output: account/contact list, fit evidence, touch/owner/suppression audit, exclusions, unknowns, email + LinkedIn drafts and any approved-write receipt. Route recurring requests to offer-weekly-prospecting-hygiene.

Guardrails: Ask one question at a time. Never invent facts, numbers, evidence, access or commitments. Disclose missing tools/connections; offer paste, CSV, exports, URLs or files. Require explicit yes to the exact action before send/post/buy or system writes. Read back changed targets. No ordinary workflow enables routines.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
