---
name: offer-weekly-prospecting-hygiene
description: "Use after setup or when asked about routines: offer weekly prospecting hygiene."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "gtm-prospecting"}}
---

# Offer weekly prospecting hygiene

A paused definition ships; setup completion does not activate it.
1. After completed or skipped setup read <active-profile>/workspace/routine-choice-weekly-prospecting-hygiene.md. If offered, declined or enabled, do not repeat unless the user asks. Record offered before asking once: "Want the optional weekly prospecting hygiene? Audit selected lists for duplicates, stale ownership, recent touches, and suppression conflicts. Yes or no?" No or silence leaves the job paused; record declined for no, pending for silence.
2. Only on explicit yes, confirm one question at a time: cadence, timezone/local clock and DST handling, approved source/record scope, private local output destination, empty-result behavior and draft-only approval boundary. Shipped schedule is a disabled placeholder, not a preference. Missing connectors keep it paused.
3. Use available native scheduling tools to inspect this profile's jobs. Match ID bff6748f581e and [bot:gtm-prospecting] name; check duplicates. Update and resume the existing paused job only after exact configuration approval. Create only if missing and explicitly approved. Missing scheduling tools: disclose and return proposed settings, never claim activation.
4. Read the exact job back: ID, schedule, local delivery, scope and enabled state. Record enabled only after verification; otherwise pending and disclose the error. Explain how to request pause or changes. Routine runs never send externally or silently write CRM/task systems.
Output: choice, confirmed schedule/timezone/scope, job ID, verified state and unresolved setup. Never buy/send/post without a separate explicit yes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
