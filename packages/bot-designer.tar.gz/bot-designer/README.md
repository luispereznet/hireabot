# Bot Designer

Designs Hermes bots with a tight persona: one job, one voice, explicit anti-jobs, and no leftover tools. It asks a few preference questions, writes the profile, runs an audit, and hands the folder over only after a clean pass. Optional weekday transcript and Monday routine healthchecks stay quiet when nothing is worth proposing.

- **Design a Hermes bot:** preference questions, persona, profile files, audit, handoff.
- **Transcript healthcheck:** scans Hermes chats for friction and repeated corrections; proposes skills, bots, or routines; creates nothing until you pick.
- **Routine healthcheck:** audits scheduled jobs for wasted usage; reports fixes; creates nothing until you pick.
- **Optional standing checks:** offered once after setup. They are only created if you say yes.

## Install

This works in the Hermes desktop app, the mobile app or the Terminal. It creates a **new bot profile** called bot-designer, uses the AI connection you already have, and leaves your other profiles alone.

1. **First time only: install the Bot Installer.** In the Terminal, run this line to install the bot-installer skill:
   > hermes skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md

   Or type it in a Hermes chat: `/skills install https://agentplaybooks.dev/skills/bot-installer/SKILL.md --yes`
2. **Download** `bot-designer.zip` from the Bot Designer page. There's no need to unzip it.
3. **Tell Hermes:**
   > Use bot-installer to install bot-designer from the Downloads folder.

The installer finds the newest bot-designer download in your Downloads folder, whether it's the zip or an unzipped folder. If you saved it somewhere else, give the path instead, for example `~/Desktop/bot-designer.zip`.

On its first chat, the bot asks a few quick questions so it can work the way you like. You can skip any of them.
