---
name: routine-healthcheck
description: "Use when auditing Hermes scheduled jobs for wasted usage."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "bot-designer"}}
---

# Routine healthcheck

Audit Hermes scheduled jobs and accepted offer-routines for wasted usage. Report fixes. Stay quiet when nothing is worth proposing. Never create, pause, or remove a job until the user picks a fix.

Working folder: `~/.hermes/profiles/bot-designer/workspace`. Save reports under `healthchecks/<YYYY-MM-DD>-routine.md`.

## Scope

1. Ask which profiles to include (default: all profiles the user names).
2. For each profile, gather:
   - `hermes -p <profile> cron list --all`
   - `hermes -p <profile> cron doctor`
   - `hermes -p <profile> cron runs` (recent attempts; note failures and empty useful output)
3. Also read this bot's own `routine-choice-*.md` files so declined offers are not re-proposed as missing jobs.

## What counts as waste

- Job that always delivers empty or "nothing to report" noise on a messaging channel
- Overlapping jobs that do the same work
- High-frequency jobs with no user action taken on recent outputs
- Failed runs that keep retrying without a fix
- Deliveries to a channel the user no longer uses (prefer local delivery)
- Disabled or completed jobs still cluttering the list with no note

## Report

- Jobs reviewed (name, schedule, deliver, last run summary)
- Findings with a concrete fix (pause, retarget to local, lower cadence, remove, rewrite prompt)
- If nothing is worth proposing: `quiet: nothing to propose` and one short line to the user

## After the report

Show the fixes. Wait. Only when the user picks one, run the matching `hermes -p <profile> cron ...` command and confirm with `cron list`. Never invent token counts; only use numbers the CLI printed.
