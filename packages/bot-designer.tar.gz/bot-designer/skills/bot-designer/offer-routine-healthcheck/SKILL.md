---
name: offer-routine-healthcheck
description: "Use after setup or when asked about routines: offer routine check."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "bot-designer"}}
---

# Offer the routine healthcheck

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-routine-healthcheck.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.
- Prefer offering this after the transcript offer, in a separate message, so each gets its own yes or no.

## Ask

Say in one line, then ask yes or no:
"Want a Monday routine healthcheck? Once a week I'll audit Hermes scheduled jobs for wasted runs and suggest pauses or cadence changes. It stays quiet when nothing's wrong, and it won't change a job until you pick. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user.

- Explicit no: reply "OK, no routine check. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-routine-healthcheck.md`. Stop.
- No clear answer or a change of topic: do not create a routine or record a decline. Carry on.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "Monday 8:49 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. Convert the user's time to it. Build a cron expression (Monday 8:49 = `49 8 * * 1`).
3. Get this profile's name (usually `bot-designer`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Routine healthcheck. Follow the routine-healthcheck skill: audit Hermes scheduled jobs for wasted usage, write a local report, stay quiet when nothing is worth proposing, and never pause or remove a job until the user picks." --name "[bot:<profile>] routine-healthcheck" --skill routine-healthcheck --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-routine-healthcheck.md`.
6. Tell the user: the day and time in their time zone, and how to pause or remove it with `hermes -p <profile> cron pause|resume|remove <job id>`, or by asking you.
