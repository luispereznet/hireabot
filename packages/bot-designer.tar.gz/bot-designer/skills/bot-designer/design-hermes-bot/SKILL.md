---
name: design-hermes-bot
description: "Use when designing or creating a new Hermes bot."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "bot-designer"}}
---

# Design a Hermes bot

Goal: a complete, audited Hermes bot the user can run. Prefer a local profile. Make a shareable package only when they ask.

Working folder: `~/.hermes/profiles/bot-designer/workspace` (use absolute paths). Drafts live in `designs/<slug>/`. Never overwrite; archive with a timestamp first.

## Preference questions (one at a time; every one skippable)

1. What should this bot do in one sentence?
2. What should it never do (anti-jobs)?
3. Who is it for, and how should it talk (voice)?
4. Display name and slug (lowercase letters, digits, hyphens)? Suggest a slug from the name.
5. Any skills it must have on day one?
6. Local profile only, or also a downloadable package?
7. Any standing rules (never delete files, ask before sending, quiet when nothing to say)?

If the first message already answers most of these, skip ahead and only ask what is missing.

## Design rules

- One job. One voice. Explicit anti-jobs. No leftover tools. No stub skills.
- Coding bots: one job, concise, verified. Prove it works before calling it done.
- Do not default to shareable templates.
- Shipped files never name other agent platforms, plugins, or creators.

## Write the draft

Create `designs/<slug>/` with:

1. `SOUL.md` — Identity, Style, Avoid, When things are unclear. Include the first-run line: until USER.md exists, follow user-setup one skippable question at a time; if the message is exactly `Reply only: READY`, reply READY and nothing else. No file paths or shell commands in SOUL.
2. `memories/MEMORY.md` — working rules only, under 2200 characters. Say what to do until USER.md exists. Separate facts with a line that is only `§`.
3. `bot.yaml` — name (slug), display_name, version `0.1.0`, description, onboarding_skill `user-setup`, min_hermes `0.22.5`. No model, provider, or credential fields. optional_routines only if the new bot truly needs offers.
4. `README.md` — plain what-it-does copy plus the two-step Bot Installer install block for this slug.
5. `skills/onboarding/user-setup/` — SKILL.md, questions.json (stranger-answerable, every question skippable), and copy the helper script from this bot's own `skills/onboarding/user-setup/scripts/user_setup.py`.
6. `skills/<slug>/<skill>/SKILL.md` — real steps, not stubs. Front matter: name matches folder, description starts with `Use when`.
7. If the user wants a live profile (default): also draft `profile.yaml` (display_name, description) and a minimal `config.yaml` note listing only non-secret defaults the installer or `hermes profile` flow should apply. Keep secrets out. Do not write under `~/.hermes/profiles/<slug>/` until the audit is clean and the user confirms the name.

For package-shaped handoff, omit USER.md, config.yaml, cron, auth, .env, BOOTSTRAP, AGENTS, and profile.yaml from the folder you zip.

## Audit before handoff

1. Run a built-in check on the draft and print PASS / WARN / FAIL counts:
   - required files present for the chosen shape (package vs live profile)
   - SOUL has Identity, Style, Avoid, When things are unclear, plus the READY / user-setup line
   - MEMORY under 2200 chars; USER placeholder or onboarding path clear
   - every skill has real steps (no empty bodies, no unfinished placeholder markers
   - `grep -rniE` over the draft for forbidden public words; must print nothing
   - bot.yaml slug matches folder; version is x.y.z; no credential fields
2. If `audit_bot.py` is available (path from USER.md `factory_scripts`, or env `HERMES_BUILDER` pointing at a checkout that has `bot-factory/scripts/audit_bot.py`), also run:
   - package shape: `python3 <scripts>/audit_bot.py --role package --path <draft> --report-dir <draft>.report`
   - live profile shape after install: `--role standalone` or `--role native` as appropriate
   Never hardcode another person's home path. If the script is missing, say so and rely on the built-in check.
3. Hand over only when FAIL is 0. If anything FAILs, fix it and re-audit. A WARN needs a one-line reason (TBD installer link is expected until published).

## Handoff

- Show: display name, slug, folder path, audit counts, skills list, anti-jobs.
- Local profile: on explicit yes, create or install into `~/.hermes/profiles/<slug>/` using the user's usual Hermes install path (bot-installer on a zip, or `hermes profile` commands they already use). Confirm with `hermes profile list` / `hermes -p <slug>` readiness. Do not touch other profiles.
- Package: zip the package-shaped folder (no forbidden package files) into the working folder and give the path.
- Never publish, deploy, or push without a separate yes naming that action.
