---
name: offer-transcript-healthcheck
description: "Use after setup or when asked about routines: offer transcript check."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "bot-designer"}}
---

# Offer the transcript healthcheck

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `~/.hermes/profiles/<this-profile>/workspace/routine-choice-transcript-healthcheck.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line, then ask yes or no:
"Want a weekday transcript healthcheck? On weekdays I'll scan recent Hermes chats for repeated corrections and propose skills or bots. It stays quiet when there's nothing worth saying, and it won't create anything until you pick. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user. If the user asks how they will see it, say so plainly; use a messaging channel only if the user names one that is already set up.

- Explicit no: reply "OK, no transcript check. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-transcript-healthcheck.md`. Stop.
- No clear answer or a change of topic: do not create a routine or record a decline. Carry on with what the user asked.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays 8:44 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a cron expression (weekdays 8:44 = `44 8 * * 1-5`).
3. Get this profile's name (the name of the folder under `~/.hermes/profiles/` holding this bot, usually `bot-designer`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Transcript healthcheck. Follow the transcript-healthcheck skill: scan recent Hermes chats for friction and repeated corrections, write a local report, stay quiet when nothing is worth proposing, and never create a skill, bot, or routine until the user picks." --name "[bot:<profile>] transcript-healthcheck" --skill transcript-healthcheck --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-transcript-healthcheck.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.
