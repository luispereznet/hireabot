---
name: transcript-healthcheck
description: "Use when scanning Hermes chats for friction or corrections."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "bot-designer"}}
---

# Transcript healthcheck

Scan recent Hermes profile chats for user friction and repeated corrections. Propose skills, bots, or routines. Stay quiet when nothing is worth proposing. Never create anything until the user picks an item from the report.

Working folder: `~/.hermes/profiles/bot-designer/workspace`. Save reports under `healthchecks/<YYYY-MM-DD>-transcript.md`. Archive older reports before replacing.

## Scope

1. Ask which profiles to include (default: all under `~/.hermes/profiles/`, plus the default home profile if the user says so). Never read another profile's `memories/USER.md` without an explicit yes.
2. Prefer Hermes CLI exports over raw databases:
   - `hermes -p <profile> sessions list` for recent titles and ids
   - `hermes -p <profile> sessions export <dir> --format md --newer-than 14d` (adjust the window if the user asks)
3. If export fails, say so and stop; do not scrape private DBs by hand.

## What counts as friction

- User repeats the same correction two or more times across sessions
- User says "no", "stop", "I said", "don't", "wrong" after the bot acted
- User re-asks for the same skill-shaped outcome (a sign a skill or routine is missing)
- Bot apologizes in a loop or asks the same question again after an answer
Ignore one-off typos and single clarifications.

## Report

Write a short markdown report:

- Profiles scanned and window
- Findings grouped by theme (missing skill, wrong default, noisy routine, unclear voice)
- For each finding: evidence (session title + paraphrase, no secrets), a proposed fix (skill / bot / routine), and effort (S/M/L)
- If nothing is worth proposing: write one line `quiet: nothing to propose` and tell the user nothing in one short line

## After the report

Show the proposals. Wait. Only when the user picks an item, load `design-hermes-bot` or the matching skill and build that thing. A report never creates files, routines, or bots on its own.
