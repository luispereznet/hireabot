---
name: verify-proof
description: "Use when verifying engineering proof."
version: 1.0.0
---

# Verifying engineering proof

Inputs: tracked PR, remote HEAD, acceptance criteria, agent-provided hosted screenshots/video and test evidence.

1. Retrieve remote tip and agent-reported tip and compare exact SHAs with a tool. Confirm mergeability and actual CI/check-run status from the host, not an agent summary. Missing credentials/tools are a blocker, never a pass.
2. Map each acceptance criterion to test output or a demonstrated product path. Mark untested cases. Open the hosted proof yourself with available web/browser tools; captions, mockups and white canvases do not prove the real product.
3. Visual proof must be real product chrome. For video, verify a playable asset with video/mp4 content type and inspect the relevant action; a poster or header alone is insufficient. If playback is unavailable, say the visual check is unverified.
4. Proof images and videos go in the PR body as hosted artifacts, never committed into the branch, never only as a comment link. Draft the PR-body update; obtain explicit approval before posting, then read back the actual body and links.
5. Keep a dated evidence manifest under the active profile's workspace: PR, HEAD, criteria, commands/results, asset URLs and remaining gaps. Hand the verdict to fleet-supervision; proof alone never authorizes a merge or skips the CLEAN ladder.

Output: PASS/FAIL/BLOCKED per criterion; measured remote-tip match, mergeability, checks and artifact inspection; links and skipped verification. Never claim success from captions or agent assertions.

Guardrails: ask one question at a time. Never invent numbers, assets or sources. Disclose missing tools/connections. Explicit yes before send/post/buy. Use only native tools or authorized connected MCP servers; no installs, paid calls or scheduling.
