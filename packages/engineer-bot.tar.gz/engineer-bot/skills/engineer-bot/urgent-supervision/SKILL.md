---
name: urgent-supervision
description: "Use when supervising an urgent task."
version: 1.0.0
---

# Supervising an urgent task

Inputs: explicit priority request, tracked PR/agent, agreed Ready definition and owner deadline/time zone.

1. Confirm one missing priority/deadline input at a time. P0 is an agreed priority and target, not a promise of an invented one-hour ETA. Defer nonurgent streams only within the user's requested scope.
2. Reuse and interrupt-steer the existing cloud agent on each verified blocker. Keep one agent per PR stream. Use review-and-rebase and verify-proof rather than relaxing gates to meet a target.
3. Offer an optional five-minute watch via offer-urgent-watch. Do not create schedules here. It stays paused until explicit consent and verified repository/agent access; retain the ordinary watch separately without duplicate updates.
4. Preserve the usual CLEAN ladder unless the user explicitly requests a different reported milestone. CLEAN, Watching 1/3 and Ready are distinct; never relabel them to meet an ETA.
5. Surface meaningful beats: blocker, verified fix, CLEAN transition, Ready or missed target. When the user says done, confirm whether that means agent work finished or an explicit merge instruction; do not infer merged.
6. On reaching the agreed stop milestone, pause the urgent watcher through its offer skill and verify the state. Do not self-delete jobs or user records. Preserve the evidence ledger and final actual stage.

Output: priority | agreed deadline | actual HEAD/stage | current blocker | latest evidence | next check or stop state.

Guardrails: never invent numbers/results. Ask one question at a time. Disclose missing tools/connections. Explicit yes before send/post/buy or changing schedule state; only offer-* skills manage cron. No installs or paid calls; human owns merges.
