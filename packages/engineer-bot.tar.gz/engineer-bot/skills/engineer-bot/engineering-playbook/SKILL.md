---
name: engineering-playbook
description: "Use when standing principles for delegating code to cloud agents."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "engineer-bot"}}
---

# Engineering playbook

When to use: Standing principles for delegating code to cloud agents and supervising PRs to merge. Use on every ship or watch.

Inputs: requested task, repository/default branch, acceptance criteria, existing cloud-agent access, board preference and current PR stream.

1. Read confirmed project preferences, fleet records and domain-knowledge reference. Ask one missing blocking question at a time; do requested work before optional onboarding.
2. Verify repository and coding-agent access with native read tools or the user's connected MCP servers. Delegate code work to an existing cloud agent; if none is available, report BLOCKED rather than impersonating a launched agent or installing a service.
3. Query the optional board across owners for the PR before creating a row. Board-first: create the board row (Stage=Working) before you dig or launch. Reuse the existing row/agent for an unmerged follow-up; launch a new stream only for a genuinely new task or agreed rewrite. If Notion is declined, agree on a local ledger first.
4. Give the agent the task, acceptance criteria, repo, allowed branch, tests and proof requirements. One cloud agent per PR stream. Keep its actual handle, PR link and tip SHA; never invent IDs. Do not open unrelated default-branch fixes.
5. Use fleet-supervision for polls and stage transitions, review-and-rebase for failures, and verify-proof for hosted evidence. Never weaken checks. The human owns merges; only a separate explicit merge request authorizes a merge.
6. Report one concise result with task, actual agent/PR handle, stage, evidence and next action. When mentioning a PR, use inline markdown with label #N and the confirmed review URL. Never claim agent completion means merged.

Output: task | agent | [#N](verified review URL) | stage | HEAD | checks/proof | blocker or next action. Save the actual ledger under this profile's workspace; read back remote writes.

Guardrails: never invent numbers or results. Disclose missing tools/connections. Explicit yes before send/post/buy or creating accounts. No credentials in chat, no installs, no paid calls. Scheduling belongs only to offer-* skills. Do not read other profiles without consent.
