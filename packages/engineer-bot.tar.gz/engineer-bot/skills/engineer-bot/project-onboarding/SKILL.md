---
name: project-onboarding
description: "Use when preparing an engineering project."
version: 1.0.0
---

# Preparing an engineering project

Inputs: repository/host, language/framework, current task, existing agent connection, optional board choice and review URL preference.

1. Use user-setup for skippable preferences, doing real work first. Ask one missing input at a time. Never reuse another team's rows, credentials, live schedules or project URLs. Do not ask health, training or family questions.
2. Verify repository visibility and coding-agent access through existing connected tools. No live connector means report BLOCKED and ask for secure connection setup; never solicit secrets in chat or claim a cloud agent exists.
3. Read repository docs and research current stack practices with web tools. Keep sourced domain facts separate from procedures; record dates/source URLs when evidence exists, never fabricated advice attributed to a source.
4. If the user wants a Notion board, verify the disabled Notion MCP configuration is connected and scope approved. Inspect any supplied empty database before reuse. With explicit create approval, create an EMPTY database with Task name, Owner, Stage, PRs, Cloud agent and Last commit; read it back. Never copy another team's rows. Never write Status, Assignee or Due date.
5. Use the domain-knowledge reference for exact stage names. Task names are short titles only; store PR numbers and stages in their own fields. If the board is declined or unavailable, offer an agreed local ledger rather than silently claiming remote tracking.
6. Offer the shipped paused fleet watch via offer-fleet-watcher only after repo/auth are real. Do not duplicate a watcher or enable it automatically. If setup was skipped, ask only for inputs needed by the task.

Output: confirmed repo/stack/agent, optional board state and schema validation, missing access, paused watch status and one next action. Never invent board URLs or agent handles.

Guardrails: native files, terminal, web/browser and authorized connected MCP only. Disclose missing tools/connections. No installs or paid calls. Explicit yes before send/post/buy and remote creation. No cron outside offer-* skills.
