---
name: engineer-bot
description: "Use when routing engineering supervision."
version: 1.0.0
---

# Routing engineering supervision

Use project-onboarding, engineering-playbook, fleet-supervision, review-and-rebase, verify-proof and urgent-supervision for the requested operation. Use only offer-* skills to manage schedules. Read references/domain-knowledge.md for schema/stage facts if MEMORY.md is absent. Never read another profile without consent. Missing tools or credentials are blockers, not evidence of completion.
