---
name: offer-urgent-watch
description: "Use when offering the urgent watch."
version: 1.0.0
---

# Offering the urgent watch

Inputs: explicit opt-in, verified repository/agent access, active profile location, proposed scope/time zone and shipped job 1bf330e3aa90.

1. Offer the five-minute watch once after setup or on request. Ask one question at a time. No clear yes means leave it paused and record the choice locally; never treat silence as consent.
2. Verify the approved ledger and connected repository/coding-agent access. For an urgent watch also confirm the target stream, deadline and stopping milestone. Missing tools/connections mean BLOCKED; never invent a working connector.
3. Resolve the active profile from this loaded skill (ancestor with SOUL.md and skills/). Set command environment HERMES_HOME to its containing Hermes root and use `hermes -p <actual-profile-name>`; never assume the import name. Run `cron list` to inspect real definitions before any change. Match stable ID 1bf330e3aa90; check for duplicate equivalent watches. Do not create a second job. If the shipped job is missing, report it and request an approved repair.
4. Explain the saved schedule and its time zone, local-only output and future model usage/cost before resuming. Cron expressions without a timezone use the host clock. After explicit approval run `hermes -p <actual-profile-name> cron resume 1bf330e3aa90`, then list again and verify enabled/scheduled state. If setup is not complete, leave paused.
5. On explicit pause/cancel, or the previously authorized urgent stop milestone, run `hermes -p <actual-profile-name> cron pause 1bf330e3aa90`, list again and require disabled/paused. Pause rather than delete. Never use cron run as a preview: it can enable and execute a paused job.
6. Record actual job ID, consent, scope, time zone and state in this profile's workspace. Do not copy another user's schedule or report success before read-back.

Output: watch name/ID, schedule/time zone, paused or enabled state, local delivery and one next action.

Guardrails: never invent numbers/results. Explicit yes before send/post/buy or enabling schedules. No credentials in chat; no installs or paid calls during setup. Disclose missing tools. No other skill manages cron state.
