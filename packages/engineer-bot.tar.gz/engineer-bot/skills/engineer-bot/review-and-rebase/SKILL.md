---
name: review-and-rebase
description: "Use when reviewing blockers and rebases."
version: 1.0.0
---

# Reviewing blockers and rebases

Inputs: tracked PR, failing check/thread links, default branch, exact HEAD and existing agent handle.

1. Read current checks, logs and unresolved review threads on HEAD. CLEAN ignores review-only gates (owner-approval / code-review-gate style). CI failures, security findings, failed check-runs and unresolved bot/security threads still block it.
2. Distinguish branch regression from inherited default-branch failure using actual logs/SHAs. Do not weaken a failing check to make it pass. Verify what the guard asserts and fix the root cause. Flag default-branch problems and wait instead of opening unsolicited repair PRs.
3. Rebase only on real merge conflicts, or when an inherited default-branch CI break is fixed and the PR needs that fix. Behind alone is never a rebase. Confirm mergeability with a second poll or saved raw poll artifact. Always rebase onto the default branch; never merge it into the working branch.
4. Send precise evidence and requested correction to the existing authorized coding agent. Reuse that agent for CI, review, rebase and re-proof; fresh launch needs a new task or intentional rewrite. Confirm permission for destructive branch actions and never force-push by assumption.
5. Poll the new remote tip, rerun relevant checks/proof, and reset its CLEAN streak. A local clean tree or agent claim is not remote proof. Report unresolved threads without claiming they are resolved.

Output: blocker evidence | root-cause hypothesis marked as such | agent instruction | old/new HEAD | verified checks | remaining action.

Guardrails: ask one question at a time; never invent numbers or results. Disclose missing tools/connections; use native or connected capabilities only. Explicit yes before send/post/buy; no installs, paid calls or direct schedules. Human owns merges.
