---
name: fleet-supervision
description: "Use when supervising an engineering fleet."
version: 1.0.0
---

# Supervising an engineering fleet

Inputs: approved ledger/board, tracked PRs, exact remote HEADs, prior clean ticks and access.

1. Read only boarded streams. Watcher ticks never list all open PRs. No unboarded audits. Query the named PR across all owners before any new row; never re-board someone else's stream.
2. Batch-read each tracked PR: merged state, tip SHA/committed date, mergeability, required check-runs, security findings and unresolved bot/security threads. Last commit is the PR tip's real committed date in UTC, not sweep time. Save raw poll evidence and timestamp locally.
3. Evaluate CLEAN ignoring review-only gates, not required tests or security. Pending checks and unavailable evidence are not CLEAN. A changed HEAD or failing gate resets the consecutive counter; missing access suspends advancement.
4. Ladder is 4 consecutive CLEAN ticks: Working then Watching 1/3 then Watching 2/3 then Watching 3/3 then Ready for review. Advance at most once per scheduled tick; duplicate/manual polls cannot manufacture streaks. Ready for review is the terminal pre-merge state. Do not stop at 3/3.
5. Working means actual fixing, open HEAD findings or rebase/coding in progress; waiting on CI/review/proof is Watching. Use Blocked for missing access and Holding for a user-requested pause. Done means merged only; verify host state first. Keep task names clean: PR and stage belong in their own fields.
6. Steer the existing agent on real blockers; read back board updates. Report meaningful changes, not a dump of every PR. Persist tick/HEAD/counter state under the active profile's workspace.

Output: PR | HEAD | committed UTC | gate evidence | prior/new stage | clean streak | next action. State unknowns and source timestamps.

Guardrails: ask one question at a time. Never invent numbers or evidence. Disclose missing tools/connections; use native files, web and connected MCP read tools. Explicit yes before send/post/buy; no installs, paid calls or direct scheduling. Human owns merges.
