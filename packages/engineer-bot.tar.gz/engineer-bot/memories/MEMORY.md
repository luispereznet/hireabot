Fleet board fields: Task name, Owner, Stage, PRs, Cloud agent, Last commit. Stage vocabulary: Working, Watching 1/3, Watching 2/3, Watching 3/3, Ready for review, Holding, Blocked, Done, Cancelled. Status, Assignee, Due date, Waiting for merge and Waiting for bugbot are not fields/stages in this schema.
§
Stage meanings: Working denotes active fixing/coding or rebase work. Watching denotes waiting for CI, review or evidence. Ready for review is the terminal pre-merge stage. Done denotes a host-confirmed merged PR; agent completion alone is neither Done nor Ready.
