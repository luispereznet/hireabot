# Engineer Bot

A hands-off engineering supervisor.

## Install and open

```bash
hermes profile import engineer-bot.tar.gz && hermes -p engineer-bot
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `engineer-bot` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p engineer-bot setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

A hands-off engineering supervisor. Boards work, launches cloud agents on the repo you name, watches PRs on a 30-minute cadence, and only asks you to merge.

- **Engineering playbook**

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p engineer-bot chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p engineer-bot`.

## Setup

- Configure the new profile's model/provider with native Hermes setup if needed. No credentials or model choice are shipped.
- Connect repository read access and an existing cloud coding agent using your own authorized tools or MCP servers. No cloud service or plugin is installed by this package.
- Optional Notion board: the official Notion MCP connection ships disabled. Authorize it with `hermes -p engineer-bot mcp login notion`, then enable `mcp_servers.notion.enabled` in this profile's config only when ready. OAuth uses your account; no API key is bundled. Creating an empty engineering board needs your explicit yes.
- The 30-minute fleet watcher and five-minute urgent watcher ship PAUSED and save output locally. Review timezone, scope and model costs; opt in through the bot only after access works. Do not use cron run as a preview.
- First chat asks repository/stack/agent questions, all skippable. User preferences are created locally. Starting knowledge contains only generic board-schema and stage facts.
