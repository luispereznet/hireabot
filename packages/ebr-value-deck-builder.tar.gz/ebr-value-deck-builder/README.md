# EBR & Value Deck Builder

Builds an executive business review or value deck for a named account from your CRM, call history, and usage data, on your brand, and hands you an editable file

## Install and open

```bash
hermes profile import ebr-value-deck-builder.tar.gz && hermes -p ebr-value-deck-builder
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `ebr-value-deck-builder` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p ebr-value-deck-builder setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Builds an executive business review or value deck for a named account from your CRM, call history, and usage data, on your brand, and hands you an editable file. Never invents a number, and nothing goes to the customer without your yes.

- **Brand kit**
- **Ebr deck**
- **Pptx compat**
- **Three whys**
- **Optional renewal deck reminder:** offered once after setup. It is only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p ebr-value-deck-builder chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p ebr-value-deck-builder`.

## Setup

- Local deck generation requires available editable-PPTX tooling; no package installs or tools are bundled. LibreOffice/renderers, PowerPoint opening and Google Slides import are separate checks; disclose unavailable checks, never promise compatibility from an unchecked file.
- All seven MCP servers and sampling ship disabled. Salesforce, HubSpot, Attio, Gong, Mixpanel, Google Drive and OneDrive use optional environment URL placeholders, not verified official connections. Choose one CRM and verify every selected server URL, authentication and scoped tools before enabling with explicit consent. See skills/ebr-value-deck-builder/references/integrations.md and blank .env.EXAMPLE.
- No facts or USER.md are prefilled. user-setup asks domain-specific skippable questions; requested deck work comes first. Brand, evidence, decks and deck-register.json stay in this profile workspace by default.
- One monthly renewal reminder ships paused with local delivery. First-of-month 09:00 is a review default, not your preference. Use offer-renewal-deck-reminder to confirm timezone/DST and resume the same job after explicit yes and readback. No duplicate creation or cron-run preview.
- Upload only a reviewed file to an exact approved Drive/OneDrive destination after explicit yes and verify readback. This bot never sends a deck to a customer.
