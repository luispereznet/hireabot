---
name: pptx-compat
description: "Use when makes every generated pptx open cleanly in PowerPoint."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ebr-value-deck-builder"}}
---

# pptx-compat

When to use: Makes every generated pptx open cleanly in PowerPoint and import into Google Slides by round-tripping it through LibreOffice and checking the result before delivery.

Inputs: The generated editable PPTX, expected slide outline/source ledger and brand kit.

1. Preserve the original. Inspect installed local PPTX readers, renderers and LibreOffice availability with terminal; never install or claim a tool exists without checking. Resolve all work under this active profile's workspace/ using safe filenames.
2. Reopen the PPTX with an available reader. Check ZIP integrity, expected slide count/order, editable text/charts, sources/notes, media relationships and absence of unintended sensitive financial fields. Compare every figure and quote to the approved evidence ledger; structural success is not visual success.
3. If LibreOffice is available, round-trip a copy through Impress to a separate PPTX in a fresh work subfolder using an isolated temporary user profile. Never overwrite the source or delete user files. Check command exit and actual output; reopen the result and compare slide count, text, numbers, notes and media. Repair any loss before delivery.
4. Render all slides when supported and inspect each for clipping, missing logos/fonts, chart labels, contrast and layout changes. Record substitutions; fix and repeat checks. Do not equate rendering with a tested PowerPoint or Google Slides import.
5. Test PowerPoint opening or Google Slides import only with available authorized tools; importing uploads data and requires explicit yes for exact file/account/destination, followed by readback. Without these tools mark those checks untested. If LibreOffice or rendering is absent, list the missing checks and offer a clearly labeled unverified editable file, not a clean-compatibility claim.
6. Return the validated copy only if it preserves content/editability, with the original retained. Give a checklist of passed, failed and unavailable tests plus file path. Block clean delivery claims on corruption or lost evidence.

Output: Actual PPTX artifact and truthful compatibility report. No invented test results, silent uploads or destructive changes.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
