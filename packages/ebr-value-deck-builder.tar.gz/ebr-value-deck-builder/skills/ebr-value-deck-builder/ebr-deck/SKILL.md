---
name: ebr-deck
description: "Use when builds an executive business review deck for a customer account from."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ebr-value-deck-builder"}}
---

# ebr-deck

When to use: Builds an executive business review deck for a customer account from the CRM, calls, and usage data: adoption, value delivered, what changed, roadmap, asks. Every number sourced; on brand; delivered as a file.

Inputs: Named account, review period, audience, authorized CRM/call/usage records and approved brand kit.

1. Confirm the account and period if missing, one question at a time. Read workspace/brand-kit.md or use brand-kit. Inspect recipient tools; select only the owner's CRM (Salesforce, HubSpot or Attio), or accept exports. Connections are optional and disabled by default; never claim access without a successful read.
2. Gather account goals, contracts, customer quotes, adoption/usage with windows/denominators, changes, approved roadmap and requests. Use selected records only. Keep a ledger of claim, source record/URL, date, units and limitations; flag stale or conflicting evidence rather than resolving it by guessing.
3. Calculate comparisons with terminal/code from comparable periods and populations. Preserve currency and units; missing baselines mean no growth/ROI claim. Every figure traces to a CRM record, call, usage report or explicit owner statement.
4. Draft slides covering goals, adoption, outcomes/value, what changed, approved roadmap, asks/next steps and sources. Lead with adoption and outcomes. Include spend, ARR, run rate or per-user dollars only when requested by name. Roadmap is not a delivery commitment; mark unverified outcomes and proposed asks.
5. Build an editable PPTX using available local tooling, with source notes or final sources slide. Use pptx-compat to validate. If generation is unavailable, return the complete slide outline/evidence table and disclose no PPTX was produced; never label an outline as a file.
6. Save under workspace/decks/<safe-account>/<period>/ without overwriting originals; record account ID, period, artifact path and validation in workspace/deck-register.json. Return the actual file and evidence gaps for owner review. Upload only on explicit yes to exact file and Drive/OneDrive destination, then read back that target. Never send a deck to a customer.

Output: Editable review deck, source ledger and compatibility report; no fabricated facts, numbers, quotes or account history.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
