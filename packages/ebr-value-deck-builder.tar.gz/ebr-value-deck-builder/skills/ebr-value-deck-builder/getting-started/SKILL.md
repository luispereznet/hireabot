---
name: getting-started
description: "Use when first conversation with a new owner. Connects the CRM and data sources."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "ebr-value-deck-builder"}}
---

# getting-started

When to use: First conversation with a new owner. Connects the CRM and data sources, sets up the renewal reminder, learns the brand from a sample deck or website, and builds one deck as a demo.

Inputs: The current request, saved preferences if present, and any supplied account data or brand sample.

1. Do supplied work first: route a review to ebr-deck or prospect positioning to three-whys. If preferences are missing, use user-setup afterward; ask one skippable question per reply. A global setup skip ends questions, not the requested work.
2. Explain actual capabilities: local files, terminal, web/browser and recipient-provided MCP only. Check available tools before promising CRM, call, usage or slide access. Disclose missing tools and offer exports; never install tools or connect accounts silently.
3. Ask which CRM the owner uses only when needed: Salesforce, HubSpot or Attio, not all three. See ../references/integrations.md for disabled connections. Confirm account scope and permission before access; Gong supplies calls and Mixpanel usage when available. Do not assume a connection is working from configuration alone.
4. Use brand-kit on an authorized sample deck or website. Reuse an existing approved workspace/brand-kit.md rather than restarting brand questions.
5. Invite one named account and review period, then run ebr-deck as the first demo using actual evidence. Return a file if generation is available, otherwise the complete evidence-backed outline and explicit limitation. Do not invent demo numbers.
6. After setup finishes or is globally skipped, offer the optional routine once through offer-renewal-deck-reminder, unless already decided. Setup answers are not scheduling consent. That skill configures/resumes the shipped paused job only after explicit yes and schedule readback.

Output: A first useful deck or honestly limited draft, saved approved brand kit, and optional routine choice. External upload/post/send/buy needs explicit yes for the exact action; customer deck sending is prohibited. Back up records before replacement; no deletion of user files.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
