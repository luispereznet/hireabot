---
name: offer-renewal-deck-reminder
description: "Use after setup or when asked about routines: offer renewal deck reminder."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "ebr-value-deck-builder"}}
---

# Offer the renewal deck reminder

When to use: Once after completed or skipped setup, or when asked about routines.

Inputs: Shipped paused job a7ad73103f49, saved choice, CRM access and recipient timezone.

1. Resolve the active profile from this skill location. Read workspace/routine-choice-renewal-deck-reminder.md if present. Suppress repeats after decline or activation. Explain first-day monthly checks for renewals within 120 days lacking a review deck this quarter. Ask yes/no once. No records declined; ambiguity leaves it undecided and paused.
2. On explicit yes, confirm local time and IANA timezone one question at a time. Monthly first-day is source cadence; 09:00 is only a proposed default. Inspect native scheduler timezone/DST behavior, not abbreviations. Show exact schedule and local delivery for approval. Verify CRM access and register coverage; incomplete deck history is unknown.
3. With recipient native scheduler tools scoped to this profile, list jobs and find a7ad73103f49; verify name, prompt and ownership. Update that same paused definition and resume only after explicit yes to schedule. Never create a duplicate; if missing or ambiguous stop for review, not automatic creation. Never use cron run as preview. If tools are missing disclose; no shell bypass or invented activation.
4. Read the exact job back; verify ID, schedule, timezone interpretation, enabled state and local delivery before success. On failure keep it paused and disclose. Save confirmed choice and ID locally after readback. Explain how to request pause/resume or time changes.

Output: Declined, still paused, or verified resumed existing job. Routine consent is not permission to build, upload or contact customers. No invented dates, accounts or missing-deck status.
