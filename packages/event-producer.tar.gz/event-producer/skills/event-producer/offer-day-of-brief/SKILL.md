---
name: offer-day-of-brief
description: "Use after setup or when asked about routines: offer day-of brief."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "event-producer"}}
---

# Offer the day-of brief

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

What it does: On the morning of the event at 7 AM, the run of show with owners, vendor arrival times with phone numbers, the guest and dietary counts, and everything still open. Create it as a one-time job on the event date.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-day-of-brief.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the day-of brief? On the morning of the event at 7 AM, the run of show with owners, vendor arrival times with phone numbers, the guest and dietary counts, and everything still open. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-day-of-brief.md`. Stop.
- Yes: continue.

## On a yes

1. Read the event date from the event brief. Suggest 7:00 AM on the event date in the user's time zone and ask to confirm.
2. Run `date +%Z` to get this computer's time zone and convert. This is a one-time job: use an ISO timestamp (for example `2026-12-05T07:00`) as the schedule instead of a cron expression.
3. Get this profile's name (the folder under `~/.hermes/profiles/` holding this bot, usually `event-producer`). Then run exactly:

   hermes -p <profile> cron create "<ISO timestamp>" "Routine: Day-of brief. On the morning of the event at 7 AM, the run of show with owners, vendor arrival times with phone numbers, the guest and dietary counts, and everything still open. Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers." --name "[bot:<profile>] Day-of brief" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <ISO timestamp>` to `routine-choice-day-of-brief.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
