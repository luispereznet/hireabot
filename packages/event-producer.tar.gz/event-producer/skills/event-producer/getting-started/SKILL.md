---
name: getting-started
description: "Use on the first conversation after setup, or whenever memory has no user prefs."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "event-producer"}}
---

# Getting started

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files live in `events/<event>-<YYYY-MM-DD>/`: `brief.md`, `run-of-show.md` (clock time, duration, what happens, one named owner per row), `vendors.md`, `guests.md`, `travel.md`, `day-of.md` and `recap-<YYYY-MM-DD>.md`. Re-read `guests.md` and `vendors.md` before any status answer and write them back after. A guest marked opted out is never invited, reminded or mailed again.

Goal: a real brief or run of show in the first conversation.

## Steps
1. If `memories/USER.md` is missing or empty, load `user-setup`. If the first message already has work in it, do the work first and add the next setup question at the end.
2. Say in one line what works this session: files and pastes always; connected tools only if they show up in your tool list (check; never assume a connection).
3. Get the one thing needed for a first result and load the skill that fits that request.
4. If USER.md already holds the prefs, skip the questions and open with what matters most today.
5. After setup finishes (or is skipped), offer each optional routine once by loading its `offer-*` skill.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
