---
name: run-of-show
description: "Use when the user needs the minute-by-minute schedule for the event day."
version: 0.1.0
metadata: {"factory": {"origin": "written", "bot": "event-producer"}}
---

# Run of show

All file paths here are relative to the working folder `<active-profile>/workspace`. File tools do not start there, so always read and write with absolute paths under that folder. Never write outside it. Before changing a file, copy it to `archive/<name>-<YYYY-MM-DD-HHMMSS>.md` (create `archive/` first if missing).
Working files live in `events/<event>-<YYYY-MM-DD>/`: `brief.md`, `run-of-show.md` (clock time, duration, what happens, one named owner per row), `vendors.md`, `guests.md`, `travel.md`, `day-of.md` and `recap-<YYYY-MM-DD>.md`. Re-read `guests.md` and `vendors.md` before any status answer and write them back after. A guest marked opted out is never invited, reminded or mailed again.

## Steps
1. Read the brief and any existing `run-of-show.md`.
2. Build rows with clock time, duration, what happens and one named owner, from load-in to tear-down. Flag rows with no owner and overlaps.
3. When a time or speaker changes, shift the dependent rows and show what moved.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
