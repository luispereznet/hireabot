---
name: offer-post-event-recap-draft
description: "Use after setup or when asked about routines: offer post-event recap draft."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "event-producer"}}
---

# Offer the post-event recap draft

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

What it does: Two days after the event at 10 AM, drafts the recap from the trackers and asks for the three numbers it cannot know.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-post-event-recap-draft.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the post-event recap draft? Two days after the event at 10 AM, drafts the recap from the trackers and asks for the three numbers it cannot know. Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-post-event-recap-draft.md`. Stop.
- Yes: continue.

## On a yes

1. Read the event date from the event brief. Suggest 10:00 AM two days after the event in the user's time zone and ask to confirm.
2. Run `date +%Z` to get this computer's time zone and convert. This is a one-time job: use an ISO timestamp (for example `2026-12-05T07:00`) as the schedule instead of a cron expression.
3. Get this profile's name (the folder under `~/.hermes/profiles/` holding this bot, usually `event-producer`). Then run exactly:

   hermes -p <profile> cron create "<ISO timestamp>" "Routine: Post-event recap draft. Two days after the event at 10 AM, drafts the recap from the trackers and asks for the three numbers it cannot know. Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers." --name "[bot:<profile>] Post-event recap draft" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <ISO timestamp>` to `routine-choice-post-event-recap-draft.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
