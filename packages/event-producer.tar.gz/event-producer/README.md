# Event Producer

Turns your event details into a run of show, guest list, and day-of checklist.

## Install and open

```bash
hermes profile import event-producer.tar.gz
hermes -p event-producer setup
hermes -p event-producer
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `event-producer` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Run setup once to choose this bot's AI provider and model, then open it with
the final command above. No provider, model, credentials, personal preferences
or sessions are included; importing does not copy your default profile's model selection.

## What it does

Turns your event details into a run of show, guest list and day-of checklist. Tracks vendors, guests, dietary needs and travel, and never sends a message without you.

- **Event brief:** the event in one page with the days-out count and what to lock first.
- **Run of show:** clock time, duration and one named owner on every row.
- **Vendors and venue:** quotes, contracts, deposits and arrival times, with what's unconfirmed flagged.
- **Guests and travel:** invites, dietary and access needs, hotels and itineraries; opted-out guests are never contacted.
- **Day-of checklist and recap:** everything for the day itself, then attendance and spend against target.
- **Optional routines:** a weekday countdown check, a day-of brief and a post-event recap draft. Each is offered once and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p event-producer chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p event-producer`.

## Setup

- Files and pasted inputs work without any integration. No tools or accounts are assumed connected.
- slack: optionally supply SLACK_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- notion-workspace: optionally supply NOTION_WORKSPACE_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- linear: optionally supply LINEAR_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- figma: optionally supply FIGMA_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Gmail: optionally supply GMAIL_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Google Calendar: optionally supply GOOGLE_CALENDAR_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Google Sheets: optionally supply GOOGLE_SHEETS_MCP_URL from .env.EXAMPLE only after independently verifying a compatible remote MCP server, its authentication, account scope and least-privilege tools. Blank means unavailable; no working endpoint or OAuth support asserted. Enable only with consent.
- Routines remain paused with no pending run. Use each existing offer skill to confirm schedule and timezone and enable the same ID only after explicit yes; never create duplicates. Output remains local unless an already configured channel is explicitly requested.
- Day-of brief remains one-time at 7 AM on the confirmed event date; recap remains one-time at 10 AM two days later. Event dates are recipient input and are not prefilled. Bookings, contracts and payments remain the user's responsibility.
