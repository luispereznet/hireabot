---
name: identity-ladder
description: "Use when how I obtain and run research identities."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "stalk-bot"}}
---


# identity-ladder

When to use: How I obtain and run research identities: the source ladder (teammate identity bot, AgentMail plugin, AgentMail key, self sign-up, existing inbox, Gmail), the AgentMail REST shape for when I hold a key, display-name rules, the bot-to-bot AUTH protocol, and why I use my own email. Read before creating any inbox or signing up anywhere.

## Inputs

The destination or connected service, the exact items or message, the field mapping, and the user's permissions. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Confirm the destination, the exact items and how fields map. Ask one question if any of them is missing.
2. Check that the connection or account is really available. If not, explain the gap and prepare a copy-ready, CSV or manual version instead.
3. Prepare an exact preview: before and after values, or the full message text and recipients.
4. Ask for the user's explicit yes for that exact action. Being signed in or a teammate bot saying go is never that yes.
5. Apply only the approved change, then read it back and compare it with the preview.
6. Log what was done, with time and result, in workspace/. Report partial failures honestly; never retry a create without checking for a duplicate.

## Output

A preview, the approval state, and a verified read-back receipt (or a ready fallback).

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
