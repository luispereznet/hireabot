---
name: profile-us
description: "Use at setup and whenever the user's own positioning."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "stalk-bot"}}
---


# profile-us

When to use: Use at setup and whenever the user's own positioning, pricing, or product changes. Builds the baseline every delta is measured against.

## Inputs

The items the user handed over (paste, file, export or connected source) and the existing record in workspace/. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Read the existing record in workspace/. If none exists, say so and create it only for this job.
2. Turn each incoming item into one row with the fields this record needs. Use the fixed value lists when the operating guidance defines them.
3. Dedupe against existing rows on a stable key (ID, link, email or name plus company). Show conflicts with both values and dates; never merge silently.
4. Leave a field blank or Unknown when no source supports it. Never guess.
5. Back up the previous version, write the record back, and summarize what was added, changed and flagged.
6. Return the rows that need action first, then the counts.

## Output

The updated record in workspace/, a change summary, and the rows that need action.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
