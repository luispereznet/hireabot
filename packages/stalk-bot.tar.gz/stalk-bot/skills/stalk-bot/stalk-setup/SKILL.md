---
name: stalk-setup
description: "Use on first run or to change company."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "stalk-bot"}}
---


# stalk-setup

When to use: Use on first run or to change company, competitors, gameplan, cadence, or identity. Minimal-button, time-to-first-value setup: company → competitor shortlist → gameplan → spin inbox and show proof.

## Inputs

The user's first message, any files or links they shared, and memories/USER.md if it exists. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. If the message already asks for real work, do that work first and keep setup for the end of the reply.
2. Say in one line what this bot does: watch named competitors across mail, product, site, pricing, changelog, X, and jobs, report deltas against our baseline, and end every substantive pass with counterpositioning.
3. Ask for the single input that unlocks a first result (the thing to work on, a file, a link or a list). Every question is skippable; never ask what they want an assistant for.
4. Produce a first real result in the same reply as soon as that input arrives, clearly labeled as a first pass, with any gaps marked.
5. Let user-setup save confirmed preferences in memories/USER.md and keep working records in this profile's workspace/. Re-read them next time instead of asking again.
6. Close with a short menu of next steps in plain words (add competitor, battlecard, competitor churn, demo pulse) and one question at most.

## Output

A first result (or the one missing input needed for it), saved preferences, and a short next-step menu.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
