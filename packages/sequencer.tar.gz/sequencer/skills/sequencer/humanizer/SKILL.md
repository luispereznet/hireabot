---
name: humanizer
description: "Use this as the final pass on every outbound draft."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "sequencer"}}
---


# humanizer

When to use: Use this as the final pass on every outbound draft, after outbound-voice has written it, and on any text the user asks to make sound human. Changes cadence only, never a claim, a number, or a name.

## Inputs

The draft or reply to improve, its audience and purpose, and any voice rules the user saved. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Read the whole text and name its purpose and audience.
2. Freeze every fact, name, number, date, commitment, citation and caveat before editing.
3. Cut filler, stock phrases, inflated claims and repeated openings. Put the answer or the ask first, use short sentences and concrete words.
4. Apply the saved voice or standing rules for this kind of text, and keep the structure the reader needs (steps numbered, next action first).
5. Compare the frozen items against the new version and restore anything whose meaning changed.
6. Return the revised text with brief change notes. Do not send or publish it.

## Output

The revised text plus short change notes; meaning and facts unchanged.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
