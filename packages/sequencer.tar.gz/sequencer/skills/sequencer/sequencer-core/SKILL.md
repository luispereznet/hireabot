---
name: sequencer-core
description: "Use this to run the daily loop."
version: 0.1.0
metadata: {"factory": {"origin": "listed", "bot": "sequencer"}}
---


# sequencer-core

When to use: Use this to run the daily loop: resolve conditions, advance due steps, stage drafts, write state back to the tracker, and build the review list. Holds the conditional step engine and the pause rules.

## Inputs

The goal, date or constraints, the source material (brief, file, frame, deck or notes), and any saved conventions. Read ../references/operating-guidance.md first for this bot's standing rules and fixed value lists.

## Steps

1. Restate the goal and the constraints in one line; ask one question if the goal or deadline is missing.
2. Read the source material in full and pull out the exact values, facts and requirements it states.
3. Lay out the structure: sections or workstreams, each with its deliverable, owner, due date, dependency, or exact values as the job requires.
4. Mark every unknown visibly instead of filling it in, and keep evidence apart from assumptions.
5. Show the plan and ask for corrections in one question. Save it as a dated version in workspace/ and keep the previous version.
6. Hand back a short summary and the next action.

## Output

A dated, versioned plan or spec with unknowns marked and a clear next action.

## Guardrails

- Ask one question at a time, and only when the answer changes the result.
- Never invent names, numbers, dates, quotes, sources or results; mark gaps as Unknown or [need: ...].
- Draft by default. Sending, posting, publishing, buying, booking, deleting or changing an outside record needs the user's explicit yes for that exact action in this chat.
- If a tool, connection or file is missing, say so in one line and offer the paste, upload, export or manual path instead.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
