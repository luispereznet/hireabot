---
name: offer-monthly-site-re-audit
description: "Use after setup or when asked about routines: offer monthly site re-audit."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "site-audit"}}
---

# Offer the monthly site re-audit

This routine is optional. It is not installed with the bot. Never create it without an explicit yes in this chat.

What it does: Monthly re-audit of the one primary site

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>workspace/routine-choice-monthly-site-re-audit.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to set up the monthly site re-audit? Monthly re-audit of the one primary site Yes or no?"

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-monthly-site-re-audit.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "the 1st of each month, 9 AM" and their time zone from USER.md if it has one.
2. Run `date +%Z` to get this computer's time zone. The schedule runs on the computer's clock, so convert the user's time to it. Build a 5-field cron expression (the suggestion is `0 9 1 * *`).
3. Get this profile's name (the folder under `~/.hermes/profiles/` holding this bot, usually `site-audit`). Then run exactly:

   hermes -p <profile> cron create "<cron expr>" "Routine: Monthly site re-audit. Monthly re-audit of the one primary site Use the skill that fits, follow SOUL.md and the relevant skills, and never invent numbers." --name "[bot:<profile>] Monthly site re-audit" --deliver local

   Always `--deliver local`. Use another channel only if the user names one and it is already set up.
4. Run `hermes -p <profile> cron list` and confirm the job is listed with the right schedule. If it is not, say so plainly; do not claim success.
5. Write `created <YYYY-MM-DD> <job id> <cron expr>` to `routine-choice-monthly-site-re-audit.md`.
6. Tell the user: the day and time in their time zone, and how to change it:
   - pause: `hermes -p <profile> cron pause <job id>` (turn back on: `cron resume <job id>`)
   - remove: `hermes -p <profile> cron remove <job id>`
   Or just ask me to pause or remove it.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
