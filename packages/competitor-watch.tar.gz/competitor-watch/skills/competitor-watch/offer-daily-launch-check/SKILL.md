---
name: offer-daily-launch-check
description: "Use after setup or when asked about routines: offer daily launch check."
version: 0.1.0
metadata: {"factory": {"origin": "routine-offer", "bot": "competitor-watch"}}
---

# Offer the daily launch check

This routine is optional. Its native definition ships paused (ID `8e950620ad50`). Never enable it without an explicit yes in this chat.

What it does: Each weekday morning, checks changelog, release note, and blog pages across the watch list and speaks up only when a competitor ships something.

## When to offer

- Once, right after first-chat setup finishes (or the user skipped it), or whenever the user asks about routines, reminders or check-ins.
- Before offering, read `<active-profile>/workspace/routine-choice-daily-launch-check.md`. If it says `declined` or `created`, do not offer again unless the user brings it up.

## Ask

Say in one line what it does, then ask yes or no:
"Want me to enable the daily launch check? Each weekday morning, checks changelog, release note, and blog pages across the watch list and speaks up only when a competitor ships something. Yes or no?"

With local delivery the routine saves each result here in Hermes and does not message the user. If the user asks how they will see it, say so plainly; use a messaging channel only if the user names one that is already set up.

- No (or no clear answer): reply "OK, not set up. Ask me any time." Write `declined <YYYY-MM-DD>` to `routine-choice-daily-launch-check.md`. Stop.
- Yes: continue.

## On a yes

1. Ask day, time and time zone in one question. Suggest "weekdays, 9 AM" and their time zone from USER.md if it has one.
2. Confirm the user's time zone and inspect the native scheduler's actual timezone and daylight-saving interpretation; convert the approved day/time correctly. The original suggested expression is `0 9 * * 1-5`; it is not an agreed schedule.
3. Resolve the active profile from this loaded skill's location. List its native jobs and find `8e950620ad50` named `[bot:competitor-watch] Daily launch check`. Verify ownership and prompt. Update that same paused definition to the agreed schedule and resume only with the user's explicit yes. Never create a duplicate; if the shipped definition is missing or mismatched, explain and stop.
4. Read back that exact job and verify its schedule, enabled state and local delivery before claiming success. Keep local delivery unless the user explicitly names an already configured messaging channel.
5. Write `created <YYYY-MM-DD> 8e950620ad50 <cron expr>` to `routine-choice-daily-launch-check.md` only after verification, preserving the existing choice marker so this offer is not repeated.
6. Tell the user the day/time in their time zone and that they may ask to pause, resume or remove this job. Do not run the job as an activation preview.


## Portable profile storage

Resolve <active-profile> from this loaded skill's location: it is the ancestor
containing skills/ and SOUL.md. Never assume the profile name, default Hermes
home, working directory, or username. Resolve relative workspace paths under
that active profile's workspace/; user preferences live in its memories/USER.md.
Missing working files mean no saved history; create them only as needed.
Back up records before replacing them. Do not delete user files.
