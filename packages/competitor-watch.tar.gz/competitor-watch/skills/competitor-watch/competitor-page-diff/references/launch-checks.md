# Public launch-check workflow

1. Inspect the competitor's public homepage and documentation links for a blog, changelog, or official repository. Fetch the relevant release feed and product documentation together when independent. Do not mistake third-party directory listings about releases for first-party launch evidence.
2. If GitHub hosts the officially linked project, read its public releases page. To verify the newest non-prerelease publication timestamp and notes, request `https://api.github.com/repos/<owner>/<repo>/releases/latest` without credentials and inspect `tag_name`, `published_at`, `html_url`, and `body`. Cite the release's `html_url`; retain the API URL as verification provenance. This endpoint covers the latest stable release, not every release or prerelease.
3. Use the explicit publication timestamp rather than relative UI text or a commit-signing date; those describe different events. Distinguish the associated CLI release from a launch of the directory website itself.
4. Classify findings before drafting:
   - Prior snapshot plus changed product evidence: verified observed change, with both snapshot times.
   - Dated official release: released functionality or fixes, even on a first run; do not imply it changed since a nonexistent prior check.
   - Undated feature documentation: current capability, launch timing unknown.
   - Maintenance/security fixes: explain the practical effect without promoting them into a major product launch.
5. State what was checked and what remains uncertain. GitHub asset-loading errors do not invalidate readable release notes; isolate the affected portion instead of discarding sound evidence or claiming complete coverage. If no dedicated blog or changelog is identified, describe the discovery scope rather than claiming none exists.
6. Save source text and a short local brief. For multiple pages, verify successful nonempty snapshots against the expected page count. Report paths in plain text in CLI sessions; do not send, publish, install competitor commands, visit authenticated management flows, or create schedules as part of a read-only check.
