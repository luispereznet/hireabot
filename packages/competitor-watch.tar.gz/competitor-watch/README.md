# Competitor Watch

Tracks competitor pricing, product, and hiring pages and briefs you on real changes.

## Install and open

```bash
hermes profile import competitor-watch.tar.gz && hermes -p competitor-watch
```

Import refuses an existing name; use `--name another-name` and open that name
instead. Native import may create a `competitor-watch` wrapper when the name is free;
using it additionally requires the wrapper directory on PATH. The explicit
`hermes -p` command does not depend on that alias.

Configure the new profile's AI connection with `hermes -p competitor-watch setup` if
needed. No provider, model, credentials, personal preferences or sessions are
included. Installation alone does not guarantee model connectivity.

## What it does

Tracks your competitors' pricing, product and hiring pages on the public web and tells you only about the changes that matter, each with its source link. Start by pasting a few competitor names or URLs.

- **Watch list:** a short list of competitors and the pages that matter (pricing, product, changelog, blog, careers).
- **Page diffs:** compares each page with the copy saved last time and ignores noise.
- **Weekly brief:** the top changes, why they matter, and a suggested follow-up, with a link on every line.
- **Pricing comparison:** your plans against theirs in one table, numbers copied exactly, never guessed.
- **Optional routines:** a Monday brief and a weekday launch check, each offered once after setup and only enabled if you say yes.

## First chat and optional capabilities

Setup questions are skippable and create this profile's own USER.md. Real
work comes first. Reading another profile's preferences requires consent.
Included routine definitions are paused; review setup and explicitly enable them before use. Connect integrations
and supply any additional tools yourself; the bot must explain unavailable
capabilities. Nothing is sent or published without approval.

## Bot Chat (terminal)

To message other bots from the terminal, open this bot's forever-chat titled
exactly `Bot Chat`:

```bash
hermes -p competitor-watch chat -c "Bot Chat" --create-if-missing
```

That title is required for bot-to-bot messaging. Desktop Bot Mode creates it for you.

## Desktop roster and portability

It appears in Hermes Desktop's Bots roster.
Open it with `hermes -p competitor-watch`.

## Setup

- No integration is required: use the original pasted, forwarded, screenshot or public-web input paths; disclose unavailable tools.
- Linear is a separately installed optional competitor-watch-linear.zip add-on. No add-on files, skills or Linear MCP requirement are bundled. Install it separately only if wanted, then follow its own setup.
- slack: leave SLACK_MCP_URL blank unless wanted. Select and verify a compatible remote MCP server, authentication, account scope and least-privilege tools first; then fill the local variable from .env.EXAMPLE and enable only with consent. No working endpoint or OAuth support is asserted.
- notion-workspace: leave NOTION_WORKSPACE_MCP_URL blank unless wanted. Select and verify a compatible remote MCP server, authentication, account scope and least-privilege tools first; then fill the local variable from .env.EXAMPLE and enable only with consent. No working endpoint or OAuth support is asserted.
- All routine definitions ship paused with no next run. Review the original suggested schedule and recipient timezone in its offer skill; enable the same ID only after yes. Local delivery saves results here and sends no message.
